const { EmbedBuilder, WebhookClient, ActivityType } = require('discord.js');
const dataBetaDev = require('../db/databaseBetaDev');
const { prefix } = require('../config.json');
const synchronizeSlashCommands = require('../modules/sync_commands.js');
const moment = require('moment-timezone');
const dbLove = require('../db/databaseLove');
const { joinVoiceChannel } = require('@discordjs/voice');
const guildId = '1248609173894336563';
module.exports = {
    name: 'ready',
    async execute(client) {  

  const channel = client.channels.cache.get('1261665354065907734'); // ID của kênh âm thanh
  if (channel) {
    joinVoiceChannel({
      channelId: channel.id,
      guildId: channel.guild.id,
      adapterCreator: channel.guild.voiceAdapterCreator,
    });
  }
        console.log(`Logged in as ${client.user.tag}!`);

        // Đếm tổng số server và member
        const totalGuilds = client.guilds.cache.size;
        const totalMembers = client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0);

        // Đặt activity cho bot
        client.user.setActivity(`Server: ${totalGuilds}, Members: ${totalMembers}`, { type: ActivityType.Watching });


        // client.user.setActivity(`Check help nối từ: ${prefix}noitu || Check help mục khác: ${prefix}help`, { type: ActivityType.Playing });
        client.user.setStatus('idle');

  
        setInterval(checkVoiceChannels, 30 * 60 * 1000);

        // Unmute users whose mute duration has expired
        const now = Date.now();
        // Synchronize slash commands
        await synchronizeSlashCommands(client,
            client.commands.map((c) => c.data),
            {
                // The parameters to be modified for synchronisation
                debug: true,
                // If you set a server ID, then it will ONLY be for the targeted server.
                // If you don't put guildID, it will be in GLOBAL,
                // So on all servers.
                // guildId: "YourDiscordServerOrDeleteThisLine"
            }
        )

        // Resume active giveaways
        dataBetaDev.all(`SELECT * FROM giveaways WHERE endTime > ? AND is_deleted = 0`, [Date.now()], async (err, rows) => {
            if (err) {
                console.error('Error fetching giveaways:', err);
                return;
            }

            for (const row of rows) {
                const guild = client.guilds.cache.get(row.guildId);
                if (!guild) continue;

                const channel = guild.channels.cache.get(row.channelId);
                if (!channel) continue;

                try {
                    const message = await channel.messages.fetch(row.messageId);
                    const remainingTime = row.endTime - Date.now();

                    setTimeout(async () => {
                        const fetchedMessage = await channel.messages.fetch(row.messageId);
                        const reactions = fetchedMessage.reactions.cache.get('1261960933270618192');

                        if (reactions) {
                            const users = await reactions.users.fetch();
                            const validUsers = users.filter(user => !user.bot).map(user => user);

                            const updatedEmbed = new EmbedBuilder()
                                .setTitle(row.prize)
                                .setFooter({ text: `Số lượng giải: ${row.winnerCount}` })
                                .setTimestamp(row.endTime)
                                .setThumbnail(message.author.displayAvatarURL());

                            if (validUsers.length > 0) {
                                const winners = validUsers.sort(() => Math.random() - Math.random()).slice(0, row.winnerCount);
                                await fetchedMessage.reply(`<a:mcw_timchat:1255340646248616006> Chiến thắng: ${winners.map(user => user.toString()).join(', ')}! Phần thưởng: **${row.prize}**, <a:mcw_timchat:1255340646248616006> Tổ chức bởi: ${message.author}`);

                                updatedEmbed.setDescription(`Giveaway đã kết thúc!\n<a:mcw_timchat:1255340646248616006> Tổ chức bởi: ${message.author}\n<a:mcw_timchat:1255340646248616006> Người chiến thắng: ${winners.map(user => user.toString()).join(', ')}`);
                            } else {
                                await fetchedMessage.reply(`Không có ai tham gia giveaway này.`);
                                updatedEmbed.setDescription(`Giveaway đã kết thúc!\n<a:mcw_timchat:1255340646248616006> Tổ chức bởi: ${message.author}\nKhông có ai tham gia giveaway này.`);
                            }

                            fetchedMessage.edit({ embeds: [updatedEmbed] });
                        }

                        dataBetaDev.run(`UPDATE giveaways SET is_deleted = 1 WHERE messageId = ?`, [row.messageId], async (err) => {
                            if (err) {
                                console.error(err);
                            }
                        });
                    }, remainingTime);
                } catch (fetchErr) {
                    console.error('Error fetching message:', fetchErr);
                }
            }
        });
    }
};

async function checkVoiceChannels() {
  dbLove.all(`SELECT * FROM voice_status`, async (err, rows) => {
    if (err) return console.error(err);
    
    const voiceChannels = rows.reduce((acc, row) => {
      if (!acc[row.channel_id]) acc[row.channel_id] = [];
      acc[row.channel_id].push(row);
      return acc;
    }, {});

    for (const channelId in voiceChannels) {
      const usersInChannel = voiceChannels[channelId];
      
      if (usersInChannel.length > 1) {
        for (let i = 0; i < usersInChannel.length; i++) {
          for (let j = i + 1; j < usersInChannel.length; j++) {
            const user1 = usersInChannel[i];
            const user2 = usersInChannel[j];
            
            const joinTime1 = new Date(user1.join_time);
            const joinTime2 = new Date(user2.join_time);
            const currentTime = new Date();
            
            const duration1 = (currentTime - joinTime1) / (1000 * 60); // in minutes
            const duration2 = (currentTime - joinTime2) / (1000 * 60); // in minutes
            
            if (duration1 >= 30 && duration2 >= 30) {
              dbLove.get(`SELECT * FROM love_data WHERE (user1_id = ? AND user2_id = ?) OR (user1_id = ? AND user2_id = ?)`, [user1.user_id, user2.user_id, user2.user_id, user1.user_id], (err, row) => {
                if (err) return console.error(err);
                if (row) {
                  const randomPoints = Math.floor(Math.random() * 100) + 1;
                  const newIntimacyLevel = row.intimacy_level + randomPoints;
                  
                  dbLove.run(`UPDATE love_data SET intimacy_level = ? WHERE id = ?`, [newIntimacyLevel, row.id]);
                  // console.log(`Increased intimacy level for ${user1.user_id} and ${user2.user_id} by ${randomPoints} points`);
                }
              });
            }
          }
        }
      }
    }
  });
}