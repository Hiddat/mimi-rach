const { EmbedBuilder, WebhookClient } = require('discord.js');

module.exports = {
    name: 'rateLimit',
    execute(info, client) {
        console.log(message);
    },
};
