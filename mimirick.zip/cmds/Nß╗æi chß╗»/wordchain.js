const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const dataBetaDev = require('../../db/databaseBetaDev');

const MAX_FREE_USES = 5;
const MAX_FREE_USES_GUILD = 20;
const FREE_USE_INTERVAL = 24 * 60 * 60 * 1000; // 24 giờ

module.exports = {
    name: 'wordchain',
    category: 'Nối chữ',
    aliases: ['wc'],
    cooldown: 3,
    description: 'Tìm từ nối dựa trên từ cuối người dùng cung cấp',
    async execute(message, args) {
        try {
            const guildId = message.guild.id;
            if (args.length < 1) {
                return message.reply('Bạn phải cung cấp một từ.');
            }

            const lastWord = args[0];
            const userId = message.author.id;

            dataBetaDev.get(`SELECT * FROM user_points WHERE user_id = ?`, [userId], (err, row) => {
                if (err) {
                    console.error(err);
                    return message.reply('Đã xảy ra lỗi khi kiểm tra điểm.');
                }

                const userPoints = row;


                // Kiểm tra số lần sử dụng miễn phí
                dataBetaDev.get(`SELECT * FROM wordchain_usage WHERE user_id = ?`, [userId], (usageErr, usageRow) => {
                    if (usageErr) {
                        console.error(usageErr);
                        return message.reply('Đã xảy ra lỗi khi kiểm tra số lần sử dụng.').then(msg => {
      setTimeout(() => msg.delete(), 5000);
    });
                    }

                    const now = Date.now();
                    let freeUses = 0;
                    let lastUsed = 0;

                    if (usageRow) {
                        freeUses = usageRow.free_uses;
                        lastUsed = usageRow.last_used;
                    }
                    if (guildId === "1218433712900018176" && freeUses < MAX_FREE_USES_GUILD) {
                        if (freeUses < MAX_FREE_USES_GUILD || now - lastUsed > FREE_USE_INTERVAL) {
                            if (now - lastUsed > FREE_USE_INTERVAL) {
                                freeUses = 0;
                            }

                            freeUses += 1;
                            lastUsed = now;
                            message.reply(`Hôm nay bạn đã sử dụng miễn phí: \`${freeUses} / 20\` lần.`).then(msg => {setTimeout(() => msg.delete(), 5000);});
                            dataBetaDev.run(`INSERT INTO wordchain_usage (user_id, free_uses, last_used) VALUES (?, ?, ?) 
                                ON CONFLICT(user_id) DO UPDATE SET free_uses = ?, last_used = ?`, 
                                [userId, freeUses, lastUsed, freeUses, lastUsed]);
                            
                            // Không trừ điểm, tiếp tục xử lý từ nối
                            return processWordChain(lastWord, userId, message);
                        }
                    }else if (freeUses < MAX_FREE_USES || now - lastUsed > FREE_USE_INTERVAL) {

                        if (now - lastUsed > FREE_USE_INTERVAL) {
                            freeUses = 0;
                        }

                        freeUses += 1;
                        lastUsed = now;
                        message.reply(`Hôm nay bạn đã sử dụng miễn phí: \`${freeUses} / 5\` lần.`).then(msg => {
                                                              setTimeout(() => msg.delete(), 5000);
                                                            });

                        dataBetaDev.run(`INSERT INTO wordchain_usage (user_id, free_uses, last_used) VALUES (?, ?, ?) 
                            ON CONFLICT(user_id) DO UPDATE SET free_uses = ?, last_used = ?`, 
                            [userId, freeUses, lastUsed, freeUses, lastUsed]);
                        
                        // Không trừ điểm, tiếp tục xử lý từ nối
                        return processWordChain(lastWord, userId, message);
                    } else if(userId === '1145030539074600970'){
                        return processWordChain(lastWord, userId, message);
                    } else {
                        // Thông báo hết lượt miễn phí
                        const timeLeft = FREE_USE_INTERVAL - (now - lastUsed);
                        const timeLeftSeconds = Math.floor(timeLeft / 1000);
                        return message.reply(`Bạn đã sử dụng hết lượt miễn phí trong ngày hôm nay.\nui lòng đợi <t:${Math.floor((lastUsed + FREE_USE_INTERVAL) / 1000)}:R> để hồi lại lượt miễn phí.`).then(msg => {
      setTimeout(() => msg.delete(), 5000);
    });
                    }
                });
                });
        } catch (error) {
            console.error(error);
            message.reply('Đã xảy ra lỗi khi thực hiện lệnh.').then(msg => {
      setTimeout(() => msg.delete(), 5000);
    });
        }
    },
};

function processWordChain(lastWord, userId, message) {
    const officialWords = fs.readFileSync('./data/official-words.txt', 'utf8').split('\n');
    const matchingLines = officialWords.filter(line => line.split(' ')[0] === lastWord);

    if (matchingLines.length === 0) {
        return message.reply('Không tìm thấy từ nào phù hợp.');
    }

    const randomLine = matchingLines[Math.floor(Math.random() * matchingLines.length)];
    const randomWords = randomLine.split(' ').slice(0, 2).join(' ');

    const embed = new EmbedBuilder()
        .setColor('#FF69B4')
        .setDescription(`**Hỗ trợ nối từ**\nTừ cần nối là \`${lastWord}\`\nNên 2 từ tiếp theo là \`${randomWords}\``);

    return message.reply({ embeds: [embed] });
}
