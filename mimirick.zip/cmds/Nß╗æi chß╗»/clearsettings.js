const { PermissionsBitField } = require('discord.js');
const fs = require('fs');
const path = require('path');
const dataChannel = require('../../data/data.json'); // Đọc file JSON nơi bạn lưu dữ liệu cho nối từ tiếng Việt
const dataBetaDev = require('../../db/databaseBetaDev'); // Dành cho các trò chơi khác

module.exports = {
    name: 'clearsettings',
    description: 'Xóa thiết lập cho các trò chơi đã thiết lập trên server',
    category: 'Nối chữ',
    cooldown: 3,
    aliases: ['clearset', 'resetsettings'],
    async execute(message, args) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
            return message.reply('Bạn cần quyền ManageGuild để sử dụng lệnh này.');
        }

        const type = args[0]; // Loại trò chơi: wordchain, count, romancount, vietnamese

        if (!type) {
            return message.reply(`Vui lòng cung cấp loại trò chơi cần xóa (wordchain, count, romancount, vietnamese).
                Trong đó:
                - \`wordchain\` : là tiếng anh\n- \`count\` : là số\n- \`romancount\` : là số la mã\n- \`vietnamese\` : là tiếng Việt
                
                \nVí dụ: clearsettings wordchain (là xoá nối tiếng anh)`);
        }

        const guildId = message.guild.id;

        switch (type.toLowerCase()) {
            case 'wordchain':
                dataBetaDev.run(`DELETE FROM wordchain_channels WHERE guild_id = ?`, [guildId], (err) => {
                    if (err) {
                        console.error(err);
                        return message.reply('Có lỗi xảy ra khi xóa thiết lập nối chữ.');
                    }
                    message.reply('Thiết lập kênh nối chữ đã được xóa.');
                });
                break;

            case 'count':
                dataBetaDev.run(`DELETE FROM count_channels WHERE guild_id = ?`, [guildId], (err) => {
                    if (err) {
                        console.error(err);
                        return message.reply('Có lỗi xảy ra khi xóa thiết lập đếm số.');
                    }
                    message.reply('Thiết lập kênh đếm số đã được xóa.');
                });
                break;

            case 'romancount':
                dataBetaDev.run(`DELETE FROM roman_count_channels WHERE guild_id = ?`, [guildId], (err) => {
                    if (err) {
                        console.error(err);
                        return message.reply('Có lỗi xảy ra khi xóa thiết lập nối số La Mã.');
                    }
                    message.reply('Thiết lập kênh nối số La Mã đã được xóa.');
                });
                break;

            case 'vietnamese':
                // Xóa kênh cho trò chơi nối từ tiếng Việt
                if (dataChannel[guildId]) {
                    delete dataChannel[guildId];
                    fs.writeFileSync(path.resolve(__dirname, '../../data/data.json'), JSON.stringify(dataChannel, null, 2));
                    message.reply('Thiết lập kênh nối từ tiếng Việt đã được xóa.');
                } else {
                    message.reply('Không tìm thấy thiết lập kênh nối từ tiếng Việt.');
                }
                break;

            default:
                message.reply('Loại trò chơi không hợp lệ. Vui lòng chọn: wordchain, count, romancount, vietnamese.');
        }
    },
};
