const { PermissionsBitField, EmbedBuilder } = require('discord.js');
const dataBetaDev = require('../../db/databaseBetaDev');

module.exports = {
    name: 'bugworden',
    description: 'Tắt hoặc bật lỗi ngắt chuỗi nối chữ EN cho server này',
    category: 'Nối chữ',
    cooldown: 3,
    async execute(message, args) {
        // Check if the user has the "MANAGE_GUILD" permission
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
            return message.reply('Bạn không có quyền để thực hiện lệnh này.');
        }

        const guildId = message.guild.id;

        // Get the current state of the bot for this guild from the database
        dataBetaDev.get(`SELECT state FROM toggle_states WHERE guild_id = ?`, [guildId], (err, row) => {
            if (err) {
                console.error('Error fetching toggle state:', err);
                return message.reply('Đã xảy ra lỗi khi kiểm tra trạng thái của bot.');
            }

            // Determine the new state to set
            const newState = row ? !row.state : true;

            // Update the database with the new state
            if (row) {
                dataBetaDev.run(`UPDATE toggle_states SET state = ? WHERE guild_id = ?`, [newState, guildId], (err) => {
                    if (err) {
                        console.error('Error updating toggle state:', err);
                        return message.reply('Đã xảy ra lỗi khi cập nhật trạng thái của bot.');
                    }
                    sendToggleResult();
                });
            } else {
                dataBetaDev.run(`INSERT INTO toggle_states (guild_id, state) VALUES (?, ?)`, [guildId, newState], (err) => {
                    if (err) {
                        console.error('Error inserting toggle state:', err);
                        return message.reply('Đã xảy ra lỗi khi thêm trạng thái của bot.');
                    }
                    sendToggleResult();
                });
            }

            function sendToggleResult() {
                const embed = new EmbedBuilder()
                    .setTitle('Trạng thái bot đã được cập nhật')
                    .setDescription(`Trạng thái ngắt chuỗi EN hiện đang **${newState ? 'Bật' : 'Tắt'}**.`)
                    .setColor('#FFB6C1');
                message.channel.send({ embeds: [embed] });
            }
        });
    }
};
