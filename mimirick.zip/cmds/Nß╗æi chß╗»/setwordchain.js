const { PermissionsBitField, EmbedBuilder } = require('discord.js');
const dataBetaDev = require('../../db/databaseBetaDev');
const fs = require('fs');
const path = require('path');

const wordsE = fs.readFileSync(path.resolve(__dirname, '../../data/wordsE.txt'), 'utf-8').split('\n').map(word => word.trim().toLowerCase());

module.exports = {
    name: 'setwordchain',
    description: 'Thiết lập kênh cho trò chơi nối chữ tiếng Anh',
    category: 'Nối chữ',
    cooldown: 3,
    aliases: ['setword', 'swc'],
    async execute(message, args) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
            return message.reply('Bạn không có quyền để thực hiện lệnh này.');
        }

        const channel = message.mentions.channels.first() || message.channel;

        const guildId = message.guild.id;
        const channelId = channel.id;

        dataBetaDev.run(`INSERT OR REPLACE INTO wordchain_channels (guild_id, channel_id) VALUES (?, ?)`, [guildId, channelId], (err) => {
            if (err) {
                console.error(err);
                return message.reply('Có lỗi xảy ra khi thiết lập kênh nối chữ.');
            }

            const embed = new EmbedBuilder()
                .setTitle('Thiết lập kênh nối chữ')
                .setDescription(`Kênh nối chữ đã được thiết lập thành công: <#${channelId}>`)
                .setColor(0xFF69B4); // Màu hồng
                
            message.reply({ embeds: [embed] });

            // Chọn từ bắt đầu ngẫu nhiên
            const startingWord = wordsE[Math.floor(Math.random() * wordsE.length)];

            dataBetaDev.run(`INSERT OR REPLACE INTO wordchain_rounds (guild_id, word, last_user, round_number) VALUES (?, ?, ?, ?)`, [guildId, startingWord, '', 1], (err) => {
                if (err) {
                    console.error(err);
                    return message.reply('Có lỗi xảy ra khi bắt đầu trò chơi.');
                }
                channel.send(`Trò chơi nối chữ bắt đầu với từ: **${startingWord}**`);
            });
        });
    },
};
