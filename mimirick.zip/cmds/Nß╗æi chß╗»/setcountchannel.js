const { EmbedBuilder, PermissionsBitField } = require('discord.js');
const dataBetaDev = require('../../db/databaseBetaDev');

module.exports = {
    name: 'setcountchannel',
    description: 'Thiết lập kênh cho trò chơi đếm số',
    category: 'Nối chữ',
    cooldown: 3,
    aliases: ['setcount', 'scc'],
    async execute(message, args) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
            return message.reply('Bạn không có quyền để thực hiện lệnh này.');
        }

        const channel = message.mentions.channels.first() || message.channel;


        const guildId = message.guild.id;
        const channelId = channel.id;

        const botPermissions = channel.permissionsFor(message.client.user);
        if (!botPermissions.has(PermissionsBitField.Flags.SendMessages) || !botPermissions.has(PermissionsBitField.Flags.AddReactions)) {
            return message.reply('Bot không có đủ quyền hạn trong kênh được tag.');
        }

        dataBetaDev.run(`INSERT OR REPLACE INTO count_channels (guild_id, channel_id, current_number, last_user_id) VALUES (?, ?, ?, ?)`, [guildId, channelId, 0, ''], (err) => {
            if (err) {
                console.error(err);
                return message.reply('Có lỗi xảy ra khi thiết lập kênh đếm số.');
            }

            const embed = new EmbedBuilder()
                .setTitle('<a:2006pinkflame:1261960949951365212> Thiết lập kênh đếm số <a:2006pinkflame:1261960949951365212>')
                .setDescription(`Kênh đếm số đã được thiết lập thành công: <#${channelId}>`)
                .setColor(0xFF69B4); // Màu hồng
                
            message.reply({ embeds: [embed] });
            channel.send('Con số bắt đầu là 0');
        });
    },
};
