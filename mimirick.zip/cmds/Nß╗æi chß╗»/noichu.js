const { PermissionsBitField } = require('discord.js');
const fs = require('fs');
const dataChannel = require('../../data/data.json');
const path = require('path');

module.exports = {
    name: 'setnoichu',
    description: 'Cài đặt kênh chơi nối từ tiếng Việt, tag kênh để đặt kênh nối chữ tiếng Việt',
    category: 'Nối chữ',
    cooldown: 3,
    aliases: ['noichu'],
    async execute(message, args) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
            return message.reply('<a:NQG_xc126:1255341397981266012> Bạn cần có quyền Admin để thực hiện thao tác này! <a:NQG_xc126:1255341397981266012>');
        }

        let channel = message.mentions.channels.first();

        // Nếu không có kênh được tag, sử dụng kênh hiện tại
        if (!channel) {
            channel = message.channel;
        }

        // Kiểm tra quyền của bot trong kênh
        const botPermissions = channel.permissionsFor(message.client.user);
        if (!botPermissions.has(PermissionsBitField.Flags.ViewChannel)) {
            return message.reply('<a:NQG_xc126:1255341397981266012> Tôi không có quyền xem kênh này! <a:NQG_xc126:1255341397981266012>');
        }

        if (!botPermissions.has(PermissionsBitField.Flags.SendMessages)) {
            return message.reply('<a:NQG_xc126:1255341397981266012> Tôi không có quyền gửi tin nhắn ở kênh này! <a:NQG_xc126:1255341397981266012>');
        }

        if (!botPermissions.has(PermissionsBitField.Flags.AddReactions)) {
            return message.reply('<a:NQG_xc126:1255341397981266012> Tôi không có quyền thả cảm xúc vào tin nhắn ở kênh này! <a:NQG_xc126:1255341397981266012>');
        }

        // Lưu kênh vào file data.json
        dataChannel[message.guild.id] = {
            channel: channel.id
        };

        fs.writeFileSync(path.resolve(__dirname, '../../data/data.json'), JSON.stringify(dataChannel));

        return message.reply(`<a:2006pinkflame:1261960949951365212> Bạn đã chọn kênh **${channel.name}** làm kênh chơi nối từ của máy chủ **${message.guild.name}**! <a:2006pinkflame:1261960949951365212>`);
    },
};

// const { PermissionsBitField } = require('discord.js');
// const fs = require('fs');
// const dataChannel = require('../../data/data.json');
// const path = require('path');

// module.exports = {
//     name: 'setnoichu',
//     description: 'Cài đặt kênh chơi nối từ tieng viet tag kenh de setchannel noi chu tieng viet',
//     category: 'Nối chữ',
//     cooldown: 3,
//     aliases: ['noichu'],
//     async execute(message, args) {
//         if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
//             return message.reply('<a:NQG_xc126:1255341397981266012> Bạn cần có quyền Admin để thực hiện thao tác này! <a:NQG_xc126:1255341397981266012>');
//         }

//         const channel = message.mentions.channels.first();

//         if (!channel) {
//             return message.reply('<a:NQG_xc126:1255341397981266012> Vui lòng tag kênh văn bản bạn muốn đặt làm kênh nối chữ. <a:NQG_xc126:1255341397981266012>');
//         }



//         // Check send permission for bot
//         const botPermissions = channel.permissionsFor(message.client.user);
//         if (!botPermissions.has(PermissionsBitField.Flags.ViewChannel)) {
//             return message.reply('<a:NQG_xc126:1255341397981266012> Tôi không có quyền xem kênh này! <a:NQG_xc126:1255341397981266012>');
//         }

//         if (!botPermissions.has(PermissionsBitField.Flags.SendMessages)) {
//             return message.reply('<a:NQG_xc126:1255341397981266012> Tôi không có quyền gửi tin nhắn ở kênh này! <a:NQG_xc126:1255341397981266012>');
//         }

//         if (!botPermissions.has(PermissionsBitField.Flags.AddReactions)) {
//             return message.reply('<a:NQG_xc126:1255341397981266012> Tôi không có quyền thả cảm xúc vào tin nhắn ở kênh này! <a:NQG_xc126:1255341397981266012>');
//         }

//         // check send permission for bot
//         // if (!message.guild.me.permissionsIn(channel).has(PermissionsBitField.Flags.ViewChannel)) {
//         //     return message.reply('Tôi không có quyền xem kênh này!');
//         // }

//         // if (!message.guild.me.permissionsIn(channel).has(PermissionsBitField.Flags.SendMessages)) {
//         //     return message.reply('Tôi không có quyền gửi tin nhắn ở kênh này!');
//         // }

//         // if (!message.guild.me.permissionsIn(channel).has(PermissionsBitField.Flags.AddReactions)) {
//         //     return message.reply('Tôi không có quyền thả cảm xúc vào tin nhắn ở kênh này!');
//         // }

//         dataChannel[message.guild.id] = {
//             channel: channel.id
//         };

//         fs.writeFileSync(path.resolve(__dirname, '../../data/data.json'), JSON.stringify(dataChannel));

//         return message.reply(`<a:2006pinkflame:1261960949951365212> Bạn đã chọn kênh **${channel.name}** làm kênh chơi nối từ của máy chủ **${message.guild.name}**! <a:2006pinkflame:1261960949951365212>`);
//     },
// };
