const { EmbedBuilder } = require('discord.js');
const db = require('../../db/databaseLove');

module.exports = {
  name: 'earn',
  description: 'Kiếm tiền thông qua các hoạt động',
  category: 'Economy',
  cooldown: 3600, // 1 hour cooldown
  async execute(message) {
    const user = message.author;

    // Kiểm tra xem người dùng có đủ điều kiện để kiếm tiền không
    const lastEarned = await getLastEarned(user.id);
    const now = new Date();
    const oneHour = 3600 * 1000;

    if (lastEarned && (now - new Date(lastEarned) < oneHour)) {
      const remainingTime = oneHour - (now - new Date(lastEarned));
      const minutes = Math.floor(remainingTime / 60000);
      const seconds = ((remainingTime % 60000) / 1000).toFixed(0);
      return message.reply(`Bạn chỉ có thể kiếm tiền mỗi giờ một lần. Hãy thử lại sau ${minutes}:${seconds < 10 ? '0' : ''}${seconds} phút.`);
    }

    // Số tiền kiếm được ngẫu nhiên trong khoảng từ 100 đến 500
    const earnedMoney = Math.floor(Math.random() * 401) + 100;

    await updateUserMoney(user.id, earnedMoney);
    await updateLastEarned(user.id);

    const embed = new EmbedBuilder()
      .setColor('#00FF00')
      .setTitle('Kiếm Tiền Thành Công')
      .setDescription(`Bạn đã kiếm được ${earnedMoney} <:xumimi:1261591338290511973>!`)
      .setTimestamp();

    message.channel.send({ embeds: [embed] });
  }
};

const getLastEarned = (userId) => new Promise((resolve, reject) => {
  db.get("SELECT last_earned FROM user_money WHERE user_id = ?", [userId], (err, row) => {
    if (err) return reject(err);
    resolve(row ? row.last_earned : null);
  });
});

const updateUserMoney = (userId, amount) => new Promise((resolve, reject) => {
  db.run("UPDATE user_money SET money = money + ?, last_earned = CURRENT_TIMESTAMP WHERE user_id = ?", [amount, userId], function(err) {
    if (err) return reject(err);
    resolve();
  });
});

const updateLastEarned = (userId) => new Promise((resolve, reject) => {
  db.run("UPDATE user_money SET last_earned = CURRENT_TIMESTAMP WHERE user_id = ?", [userId], function(err) {
    if (err) return reject(err);
    resolve();
  });
});
