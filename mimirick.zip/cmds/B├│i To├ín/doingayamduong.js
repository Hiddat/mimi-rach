const { EmbedBuilder } = require('discord.js');

// Các hàm tính toán chuyển đổi
function jdFromDate(dd, mm, yy) {
    let a = Math.floor((14 - mm) / 12);
    let y = yy + 4800 - a;
    let m = mm + 12 * a - 3;
    let jd = dd + Math.floor((153 * m + 2) / 5) + 365 * y + Math.floor(y / 4) - Math.floor(y / 100) + Math.floor(y / 400) - 32045;
    if (jd < 2299161) {
        jd = dd + Math.floor((153 * m + 2) / 5) + 365 * y + Math.floor(y / 4) - 32083;
    }
    return jd;
}

function getNewMoonDay(k) {
    let T = k / 1236.85;
    let T2 = T * T;
    let T3 = T2 * T;
    let dr = Math.PI / 180;
    let Jd1 = 2415020.75933 + 29.53058868 * k + 0.0001178 * T2 - 0.000000155 * T3;
    Jd1 += 0.00033 * Math.sin((166.56 + 132.87 * T - 0.009173 * T2) * dr);
    let M = 359.2242 + 29.10535608 * k - 0.0000333 * T2 - 0.00000347 * T3;
    let Mpr = 306.0253 + 385.81691806 * k + 0.0107306 * T2 + 0.00001236 * T3;
    let F = 21.2964 + 390.67050646 * k - 0.0016528 * T2 - 0.00000239 * T3;
    let C1 = (0.1734 - 0.000393 * T) * Math.sin(M * dr) + 0.0021 * Math.sin(2 * dr * M);
    C1 -= 0.4068 * Math.sin(Mpr * dr) + 0.0161 * Math.sin(dr * 2 * Mpr);
    C1 -= 0.0004 * Math.sin(dr * 3 * Mpr);
    C1 += 0.0104 * Math.sin(dr * 2 * F) - 0.0051 * Math.sin(dr * (M + Mpr));
    C1 -= 0.0074 * Math.sin(dr * (M - Mpr)) + 0.0004 * Math.sin(dr * (2 * F + M));
    C1 -= 0.0004 * Math.sin(dr * (2 * F - M)) - 0.0006 * Math.sin(dr * (2 * F + Mpr));
    C1 += 0.001 * Math.sin(dr * (2 * F - Mpr)) + 0.0005 * Math.sin(dr * (2 * Mpr + M));
    let deltaT;
    if (T < -11) {
        deltaT = 0.001 + 0.000839 * T + 0.0002261 * T2 - 0.00000845 * T3 - 0.000000081 * T * T3;
    } else {
        deltaT = -0.000278 + 0.000265 * T + 0.000262 * T2;
    }
    let JdNew = Jd1 + C1 - deltaT;
    return Math.floor(JdNew + 0.5 + (7 - 0) / 24);
}

function getSunLongitude(jdn) {
    let T = (jdn - 2451545.0) / 36525;
    let T2 = T * T;
    let dr = Math.PI / 180;
    let M = 357.52910 + 35999.05030 * T - 0.0001559 * T2 - 0.00000048 * T * T2;
    let L0 = 280.46645 + 36000.76983 * T + 0.0003032 * T2;
    let DL = (1.914600 - 0.004817 * T - 0.000014 * T2) * Math.sin(dr * M);
    DL += (0.019993 - 0.000101 * T) * Math.sin(2 * dr * M);
    DL += 0.000290 * Math.sin(3 * dr * M);
    let L = L0 + DL;
    L = L * dr;
    L -= Math.PI * 2 * (Math.floor(L / (Math.PI * 2)));
    return Math.floor(L / Math.PI * 6);
}

function getLunarMonth11(yy, timeZone) {
    let off = jdFromDate(31, 12, yy) - 2415021;
    let k = Math.floor(off / 29.53058867);
    let nm = getNewMoonDay(k);
    let sunLong = getSunLongitude(nm);
    if (sunLong >= 9) {
        nm = getNewMoonDay(k - 1);
    }
    return nm;
}

function getLeapMonthOffset(a11, timeZone) {
    let k = Math.floor((a11 - 2415021.076998695) / 29.53058867 + 0.5);
    let last = 0;
    let i = 1;
    let arc = getSunLongitude(getNewMoonDay(k + i));
    do {
        last = arc;
        i++;
        arc = getSunLongitude(getNewMoonDay(k + i));
    } while (arc != last && i < 14);
    return i - 1;
}

function convertSolarToLunar(dd, mm, yy, timeZone) {
    let dayNumber = jdFromDate(dd, mm, yy);
    let k = Math.floor((dayNumber - 2415021.07699869) / 29.53058867);
    let monthStart = getNewMoonDay(k + 1);
    if (monthStart > dayNumber) {
        monthStart = getNewMoonDay(k);
    }
    let a11 = getLunarMonth11(yy, timeZone);
    let b11 = a11;
    if (a11 >= monthStart) {
        a11 = getLunarMonth11(yy - 1, timeZone);
    } else {
        b11 = getLunarMonth11(yy + 1, timeZone);
    }
    let lunarDay = dayNumber - monthStart + 1;
    let diff = Math.floor((monthStart - a11) / 29);
    let lunarLeap = 0;
    let lunarMonth = diff + 11;
    if (b11 - a11 > 365) {
        let leapMonthDiff = getLeapMonthOffset(a11, timeZone);
        if (diff >= leapMonthDiff) {
            lunarMonth = diff + 10;
            if (diff == leapMonthDiff) {
                lunarLeap = 1;
            }
        }
    }
    if (lunarMonth > 12) {
        lunarMonth -= 12;
    }
    if (lunarMonth >= 11 && diff < 4) {
        lunarYear = yy - 1;
    } else {
        lunarYear = yy;
    }
    return [lunarDay, lunarMonth, lunarYear, lunarLeap];
}

function getCanChi(day, month, year) {
    const CAN = ["Giáp", "Ất", "Bính", "Đinh", "Mậu", "Kỷ", "Canh", "Tân", "Nhâm", "Quý"];
    const CHI = ["Tý", "Sửu", "Dần", "Mão", "Thìn", "Tỵ", "Ngọ", "Mùi", "Thân", "Dậu", "Tuất", "Hợi"];
    const canYear = CAN[year % 10];
    const chiYear = CHI[year % 12];
    const canMonth = CAN[(year * 12 + month + 3) % 10];
    const chiMonth = CHI[(month + 1) % 12];
    const canDay = CAN[(day + 9) % 10];
    const chiDay = CHI[(day + 1) % 12];
    return [canDay, chiDay, canMonth, chiMonth, canYear, chiYear];
}

module.exports = {
    name: 'doingayamduong',
    description: 'Đổi ngày dương lịch sang ngày âm lịch (dd/mm/yy).',
    category: 'Bói Toán',
    aliases: ['dnad'],
    cooldown: 6,
    async execute(message, args) { 
        if (!args.length) {
            return message.reply('Vui lòng cung cấp ngày dương lịch (dd/mm/yy).');
        }

        const dateString = args[0];
        const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;

        if (!datePattern.test(dateString)) {
            return message.reply('Định dạng ngày không hợp lệ. Vui lòng nhập ngày theo định dạng dd/mm/yy.');
        }

        const [_, day, month, year] = dateString.match(datePattern);

        // Chuyển đổi ngày dương sang ngày âm
        const [lunarDay, lunarMonth, lunarYear, lunarLeap] = convertSolarToLunar(parseInt(day), parseInt(month), parseInt(year), 7);
        const [canDay, chiDay, canMonth, chiMonth, canYear, chiYear] = getCanChi(lunarDay, lunarMonth, lunarYear);

        const lunarDateString = `Ngày ${canDay} ${chiDay}, Tháng ${canMonth} ${chiMonth}, Năm ${canYear} ${chiYear}`;

        const embed = new EmbedBuilder()
            .setTitle('Chuyển đổi ngày dương lịch sang ngày âm lịch')
            .setColor(0xFF69B4)
            .setDescription(`Ngày dương lịch: **${day}/${month}/${year}**\nNgày âm lịch: **${lunarDay}/${lunarMonth}/${lunarYear}**\n${lunarDateString}`)
            .setFooter({ text: `Yêu cầu bởi ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
            .setTimestamp();

        message.reply({ embeds: [embed] });
    },
};
