const { EmbedBuilder } = require('discord.js');

function getZodiacSign(day, month) {
    const zodiacs = [
        { name: '♈ Bạch Dương', start: '21/03', end: '19/04', symbol: '♈', description: 'Bạch Dương là người mạnh mẽ, năng động và quyết đoán. Họ luôn sẵn sàng đối mặt với thử thách và không ngại gian khổ.', traits: 'Tính cách: Nhiệt huyết, thẳng thắn, bốc đồng.\nMọi thứ về Bạch Dương: Họ luôn tìm kiếm sự thử thách và không ngại đối mặt với khó khăn. Bạch Dương có thể rất nóng tính nhưng cũng rất nhanh nguội.', longitude: '0° - 30°', thumbnail: 'https://cdn2.fptshop.com.vn/unsafe/Uploads/images/tin-tuc/168770/Originals/12-cung-hoang-dao-anime-4.jpg' },
        { name: '♉ Kim Ngưu', start: '20/04', end: '20/05', symbol: '♉', description: 'Kim Ngưu là người kiên định, thực tế và đáng tin cậy. Họ luôn tìm kiếm sự ổn định và cảm giác an toàn trong cuộc sống.', traits: 'Tính cách: Kiên định, thực tế, đáng tin cậy.\nMọi thứ về Kim Ngưu: Họ yêu thích sự ổn định và luôn tìm kiếm cảm giác an toàn trong mọi việc. Kim Ngưu rất trung thành và có thể dựa vào.', longitude: '30° - 60°', thumbnail: 'https://cdn2.fptshop.com.vn/unsafe/Uploads/images/tin-tuc/168770/Originals/12-cung-hoang-dao-anime-9.jpg' },
        { name: '♊ Song Tử', start: '21/05', end: '20/06', symbol: '♊', description: 'Song Tử là người thông minh, linh hoạt và năng động. Họ luôn thích khám phá và tìm hiểu những điều mới mẻ.', traits: 'Tính cách: Thông minh, linh hoạt, năng động.\nMọi thứ về Song Tử: Họ rất thích giao tiếp và thường xuyên thay đổi ý kiến. Song Tử rất linh hoạt và thích nghi nhanh chóng với môi trường xung quanh.', longitude: '60° - 90°', thumbnail: 'https://cdn2.fptshop.com.vn/unsafe/Uploads/images/tin-tuc/168770/Originals/12-cung-hoang-dao-anime-12.jpg' },
        { name: '♋ Cự Giải', start: '21/06', end: '22/07', symbol: '♋', description: 'Cự Giải là người nhạy cảm, tình cảm và bảo vệ. Họ luôn quan tâm và chăm sóc cho những người xung quanh.', traits: 'Tính cách: Nhạy cảm, tình cảm, bảo vệ.\nMọi thứ về Cự Giải: Họ rất quan tâm đến gia đình và bạn bè. Cự Giải có thể rất nhạy cảm và dễ bị tổn thương, nhưng họ cũng rất mạnh mẽ khi cần bảo vệ những người mình yêu thương.', longitude: '90° - 120°', thumbnail: 'https://cdn2.fptshop.com.vn/unsafe/Uploads/images/tin-tuc/168770/Originals/12-cung-hoang-dao-anime-20.jpg' },
        { name: '♌ Sư Tử', start: '23/07', end: '22/08', symbol: '♌', description: 'Sư Tử là người tự tin, mạnh mẽ và quyết đoán. Họ luôn tỏa sáng và thu hút sự chú ý từ mọi người.', traits: 'Tính cách: Tự tin, mạnh mẽ, quyết đoán.\nMọi thứ về Sư Tử: Họ thích được tôn vinh và luôn muốn trở thành trung tâm của sự chú ý. Sư Tử có tấm lòng hào phóng và luôn sẵn sàng giúp đỡ người khác.', longitude: '120° - 150°', thumbnail: 'https://cdn2.fptshop.com.vn/unsafe/Uploads/images/tin-tuc/168770/Originals/12-cung-hoang-dao-anime-25.jpg' },
        { name: '♍ Xử Nữ', start: '23/08', end: '22/09', symbol: '♍', description: 'Xử Nữ là người tỉ mỉ, chu đáo và tận tâm. Họ luôn cẩn trọng và tỉ mỉ trong mọi việc mình làm.', traits: 'Tính cách: Tỉ mỉ, chu đáo, tận tâm.\nMọi thứ về Xử Nữ: Họ luôn chú trọng đến từng chi tiết và luôn nỗ lực để hoàn thiện mọi thứ. Xử Nữ rất trung thực và đáng tin cậy.', longitude: '150° - 180°', thumbnail: 'https://cdn2.fptshop.com.vn/unsafe/Uploads/images/tin-tuc/168770/Originals/12-cung-hoang-dao-anime-30.jpg' },
        { name: '♎ Thiên Bình', start: '23/09', end: '22/10', symbol: '♎', description: 'Thiên Bình là người công bằng, hòa nhã và yêu thích sự hài hòa. Họ luôn tìm kiếm sự cân bằng và hòa hợp trong các mối quan hệ.', traits: 'Tính cách: Công bằng, hòa nhã, yêu thích sự hài hòa.\nMọi thứ về Thiên Bình: Họ luôn tìm kiếm sự cân bằng trong mọi việc và rất giỏi trong việc giải quyết xung đột. Thiên Bình có khả năng giao tiếp tốt và luôn cố gắng giữ hòa khí.', longitude: '180° - 210°', thumbnail: 'https://cdn2.fptshop.com.vn/unsafe/Uploads/images/tin-tuc/168770/Originals/12-cung-hoang-dao-anime-34.jpg' },
        { name: '♏ Bọ Cạp', start: '23/10', end: '21/11', symbol: '♏', description: 'Bọ Cạp là người quyết đoán, mạnh mẽ và đam mê. Họ luôn kiên định và không dễ bị lung lay.', traits: 'Tính cách: Quyết đoán, mạnh mẽ, đam mê.\nMọi thứ về Bọ Cạp: Họ rất kiên định và không dễ bị lung lay trong quyết định của mình. Bọ Cạp có khả năng kiểm soát tốt cảm xúc và luôn tìm kiếm sự thật.', longitude: '210° - 240°', thumbnail: 'https://cdn2.fptshop.com.vn/unsafe/Uploads/images/tin-tuc/168770/Originals/12-cung-hoang-dao-anime-40.jpg' },
        { name: '♐ Nhân Mã', start: '22/11', end: '21/12', symbol: '♐', description: 'Nhân Mã là người lạc quan, vui vẻ và yêu tự do. Họ luôn tìm kiếm những cuộc phiêu lưu và trải nghiệm mới.', traits: 'Tính cách: Lạc quan, vui vẻ, yêu tự do.\nMọi thứ về Nhân Mã: Họ rất thích khám phá và luôn tìm kiếm những trải nghiệm mới mẻ. Nhân Mã rất lạc quan và luôn nhìn vào mặt tích cực của cuộc sống.', longitude: '240° - 270°', thumbnail: 'https://cdn2.fptshop.com.vn/unsafe/Uploads/images/tin-tuc/168770/Originals/12-cung-hoang-dao-anime-43.jpg' },
        { name: '♑ Ma Kết', start: '22/12', end: '19/01', symbol: '♑', description: 'Ma Kết là người kiên định, có trách nhiệm và tham vọng. Họ luôn nỗ lực để đạt được mục tiêu của mình.', traits: 'Tính cách: Kiên định, có trách nhiệm, tham vọng.\nMọi thứ về Ma Kết: Họ rất kiên định và không ngừng nỗ lực để đạt được mục tiêu của mình. Ma Kết rất có trách nhiệm và luôn hoàn thành tốt công việc của mình.', longitude: '270° - 300°', thumbnail: 'https://cdn2.fptshop.com.vn/unsafe/Uploads/images/tin-tuc/168770/Originals/12-cung-hoang-dao-anime-50.jpg' },
        { name: '♒ Bảo Bình', start: '20/01', end: '18/02', symbol: '♒', description: 'Bảo Bình là người sáng tạo, độc lập và nhân ái. Họ luôn nghĩ khác biệt và tìm cách làm mới mọi thứ.', traits: 'Tính cách: Sáng tạo, độc lập, nhân ái.\nMọi thứ về Bảo Bình: Họ luôn nghĩ khác biệt và tìm cách làm mới mọi thứ. Bảo Bình rất nhân ái và luôn quan tâm đến cộng đồng.', longitude: '300° - 330°', thumbnail: 'https://cdn2.fptshop.com.vn/unsafe/Uploads/images/tin-tuc/168770/Originals/12-cung-hoang-dao-anime-53.jpg' },
        { name: '♓ Song Ngư', start: '19/02', end: '20/03', symbol: '♓', description: 'Song Ngư là người nhạy cảm, tình cảm và sáng tạo. Họ luôn mơ mộng và có trí tưởng tượng phong phú.', traits: 'Tính cách: Nhạy cảm, tình cảm, sáng tạo.\nMọi thứ về Song Ngư: Họ rất nhạy cảm và có trí tưởng tượng phong phú. Song Ngư rất tình cảm và luôn quan tâm đến người khác.', longitude: '330° - 360°', thumbnail: 'https://cdn2.fptshop.com.vn/unsafe/Uploads/images/tin-tuc/168770/Originals/12-cung-hoang-dao-anime-55.jpg' }
    ];

    const date = new Date(`${month}/${day}/2000`); // Năm không quan trọng, chỉ cần xác định ngày và tháng
    for (const zodiac of zodiacs) {
        const [startDay, startMonth] = zodiac.start.split('/');
        const [endDay, endMonth] = zodiac.end.split('/');
        const startDate = new Date(`${startMonth}/${startDay}/2000`);
        const endDate = new Date(`${endMonth}/${endDay}/2000`);

        if ((date >= startDate && date <= endDate) || (startMonth === '12' && endMonth === '01' && (date >= startDate || date <= endDate))) {
            return zodiac;
        }
    }
    return null;
}

module.exports = {
    name: 'hoangdao',
    description: 'Đưa ra thông tin hoàng đạo về một ngày bất kì! (dd/mm).',
    category: 'Bói Toán',
    aliases: ['hd'],
    cooldown: 6,
    async execute(message, args) { 
        if (args.length === 0) {
            return message.reply('Vui lòng cung cấp ngày tháng (dd/mm) để kiểm tra cung hoàng đạo.');
        }

        const dateString = args[0];
        const datePattern = /^(\d{2})\/(\d{2})$/;

        if (!datePattern.test(dateString)) {
            return message.reply('Định dạng ngày không hợp lệ. Vui lòng nhập ngày theo định dạng dd/mm.');
        }

        const [_, day, month] = dateString.match(datePattern);
        const zodiacSign = getZodiacSign(parseInt(day), parseInt(month));

        if (!zodiacSign) {
            return message.reply('Không tìm thấy cung hoàng đạo cho ngày tháng này.');
        }

        const embed = new EmbedBuilder()
            .setTitle(`Cung hoàng đạo: ${zodiacSign.name}`)
            .setColor(0xFF69B4)
            .setDescription(zodiacSign.description)
            .addFields(
                { name: 'Ngày sinh', value: `${day}/${month}` },
                { name: 'Thời gian', value: `${zodiacSign.start} - ${zodiacSign.end}` },
                { name: 'Kinh độ Hoàng đạo', value: zodiacSign.longitude },
                { name: 'Đặc điểm', value: zodiacSign.traits }
            )
            .setThumbnail(zodiacSign.thumbnail)
            .setFooter({ text: `Yêu cầu bởi ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
            .setTimestamp();

        await message.channel.send({ embeds: [embed] });
    },
};
