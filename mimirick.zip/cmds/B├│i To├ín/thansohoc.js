const { EmbedBuilder } = require('discord.js');

function calculateLifePathNumber(day, month, year) {
    const sum = (num) => num.toString().split('').reduce((acc, val) => acc + parseInt(val), 0);

    let lifePathNumber = sum(day) + sum(month) + sum(year);

    while (lifePathNumber > 9 && ![11, 22, 33].includes(lifePathNumber)) {
        lifePathNumber = sum(lifePathNumber);
    }

    return lifePathNumber;
}

function getLifePathMeaning(number) {
    const meanings = {
        1: {
            title: "Con số chủ đạo 1",
            purpose: "Người có con số chủ đạo 1 thường có sự tự tin, độc lập và khát khao lãnh đạo. Họ là những người tiên phong, không ngại thử thách và luôn muốn đứng đầu trong mọi lĩnh vực.",
            bestExpression: "Họ thể hiện tốt nhất khi được tự do hành động và quyết định, không bị ràng buộc bởi quy tắc hay áp lực từ người khác. Sự sáng tạo và độc đáo giúp họ nổi bật trong công việc.",
            highlight: "Khả năng lãnh đạo thiên bẩm, sáng tạo và có tầm nhìn chiến lược. Họ thường tạo ra những ý tưởng đột phá và dẫn dắt nhóm đi đến thành công.",
            weaknesses: "Đôi khi họ có thể trở nên kiêu ngạo, cứng đầu và khó làm việc nhóm. Sự độc lập quá mức có thể khiến họ cảm thấy cô đơn.",
            solution: "Học cách lắng nghe và tôn trọng ý kiến của người khác, đồng thời phát triển kỹ năng làm việc nhóm để đạt được thành công toàn diện.",
            career: "Nhà lãnh đạo, doanh nhân, nghệ sĩ, nhà phát minh, nhà tư tưởng sáng tạo.",
            summary: "Những người mang con số chủ đạo 1 là những cá nhân mạnh mẽ, độc lập và sáng tạo. Họ luôn tiên phong trong mọi lĩnh vực và không ngại đối mặt với thử thách để đạt được mục tiêu."
        },
        2: {
            title: "Con số chủ đạo 2",
            purpose: "Người có con số chủ đạo 2 thường tìm kiếm sự hòa hợp, cân bằng và hợp tác. Họ là những người làm việc nhóm xuất sắc, luôn biết cách kết nối và xây dựng mối quan hệ tốt đẹp.",
            bestExpression: "Họ thể hiện tốt nhất trong môi trường làm việc nhóm, nơi họ có thể đóng vai trò là người hòa giải, kết nối các thành viên và duy trì sự cân bằng.",
            highlight: "Khả năng hòa giải, làm việc nhóm và duy trì mối quan hệ tốt. Họ thường là người đứng sau thành công của nhóm, hỗ trợ và thúc đẩy người khác.",
            weaknesses: "Dễ bị phụ thuộc vào người khác và thiếu tự tin khi đứng một mình. Họ có thể gặp khó khăn trong việc đưa ra quyết định và tự lập.",
            solution: "Phát triển sự tự tin và khả năng quyết định độc lập. Học cách đứng vững trước áp lực và không quá phụ thuộc vào người khác.",
            career: "Nhà ngoại giao, giáo viên, nhà tư vấn, nhân viên xã hội, chuyên viên HR.",
            summary: "Những người mang con số chủ đạo 2 là những cá nhân hòa đồng, cân bằng và hợp tác. Họ xuất sắc trong việc làm việc nhóm và duy trì mối quan hệ tốt đẹp với mọi người xung quanh."
        },
        3: {
            title: "Con số chủ đạo 3",
            purpose: "Người có con số chủ đạo 3 thường có khả năng giao tiếp tốt, sáng tạo và vui vẻ. Họ yêu thích cuộc sống, luôn mang lại niềm vui và năng lượng tích cực cho những người xung quanh.",
            bestExpression: "Họ thể hiện tốt nhất khi được tự do biểu đạt cảm xúc và ý tưởng của mình. Môi trường sáng tạo, nghệ thuật là nơi họ tỏa sáng.",
            highlight: "Khả năng giao tiếp, sáng tạo và sự vui vẻ. Họ thường là tâm điểm của các cuộc trò chuyện, luôn mang lại tiếng cười và niềm vui.",
            weaknesses: "Dễ bị phân tán, thiếu kiên nhẫn và không ổn định. Họ có thể gặp khó khăn trong việc tập trung vào một mục tiêu dài hạn.",
            solution: "Học cách kiên nhẫn, tập trung và lập kế hoạch cụ thể để đạt được mục tiêu dài hạn.",
            career: "Nghệ sĩ, nhà văn, diễn viên, nhà thiết kế, người dẫn chương trình.",
            summary: "Những người mang con số chủ đạo 3 là những cá nhân sáng tạo, vui vẻ và giao tiếp tốt. Họ luôn mang lại niềm vui và năng lượng tích cực cho mọi người xung quanh."
        },
        4: {
            title: "Con số chủ đạo 4",
            purpose: "Người có con số chủ đạo 4 thường có tính cách thực tế, kỷ luật và đáng tin cậy. Họ luôn nỗ lực làm việc chăm chỉ và có trách nhiệm cao.",
            bestExpression: "Họ thể hiện tốt nhất trong môi trường có cấu trúc và quy tắc rõ ràng, nơi họ có thể sử dụng khả năng tổ chức và lập kế hoạch của mình.",
            highlight: "Khả năng tổ chức, lập kế hoạch và làm việc chăm chỉ. Họ là những người có thể hoàn thành công việc một cách hiệu quả và đáng tin cậy.",
            weaknesses: "Đôi khi họ có thể trở nên cứng nhắc và thiếu linh hoạt, khó thích nghi với những thay đổi đột ngột.",
            solution: "Học cách linh hoạt và cởi mở hơn với những thay đổi. Phát triển khả năng tư duy sáng tạo để giải quyết vấn đề.",
            career: "Kỹ sư, quản lý dự án, nhân viên hành chính, kế toán.",
            summary: "Những người mang con số chủ đạo 4 là những cá nhân thực tế, kỷ luật và đáng tin cậy. Họ luôn làm việc chăm chỉ và có khả năng tổ chức xuất sắc."
        },
        5: {
            title: "Con số chủ đạo 5",
            purpose: "Người có con số chủ đạo 5 thường yêu thích sự tự do, phiêu lưu và thay đổi. Họ luôn tìm kiếm những trải nghiệm mới mẻ và không ngại thử thách bản thân.",
            bestExpression: "Họ thể hiện tốt nhất khi được tự do khám phá và trải nghiệm những điều mới mẻ, không bị ràng buộc bởi quy tắc hay hạn chế.",
            highlight: "Khả năng thích nghi, sự linh hoạt và tính cách phiêu lưu. Họ luôn tìm kiếm sự mới mẻ và không ngừng khám phá.",
            weaknesses: "Dễ bị phân tán, thiếu kiên nhẫn và không ổn định. Họ có thể gặp khó khăn trong việc duy trì một công việc hay mục tiêu dài hạn.",
            solution: "Học cách kiên nhẫn, tập trung và lập kế hoạch cụ thể để đạt được mục tiêu dài hạn. Phát triển khả năng kiềm chế và kiểm soát cảm xúc.",
            career: "Nhà báo, nhà du lịch, diễn viên, nhà sáng tạo nội dung.",
            summary: "Những người mang con số chủ đạo 5 là những cá nhân yêu thích sự tự do, phiêu lưu và thay đổi. Họ luôn tìm kiếm những trải nghiệm mới mẻ và không ngại thử thách bản thân."
        },
        6: {
            title: "Con số chủ đạo 6",
            purpose: "Người có con số chủ đạo 6 thường có lòng yêu thương, sự quan tâm và trách nhiệm với gia đình và cộng đồng. Họ luôn tìm kiếm sự hòa hợp và cân bằng trong cuộc sống.",
            bestExpression: "Họ thể hiện tốt nhất khi được chăm sóc và giúp đỡ người khác, tạo ra môi trường sống hòa hợp và ấm áp.",
            highlight: "Khả năng chăm sóc, lòng yêu thương và trách nhiệm. Họ luôn sẵn sàng giúp đỡ người khác và tạo ra môi trường sống tích cực.",
            weaknesses: "Dễ bị phụ thuộc vào người khác và thiếu tự tin khi đứng một mình. Họ có thể gặp khó khăn trong việc đưa ra quyết định và tự lập.",
            solution: "Phát triển sự tự tin và khả năng quyết định độc lập. Học cách đứng vững trước áp lực và không quá phụ thuộc vào người khác.",
            career: "Giáo viên, y tá, nhân viên xã hội, chuyên viên HR.",
            summary: "Những người mang con số chủ đạo 6 là những cá nhân yêu thương, quan tâm và trách nhiệm. Họ luôn tìm kiếm sự hòa hợp và cân bằng trong cuộc sống."
        },
        7: {
            title: "Con số chủ đạo 7",
            purpose: "Người có con số chủ đạo 7 thường có sự tìm kiếm tri thức, sự hiểu biết và sự phát triển tâm linh. Họ luôn tìm kiếm sự thật và sự hiểu biết sâu sắc về cuộc sống.",
            bestExpression: "Họ thể hiện tốt nhất khi được tự do khám phá và nghiên cứu các lĩnh vực mà họ quan tâm, không bị ràng buộc bởi quy tắc hay hạn chế.",
            highlight: "Khả năng tư duy sâu sắc, sự thông minh và sự phát triển tâm linh. Họ luôn tìm kiếm sự thật và sự hiểu biết sâu sắc về cuộc sống.",
            weaknesses: "Đôi khi họ có thể trở nên quá lý trí, thiếu cảm xúc và khó gần gũi. Sự tìm kiếm sự thật có thể khiến họ cảm thấy cô đơn và tách biệt.",
            solution: "Học cách cân bằng giữa lý trí và cảm xúc. Phát triển khả năng giao tiếp và kết nối với người khác để có cuộc sống hài hòa hơn.",
            career: "Nhà nghiên cứu, triết gia, nhà khoa học, nhà tâm linh.",
            summary: "Những người mang con số chủ đạo 7 là những cá nhân thông minh, tư duy sâu sắc và có sự phát triển tâm linh. Họ luôn tìm kiếm sự thật và sự hiểu biết sâu sắc về cuộc sống."
        },
        8: {
            title: "Con số chủ đạo 8",
            purpose: "Người có con số chủ đạo 8 thường tìm kiếm sự thành công, quyền lực và sự giàu có. Họ luôn nỗ lực để đạt được mục tiêu và khát khao xây dựng sự nghiệp vững chắc.",
            bestExpression: "Họ thể hiện tốt nhất trong môi trường cạnh tranh, nơi họ có thể phát huy khả năng lãnh đạo và sự quyết đoán của mình.",
            highlight: "Khả năng lãnh đạo, sự quyết đoán và tham vọng. Họ luôn nỗ lực để đạt được mục tiêu và khát khao xây dựng sự nghiệp vững chắc.",
            weaknesses: "Đôi khi họ có thể trở nên quá tham vọng, cứng nhắc và thiếu cảm xúc. Sự tập trung vào công việc có thể khiến họ bỏ qua các mối quan hệ cá nhân.",
            solution: "Học cách cân bằng giữa công việc và cuộc sống cá nhân. Phát triển khả năng cảm thông và giao tiếp để duy trì mối quan hệ tốt đẹp.",
            career: "Doanh nhân, nhà quản lý, luật sư, nhà đầu tư.",
            summary: "Những người mang con số chủ đạo 8 là những cá nhân tham vọng, quyết đoán và có khả năng lãnh đạo. Họ luôn nỗ lực để đạt được mục tiêu và xây dựng sự nghiệp vững chắc."
        },
        9: {
            title: "Con số chủ đạo 9",
            purpose: "Người có con số chủ đạo 9 thường có lòng nhân ái, sự bao dung và tinh thần vị tha. Họ luôn tìm kiếm cách giúp đỡ và cống hiến cho cộng đồng.",
            bestExpression: "Họ thể hiện tốt nhất khi được tham gia vào các hoạt động từ thiện, giúp đỡ người khác và tạo ra sự thay đổi tích cực trong cộng đồng.",
            highlight: "Lòng nhân ái, sự bao dung và tinh thần vị tha. Họ luôn tìm kiếm cách giúp đỡ và cống hiến cho cộng đồng.",
            weaknesses: "Đôi khi họ có thể trở nên quá nhạy cảm, dễ bị tổn thương và thiếu kiên nhẫn. Sự vị tha quá mức có thể khiến họ quên đi nhu cầu của bản thân.",
            solution: "Học cách cân bằng giữa việc giúp đỡ người khác và chăm sóc bản thân. Phát triển sự kiên nhẫn và khả năng tự bảo vệ trước những tình huống khó khăn.",
            career: "Nhân viên xã hội, y tá, giáo viên, nhà hoạt động từ thiện.",
            summary: "Những người mang con số chủ đạo 9 là những cá nhân nhân ái, bao dung và vị tha. Họ luôn tìm kiếm cách giúp đỡ và cống hiến cho cộng đồng."
        },
        11: {
            title: "Con số chủ đạo 11",
            purpose: "Người có con số chủ đạo 11 thường có trực giác mạnh mẽ, khả năng tâm linh và tầm nhìn xa. Họ luôn tìm kiếm sự hiểu biết sâu sắc và sự kết nối với tâm linh.",
            bestExpression: "Họ thể hiện tốt nhất khi được tự do khám phá và phát triển khả năng tâm linh của mình. Môi trường tĩnh lặng và sâu sắc là nơi họ tỏa sáng.",
            highlight: "Trực giác mạnh mẽ, khả năng tâm linh và tầm nhìn xa. Họ luôn tìm kiếm sự hiểu biết sâu sắc và sự kết nối với tâm linh.",
            weaknesses: "Đôi khi họ có thể trở nên quá nhạy cảm, dễ bị tổn thương và thiếu kiên nhẫn. Sự tìm kiếm tâm linh có thể khiến họ cảm thấy cô đơn và tách biệt.",
            solution: "Học cách cân bằng giữa cuộc sống thực tế và tâm linh. Phát triển khả năng tự bảo vệ và kiên nhẫn để đối mặt với những thử thách.",
            career: "Nhà tâm linh, nhà nghiên cứu, triết gia, nhà văn.",
            summary: "Những người mang con số chủ đạo 11 là những cá nhân có trực giác mạnh mẽ, khả năng tâm linh và tầm nhìn xa. Họ luôn tìm kiếm sự hiểu biết sâu sắc và sự kết nối với tâm linh."
        },
        22: {
            title: "Con số chủ đạo 22",
            purpose: "Người có con số chủ đạo 22 thường có khả năng biến ước mơ thành hiện thực, xây dựng những dự án lớn và có tầm ảnh hưởng. Họ luôn tìm kiếm cách để tạo ra sự thay đổi tích cực trong thế giới.",
            bestExpression: "Họ thể hiện tốt nhất khi được tự do sáng tạo và xây dựng những dự án lớn. Môi trường cạnh tranh và thử thách là nơi họ tỏa sáng.",
            highlight: "Khả năng biến ước mơ thành hiện thực, xây dựng những dự án lớn và có tầm ảnh hưởng. Họ luôn tìm kiếm cách để tạo ra sự thay đổi tích cực trong thế giới.",
            weaknesses: "Đôi khi họ có thể trở nên quá tham vọng, cứng nhắc và thiếu cảm xúc. Sự tập trung vào công việc có thể khiến họ bỏ qua các mối quan hệ cá nhân.",
            solution: "Học cách cân bằng giữa công việc và cuộc sống cá nhân. Phát triển khả năng cảm thông và giao tiếp để duy trì mối quan hệ tốt đẹp.",
            career: "Doanh nhân, nhà quản lý, kiến trúc sư, nhà đầu tư.",
            summary: "Những người mang con số chủ đạo 22 là những cá nhân có khả năng biến ước mơ thành hiện thực, xây dựng những dự án lớn và có tầm ảnh hưởng. Họ luôn tìm kiếm cách để tạo ra sự thay đổi tích cực trong thế giới."
        },
        33: {
            title: "Con số chủ đạo 33",
            purpose: "Người có con số chủ đạo 33 thường có lòng yêu thương vô điều kiện, sự bao dung và tinh thần phục vụ. Họ luôn tìm kiếm cách để giúp đỡ và cống hiến cho cộng đồng.",
            bestExpression: "Họ thể hiện tốt nhất khi được tham gia vào các hoạt động từ thiện, giúp đỡ người khác và tạo ra sự thay đổi tích cực trong cộng đồng.",
            highlight: "Lòng yêu thương vô điều kiện, sự bao dung và tinh thần phục vụ. Họ luôn tìm kiếm cách để giúp đỡ và cống hiến cho cộng đồng.",
            weaknesses: "Đôi khi họ có thể trở nên quá nhạy cảm, dễ bị tổn thương và thiếu kiên nhẫn. Sự phục vụ quá mức có thể khiến họ quên đi nhu cầu của bản thân.",
            solution: "Học cách cân bằng giữa việc giúp đỡ người khác và chăm sóc bản thân. Phát triển sự kiên nhẫn và khả năng tự bảo vệ trước những tình huống khó khăn.",
            career: "Nhân viên xã hội, y tá, giáo viên, nhà hoạt động từ thiện.",
            summary: "Những người mang con số chủ đạo 33 là những cá nhân có lòng yêu thương vô điều kiện, sự bao dung và tinh thần phục vụ. Họ luôn tìm kiếm cách để giúp đỡ và cống hiến cho cộng đồng."
        }
    };
    return meanings[number] || {
        title: "Không tìm thấy ý nghĩa cho con số chủ đạo này.",
        purpose: "",
        bestExpression: "",
        highlight: "",
        weaknesses: "",
        solution: "",
        career: "",
        summary: ""
    };
}

module.exports = {
    name: 'thansohoc',
    description: 'Xem ý nghĩa con số chủ đạo của một ngày sinh (dd/mm/yy).',
    category: 'Bói Toán',
    cooldown: 6,
    aliases: ['tsh'],
    async execute(message, args) {
        if (!args.length) {
            return message.reply('Vui lòng cung cấp ngày tháng năm sinh (dd/mm/yy).');
        }

        const dateString = args[0];
        const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;

        if (!datePattern.test(dateString)) {
            return message.reply('Định dạng ngày không hợp lệ. Vui lòng nhập ngày theo định dạng dd/mm/yy.');
        }

        const [_, day, month, year] = dateString.match(datePattern);

        // Tính toán con số chủ đạo
        const lifePathNumber = calculateLifePathNumber(parseInt(day), parseInt(month), parseInt(year));
        const lifePathMeaning = getLifePathMeaning(lifePathNumber);

        const embed1 = new EmbedBuilder()
            .setTitle(`${lifePathMeaning.title}`)
            .setColor(0xFF69B4)
            .setDescription(`Ngày sinh: **${day}/${month}/${year}**\n`)
            .addFields(
                { name: '<:1_:1257549823767216178> Mục đích sống', value: lifePathMeaning.purpose },
                { name: '<:2_:1257549815773003859> Thể hiện tốt nhất', value: lifePathMeaning.bestExpression },
                { name: '<:3_:1257549813730250913> Nổi bật', value: lifePathMeaning.highlight },
                { name: '<:4_:1257549811524308992> Nhược điểm', value: lifePathMeaning.weaknesses },
                { name: '<:5_:1257549809091608586> Hướng giải quyết', value: lifePathMeaning.solution },
                { name: '<:6_:1257549806717370379> Nghề nghiệp', value: lifePathMeaning.career },
                { name: '<a:tick:1254376731356430361> Tổng kết', value: lifePathMeaning.summary }
            )
            .setFooter({ text: `Yêu cầu bởi ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
            .setTimestamp();
        await message.channel.send({ embeds: [embed1] });
    },
};
