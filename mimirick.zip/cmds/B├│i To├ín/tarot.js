const { EmbedBuilder } = require('discord.js');
const tarotCards = require('../../data/tarotCards.json');

module.exports = {
    name: 'tarot',
    description: 'Chọn ngẫu nhiên 1 lá bài từ bộ Rider Waite Tarot và đưa ra ý nghĩa! Nhập thêm ký tự r phía sau để chọn cả lá ngược.',
    category: 'Bói Toán',
    aliases: ['tr'],
    cooldown: 6,
    async execute(message, args) {
        const randomCardIndex = Math.floor(Math.random() * tarotCards.length);
        const card = tarotCards[randomCardIndex];
        const isReversed = args[0] && args[0].toLowerCase() === 'r';
        const cardData = isReversed ? card.reversed : card;

        const embed = new EmbedBuilder()
            .setTitle(`Lá bài: ${card.name} ${isReversed ? '(Ngược)' : ''}`)
            .setColor(0xFF69B4)
            .setDescription(cardData.description)
            .addFields(
                { name: 'Từ khóa', value: cardData.keywords.join(', '), inline: false },
                { name: 'Ý nghĩa', value: cardData.meaning, inline: false }
            )
            .setImage(card.image)
            .setFooter({ text: `Yêu cầu bởi ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
            .setTimestamp();

        await message.channel.send({ embeds: [embed] });
    },
};
