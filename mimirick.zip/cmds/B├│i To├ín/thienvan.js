const { EmbedBuilder } = require('discord.js');
const axios = require('axios');
const moment = require('moment');
const NASA_API_KEY = 'qu26rLVx3STbdWJvZuKhua3YyjMqKZirYU3dKdzJ';

module.exports = {
    name: 'thienvan',
    description: 'Xem một bức ảnh thiên văn của một ngày bất kì cung cấp bởi NASA',
    category: 'Bói Toán',
    aliases: ['apod'],
    cooldown: 6,
    async execute(message, args) {
        if (!args.length) {
            return message.reply('Vui lòng cung cấp ngày theo định dạng dd/mm/yyyy.');
        }

        const inputDate = args[0];
        const dateFormat = 'DD/MM/YYYY';
        if (!moment(inputDate, dateFormat, true).isValid()) {
            return message.reply('Định dạng ngày không hợp lệ. Vui lòng sử dụng định dạng dd/mm/yyyy.');
        }

        const formattedDate = moment(inputDate, dateFormat).format('YYYY-MM-DD');

        try {
            const response = await axios.get(`https://api.nasa.gov/planetary/apod?date=${formattedDate}&api_key=${NASA_API_KEY}`);
            const { title, explanation, url, hdurl, date } = response.data;

            const embed = new EmbedBuilder()
                .setColor('#FF69B4')
                .setTitle(title)
                .setDescription(explanation)
                .setImage(hdurl || url)
                .setFooter({ text: `Ngày: ${date}` })
                .setTimestamp();

            message.reply({ embeds: [embed] });
        } catch (error) {
            console.error('Error fetching data from NASA API:', error);
            message.reply('Đã xảy ra lỗi khi lấy dữ liệu từ NASA. Vui lòng thử lại sau.');
        }
    },
};
