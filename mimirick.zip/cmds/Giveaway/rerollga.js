const { EmbedBuilder, WebhookClient, PermissionsBitField } = require('discord.js');
const dataBetaDev = require('../../db/databaseBetaDev');

module.exports = {
    name: 'rerollga',
    description: 'Reroll một giveaway đã kết thúc.',
    cooldown: 0,
    category: 'Giveaway',
    async execute(message, args) {
        // if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
        //     return message.reply('Bạn không có quyền sử dụng lệnh này.');
        // }

        const messageId = args[0];
        if (!messageId) {
            return message.reply('Vui lòng cung cấp ID của tin nhắn giveaway.');
        }

        try {
            const giveaway = await new Promise((resolve, reject) => {
                dataBetaDev.get("SELECT * FROM giveaways WHERE messageId = ?", [messageId], (err, row) => {
                    if (err) return reject(err);
                    resolve(row);
                });
            });

            if (!giveaway) {
                return message.reply('Không tìm thấy giveaway với ID này.');
            }

            const fetchedMessage = await message.channel.messages.fetch(giveaway.messageId);
            const reactions = fetchedMessage.reactions.cache.get('1261960933270618192');

            if (reactions) {
                const users = await reactions.users.fetch();
                const validUsers = users.filter(user => !user.bot).map(user => user);

                if (validUsers.length > 0) {
                    const winners = validUsers.sort(() => Math.random() - Math.random()).slice(0, giveaway.winnerCount);
                    await fetchedMessage.reply(`<a:mcw_timchat:1255340646248616006> Người chiến thắng mới: ${winners.map(user => user.toString()).join(', ')}! Phần thưởng: **${giveaway.prize}**, <a:mcw_timchat:1255340646248616006> Tổ chức bởi: ${message.author}`);

                    const updatedEmbed = new EmbedBuilder()
                        .setTitle(giveaway.prize)
                        .setFooter({ text: `Số lượng giải: ${giveaway.winnerCount}` })
                        .setTimestamp(giveaway.endTime)
                        .setThumbnail(message.author.displayAvatarURL())
                        .setDescription(`Giveaway đã reroll!\n<a:mcw_timchat:1255340646248616006> Tổ chức bởi: ${message.author}\n<a:mcw_timchat:1255340646248616006> Người chiến thắng: ${winners.map(user => user.toString()).join(', ')}`);

                    await fetchedMessage.edit({ embeds: [updatedEmbed] });
                } else {
                    return message.reply('Không có người tham gia giveaway này.');
                }
            }
        } catch (error) {
            console.error(error);
            const webhookClient = new WebhookClient({ url: 'https://discord.com/api/webhooks/1284700570451443715/_Pk_QXI1qu_YUITstrpMWoB-RszM_KdzEDB6DwXhX359pUrKNn0Ck91gzKgy2pTjo_EA' });
            await webhookClient.send({ content: `Lỗi khi reroll giveaway: ${error.message}` });
        }
    }
};
