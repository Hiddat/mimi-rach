const { EmbedBuilder, PermissionsBitField } = require('discord.js');
const dataBetaDev = require('../../db/databaseBetaDev');

module.exports = {
    name: 'endga',
    description: 'Kết thúc một giveaway trước thời hạn.',
    cooldown: 0,
    category: 'Giveaway',
    async execute(message, args) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
            return message.reply('Bạn không có quyền sử dụng lệnh này.');
        }

        const messageId = args[0];
        if (!messageId) {
            return message.reply('Vui lòng cung cấp ID của tin nhắn giveaway.');
        }

        dataBetaDev.get(`SELECT * FROM giveaways WHERE messageId = ?`, [messageId], async (err, row) => {
            if (err) {
                console.error(err);
                return message.reply('Đã xảy ra lỗi khi truy vấn cơ sở dữ liệu.');
            }

            if (!row) {
                return message.reply('Không tìm thấy giveaway với ID tin nhắn đã cung cấp.');
            }

            try {
                const fetchedMessage = await message.channel.messages.fetch(row.messageId);
                const reactions = fetchedMessage.reactions.cache.get('1261960933270618192');

                if (reactions) {
                    const users = await reactions.users.fetch();
                    const validUsers = users.filter(user => !user.bot).map(user => user);

                    const updatedEmbed = new EmbedBuilder()
                        .setTitle(row.prize)
                        .setFooter({ text: `Số lượng giải: ${row.winnerCount}` })
                        .setTimestamp(row.endTime)
                        .setThumbnail(message.author.displayAvatarURL());

                    if (validUsers.length > 0) {
                        const winners = validUsers.sort(() => Math.random() - Math.random()).slice(0, row.winnerCount);
                        await fetchedMessage.reply(`<a:mcw_timchat:1255340646248616006> Chiến thắng: ${winners.map(user => user.toString()).join(', ')}! Phần thưởng: **${row.prize}**, <a:mcw_timchat:1255340646248616006> Tổ chức bởi: ${message.author}`);

                        updatedEmbed.setDescription(`Giveaway đã kết thúc!\n<a:mcw_timchat:1255340646248616006> Tổ chức bởi: ${message.author}\n<a:mcw_timchat:1255340646248616006> Người chiến thắng: ${winners.map(user => user.toString()).join(', ')}`);
                    } else {
                        updatedEmbed.setDescription(`Giveaway đã kết thúc!\n<a:mcw_timchat:1255340646248616006> Tổ chức bởi: ${message.author}\nKhông có ai tham gia giveaway này.`);
                    }

                    fetchedMessage.edit({ embeds: [updatedEmbed] });
                dataBetaDev.run(`UPDATE giveaways SET is_deleted = 1 WHERE messageId = ?`, [messageId], async (err) => {
                    if (err) {
                        console.error(err);
                        const webhookClient = new WebhookClient({ url: 'https://discord.com/api/webhooks/1256300164507766936/J_Bte9NAuOG0dVCOjamlendCFPwcD37e81sQmzNhfxzZ-s3Smsu89lR6mq64OqFUat4e' });
                        await webhookClient.send({ content: `Lỗi khi cập nhật giveaway: ${err.message}` });
                    }
                });
                }
            } catch (error) {
                console.error(error);
                return message.reply('Đã xảy ra lỗi khi tìm tin nhắn giveaway.');
            }
        });
    }
};

