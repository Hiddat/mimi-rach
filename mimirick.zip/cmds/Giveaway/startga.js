const { EmbedBuilder, WebhookClient, PermissionsBitField } = require('discord.js');
const dataBetaDev = require('../../db/databaseBetaDev');

const maxGiveaways = 15;
const maxDuration = 30 * 24 * 60 * 60 * 1000; // 15 ngày tính bằng milliseconds
const minDuration = 15 * 1000; // 15 giây tính bằng milliseconds

function parseDuration(duration) {
    const regex = /^(\d+)([dhms])$/;
    const match = duration.match(regex);
    if (!match) return null;

    let value = parseInt(match[1]);
    const unit = match[2];

    if (isNaN(value)) return null;

    switch (unit) {
        case 'd':
            value *= 24 * 60 * 60 * 1000; // days to milliseconds
            break;
        case 'h':
            value *= 60 * 60 * 1000; // hours to milliseconds
            break;
        case 'm':
            value *= 60 * 1000; // minutes to milliseconds
            break;
        case 's':
            value *= 1000; // seconds to milliseconds
            break;
        default:
            return null;
    }

    // Đảm bảo thời gian tối thiểu là 15 giây
    return value < minDuration ? minDuration : value;
}

function getCurrentGiveaways(guildId) {
    return new Promise((resolve, reject) => {
        dataBetaDev.all(`SELECT COUNT(*) as count FROM giveaways WHERE guildId = ? AND endTime > ?`, [guildId, Date.now()], (err, rows) => {
            if (err) {
                return reject(err);
            }
            resolve(rows[0].count);
        });
    });
}
async function logError(error, context) {
    const webhookClient = new WebhookClient({ url: 'https://discord.com/api/webhooks/1256300164507766936/J_Bte9NAuOG0dVCOjamlendCFPwcD37e81sQmzNhfxzZ-s3Smsu89lR6mq64OqFUat4e' });

    const errorEmbed = new EmbedBuilder()
        .setTitle('Lỗi Bot')
        .setColor(0xff0000)
        .setDescription(`Đã xảy ra lỗi trong bot`)
        .addFields(
            { name: 'Lỗi', value: `\`\`\`${error.stack || error}\`\`\`` },
            { name: 'Ngữ cảnh', value: `\`\`\`${context}\`\`\`` }
        )
        .setTimestamp();

    await webhookClient.send({ embeds: [errorEmbed] });
}

module.exports = {
    name: 'giveaway',
    cooldown: 0,
    aliases: ['sga', 'ga'],
    category: 'Giveaway',
    description: 'Tạo một giveaway. Ví dụ: .ga <thời gian: 1d (1 ngày), 1h, 10s,...> <số lượng winner: 1 hoặc ...> <phần thưởng>',
    async execute(message, args) {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild) && !message.member.roles.cache.some(role => role.name === 'Giveaway Mimi Bot')) {
            return message.reply('Bạn không có quyền sử dụng lệnh này.\n Hoặc phải có role name `Giveaway Mimi Bot`.');
        }
        try {
            if (args.length < 3) {
                return message.reply('Usage: .giveaway <duration> <number of winners> <prize>\n Ví dụ: .sga 30s 3 phân thưởng\n Trong đó: 30s s là giây, m là phút, h là giờ, d là ngày');
            }

            const duration = parseDuration(args[0]);
            if (duration === null || duration > maxDuration) {
                return message.reply('Thời lượng không hợp lệ. Thời lượng tối đa là 30 ngày.');

            }

            const winnerCount = parseInt(args[1]);
            if (isNaN(winnerCount) || winnerCount <= 0) {
                return message.reply('Số lượng người chiến thắng không hợp lệ.');
            }

            const prize = args.slice(2).join(' ');

            const currentGiveaways = await getCurrentGiveaways(message.guild.id);
            if (currentGiveaways >= maxGiveaways) {
                return message.reply('Số lượng tối đa của giveaway hoạt động trong máy chủ này là 15.');
            }

            const endTime = Date.now() + duration;

            const embed = new EmbedBuilder()
                .setTitle(prize)
                .setColor('#FFB6C1')
                .setDescription(`<a:mcw_timchat:1255340646248616006> Nhấn emoji <a:9668milkpink:1261960933270618192> bên dưới để tham gia!\n<a:mcw_timchat:1255340646248616006> Đếm ngược: **<t:${Math.floor(endTime / 1000)}:R>**\n<a:hopqua:1260970833506205748> Tổ chức bởi: ${message.author}`)
                .setFooter({ text: `Số lượng giải: ${winnerCount}` })
                .setTimestamp()
                .setThumbnail(message.author.displayAvatarURL());

            const giveawayMessage = await message.channel.send({ content: '# <a:duoitrai:1255341834436350085> **G I V E A W A Y** <a:duoiphai:1255341894687260775>', embeds: [embed] });
            giveawayMessage.react('1261960933270618192');

            // Xóa tin nhắn gọi lệnh nếu có quyền
            if (message.deletable) {
                try {
                    await message.delete();
                } catch (error) {
                    console.error('Không thể xóa tin nhắn gọi lệnh:', error);
                }
            }

            dataBetaDev.run(`INSERT INTO giveaways (id, prize, winnerCount, endTime, channelId, messageId, guildId) VALUES (?, ?, ?, ?, ?, ?, ?)`,
                [giveawayMessage.id, prize, winnerCount, endTime, message.channel.id, giveawayMessage.id, message.guild.id], async (err) => {
                    if (err) {
                        console.error('Lỗi khi chèn vào cơ sở dữ liệu:', err);
                        await logError(err, 'INSERT INTO giveaways');
                        return;
                    }

                    // Schedule giveaway end check
                    const checkInterval = 1000; // Check every 1 second
                    const endTimeout = setInterval(async () => {
                        const now = Date.now();
                        if (now >= endTime) {
                            clearInterval(endTimeout);

                            dataBetaDev.get(`SELECT * FROM giveaways WHERE messageId = ? AND is_deleted = 0`, [giveawayMessage.id], async (err, row) => {
                                if (err) {
                                    console.error(err);
                                    await logError(err, 'SELECT * FROM giveaways');
                                    return;
                                }
                                if (!row) return;

                                const fetchedMessage = await message.channel.messages.fetch(row.messageId);
                                const reactions = fetchedMessage.reactions.cache.get('1261960933270618192');

                                if (reactions) {
                                    const users = await reactions.users.fetch();
                                    const validUsers = users.filter(user => !user.bot).map(user => user);

                                    const updatedEmbed = new EmbedBuilder()
                                        .setTitle(row.prize)
                                        .setFooter({ text: `Số lượng giải: ${row.winnerCount}` })
                                        .setTimestamp(row.endTime)
                                        .setThumbnail(message.author.displayAvatarURL());

                                    if (validUsers.length > 0) {
                                        const winners = validUsers.sort(() => Math.random() - Math.random()).slice(0, row.winnerCount);
                                        await fetchedMessage.reply(`<a:mcw_timchat:1255340646248616006> Chiến thắng: ${winners.map(user => user.toString()).join(', ')}! Phần thưởng: **${row.prize}**, <a:mcw_timchat:1255340646248616006> Tổ chức bởi: ${message.author}`);

                                        updatedEmbed.setDescription(`Giveaway đã kết thúc!\n<a:mcw_timchat:1255340646248616006> Tổ chức bởi: ${message.author}\n<a:mcw_timchat:1255340646248616006> Người chiến thắng: ${winners.map(user => user.toString()).join(', ')}`);
                                    } else {
                                        updatedEmbed.setDescription(`Giveaway đã kết thúc!\n<a:mcw_timchat:1255340646248616006> Tổ chức bởi: ${message.author}\nKhông có ai tham gia giveaway này.`);
                                    }

                                    fetchedMessage.edit({ embeds: [updatedEmbed] });
                                }

                                dataBetaDev.run(`UPDATE giveaways SET is_deleted = 1 WHERE messageId = ?`, [row.messageId], async (err) => {
                                    if (err) {
                                        console.error(err);
                                        await logError(err, 'UPDATE giveaways SET is_deleted = 1');
                                    }
                                });
                            });
                        }
                    }, checkInterval);
                });

        } catch (error) {
            console.error(error);
            await logError(error, 'Giveaway Command');
        }
    }
};
