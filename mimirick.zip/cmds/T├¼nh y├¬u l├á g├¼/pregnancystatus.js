const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');
const dbLove = require('../../db/databaseLove');

module.exports = {
  name: 'pregnancystatus',
  description: 'Xem trạng thái thai kỳ của người gọi lệnh',
  category: 'Tình yêu là gì?',
  cooldown: 3,
  async execute(message) {
    const user = message.author;

    const checkStatus = (userId) => new Promise((resolve, reject) => {
      dbLove.get("SELECT * FROM love_data WHERE (user1_id = ? OR user2_id = ?) AND success_time IS NOT NULL ORDER BY success_time DESC LIMIT 1", [userId, userId], (err, row) => {
        if (err) return reject(err);
        resolve(row);
      });
    });

    const userStatus = await checkStatus(user.id);

    if (!userStatus) {
      return message.reply('Bạn hiện tại đang độc thân.');
    }

    if (!userStatus.pregnancy_start) {
      return message.reply('Bạn chưa có thai.');
    }

    const currentTime = new Date();
    const pregnancyStartDate = new Date(userStatus.pregnancy_start);
    const pregnancyDays = Math.floor((currentTime - pregnancyStartDate) / (1000 * 60 * 60 * 24));

    let pregnancyStage = userStatus.pregnancy_stage;
    let pregnancyGender = userStatus.pregnancy_gender;

    if (!pregnancyGender && pregnancyDays >= 15) {
      pregnancyGender = Math.random() < 0.5 ? 'Nam' : 'Nữ';
      dbLove.run(`UPDATE love_data SET pregnancy_gender = ? WHERE (user1_id = ? OR user2_id = ?) AND success_time IS NOT NULL`, [pregnancyGender, user.id, userStatus.user2_id || userStatus.user1_id]);
    }

    if (pregnancyDays < 10) {
      pregnancyStage = 'Giai đoạn đầu';
    } else if (pregnancyDays < 20) {
      pregnancyStage = 'Giai đoạn giữa';
    } else {
      pregnancyStage = 'Giai đoạn cuối';
    }

    dbLove.run(`UPDATE love_data SET pregnancy_stage = ? WHERE (user1_id = ? OR user2_id = ?) AND success_time IS NOT NULL`, [pregnancyStage, user.id, userStatus.user2_id || userStatus.user1_id]);

    const embed = new EmbedBuilder()
      .setColor('#FFB6C1')
      .setTitle(`Trạng thái thai kỳ của ${user.tag}`)
      .setDescription(`**Sức khoẻ:** ${userStatus.pregnancy_health}%\n**Trạng thái thai kỳ:** ${pregnancyStage}\n**Giới tính thai kỳ:** ${pregnancyGender ? pregnancyGender : 'Chưa xác định'}\n**Thai:** ${pregnancyDays} ngày`)
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .setTimestamp()
      .setFooter({ text: `Mimi Love - ${currentTime.toLocaleDateString()} ${currentTime.toLocaleTimeString()}` });

    const userId = user.id;
    const inventoryItems = await new Promise((resolve, reject) => {
      dbLove.all("SELECT item_name, quantity FROM user_inventorys WHERE user_id = ?", [userId], (err, rows) => {
        if (err) return reject(err);
        resolve(rows);
      });
    });

    const limitedHealthItems = inventoryItems.filter(item => item.quantity > 0);

    const menus = [];
    for (let i = 0; i < limitedHealthItems.length; i += 25) {
      const itemsChunk = limitedHealthItems.slice(i, i + 25).map(item => ({
        label: item.item_name,
        value: item.item_name
      }));

      menus.push(
        new ActionRowBuilder().addComponents(
          new StringSelectMenuBuilder()
            .setCustomId(`select_health_item_${i / 25}`)
            .setPlaceholder('Chọn đồ ăn từ balo để tăng sức khỏe')
            .addOptions(itemsChunk)
        )
      );
    }

    const messageEmbed = await message.channel.send({ embeds: [embed], components: menus });

    const filter = i => i.customId.startsWith('select_health_item') && i.user.id === user.id;
    const collector = messageEmbed.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async i => {
      const selectedItem = i.values[0];

      const item = inventoryItems.find(item => item.item_name === selectedItem);

      if (item && item.quantity > 0) {
        dbLove.run(`UPDATE user_inventorys SET quantity = quantity - 1 WHERE user_id = ? AND item_name = ?`, [userId, selectedItem], function(err) {
          if (err) {
            console.error(err);
            return;
          }
        });

        const newHealth = Math.min(userStatus.pregnancy_health + 10, 100);
        dbLove.run(`UPDATE love_data SET pregnancy_health = ? WHERE (user1_id = ? OR user2_id = ?) AND success_time IS NOT NULL`, [newHealth, user.id, userStatus.user2_id || userStatus.user1_id]);

        await i.update({ content: `Bạn đã sử dụng ${selectedItem}. Sức khỏe hiện tại: ${newHealth}%`, components: [] });
      } else {
        await i.update({ content: 'Số lượng không đủ hoặc không tìm thấy vật phẩm.', components: [] });
      }
    });

    // Hiển thị nút Đẻ khi đến ngày đẻ
    if (pregnancyDays >= 30) {
      const deliveryRow = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('natural_birth')
            .setLabel('Đẻ thường')
            .setStyle(ButtonStyle.Primary)
            .setEmoji('👶'),
          new ButtonBuilder()
            .setCustomId('c_section')
            .setLabel('Đẻ mổ')
            .setStyle(ButtonStyle.Danger)
            .setEmoji('🏥')
        );

      const deliveryEmbed = await message.channel.send({ content: 'Đã đến ngày sinh, hãy chọn phương thức sinh:', components: [deliveryRow] });

      const deliveryFilter = i => ['natural_birth', 'c_section'].includes(i.customId) && i.user.id === user.id;
      const deliveryCollector = deliveryEmbed.createMessageComponentCollector({ filter: deliveryFilter, time: 43200000 }); // 12 tiếng

      deliveryCollector.on('collect', async i => {
        let deliveryType = '';
        let cost = 0;

        if (i.customId === 'natural_birth') {
          deliveryType = 'Đẻ thường';
          cost = 5000000; // Giá đẻ thường
        } else if (i.customId === 'c_section') {
          deliveryType = 'Đẻ mổ';
          cost = 20000000; // Giá đẻ mổ
        }

        const userMoney = await new Promise((resolve, reject) => {
          dbLove.get("SELECT money FROM user_money WHERE user_id = ?", [userId], (err, row) => {
            if (err) return reject(err);
            resolve(row ? row.money : 0);
          });
        });

        if (userMoney < cost) {
          await i.update({ content: `Bạn không đủ tiền để ${deliveryType.toLowerCase()}! Cần ${cost} <:xumimi:1261591338290511973>`, components: [] });
          return;
        }

        dbLove.run("UPDATE user_money SET money = money - ? WHERE user_id = ?", [cost, userId], (err) => {
          if (err) {
            console.error(err);
            return;
          }
        });

        dbLove.run(`UPDATE love_data SET pregnancy_start = NULL, pregnancy_health = NULL, pregnancy_stage = NULL, pregnancy_gender = NULL WHERE (user1_id = ? OR user2_id = ?) AND success_time IS NOT NULL`, [user.id, userStatus.user2_id || userStatus.user1_id]);

        await i.update({ content: `Chúc mừng! Bạn đã ${deliveryType.toLowerCase()} thành công!`, components: [] });
      });

      deliveryCollector.on('end', async collected => {
        if (collected.size === 0) {
          dbLove.run(`UPDATE love_data SET pregnancy_start = NULL, pregnancy_health = NULL, pregnancy_stage = NULL, pregnancy_gender = NULL WHERE (user1_id = ? OR user2_id = ?) AND success_time IS NOT NULL`, [user.id, userStatus.user2_id || userStatus.user1_id]);
          dbLove.run(`DELETE FROM love_data WHERE (user1_id = ? OR user2_id = ?) AND success_time IS NOT NULL`, [user.id, userStatus.user2_id || userStatus.user1_id]);
          dbLove.run(`DELETE FROM user_inventorys WHERE user_id = ?`, [user.id]);
          dbLove.run(`DELETE FROM user_inventorys WHERE user_id = ?`, [userStatus.user2_id || userStatus.user1_id]);

          await message.channel.send('Thời gian chọn phương thức sinh đã hết. Trạng thái bầu và trạng thái yêu đương đã bị loại bỏ.');
        }
        
            deliveryEmbed.edit({ components: [] });
      });
    }
  }
};
