const dbLove = require('../../db/databaseLove');

module.exports = {
  name: 'setaboutlove',
  description: 'Đặt mô tả cho bản thân (tối đa 250 ký tự)',
  category: 'Tình yêu là gì?',
    cooldown: 3,
  async execute(message, args) { 
    const user = message.author;
    const aboutText = args.join(' ');

    if (aboutText.length < 1) {
      return message.channel.send('Mô tả này phải lớn hơn 0 ký tự.');
    }

    if (aboutText.length > 250) {
      return message.channel.send('Mô tả không được dài quá 250 ký tự.');
    }

    const updateAbout = (userId, about) => new Promise((resolve, reject) => {
      dbLove.run("INSERT INTO user_about (user_id, about) VALUES (?, ?) ON CONFLICT(user_id) DO UPDATE SET about = ?", [userId, about, about], function(err) {
        if (err) return reject(err);
        resolve();
      });
    });

    try {
      await updateAbout(user.id, aboutText);
      message.channel.send('Mô tả của bạn đã được cập nhật. Các mô tả trống sẽ khiến \`loveinfo\` không sử dụng được. Nếu bị hãy \`setboutlove\` lại nhé!');
    } catch (error) {
      console.error(error);
      message.reply('Có lỗi xảy ra khi cập nhật mô tả của bạn.');
    }
  }
};
