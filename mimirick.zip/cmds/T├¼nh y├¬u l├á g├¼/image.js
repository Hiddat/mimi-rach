const dbLove = require('../../db/databaseLove');
const isImageUrl = require('is-image-url');
module.exports = {
  name: 'setimagelove',
  description: 'Đặt link ảnh cho Loveinfo',
  category: 'Tình yêu là gì?',
    cooldown: 3,
  async execute(message, args) { 
    const user = message.author;
    const imageText = args.join(' ');

    if (imageText.length < 1) {      
      return message.reply('Vui lòng cung cấp một đường link hình ảnh hợp lệ.');
    }

    if (!isImageUrl(imageText)) {
      return message.reply(`Vui lòng cung cấp một đường link hình ảnh hợp lệ.
Bạn cũng có thể upload ảnh lấy link ở đây nhé: [Website](<https://upload.mimibot.fun/>)  <3`);
    }

    const updateImage = (userId, image) => new Promise((resolve, reject) => {
      dbLove.run("INSERT INTO user_about (user_id, image) VALUES (?, ?) ON CONFLICT(user_id) DO UPDATE SET image = ?", [userId, image, image], function(err) {
        if (err) return reject(err);
        resolve();
      });
    });

    try {
      await updateImage(user.id, imageText);
      message.channel.send('Ảnh của bạn đã được cập nhật. Nhớ set cả about nữa nếu chưa set nhé tránh bị lỗi@');
    } catch (error) {
      console.error(error);
      message.reply('Có lỗi xảy ra khi cập nhật mô tả của bạn.');
    }
  }
};
