const { EmbedBuilder } = require('discord.js');
const dbLove = require('../../db/databaseLove');

module.exports = {
  name: 'checklove',
  aliases: ['cl'],
  description: 'Kiểm tra người được tag có người yêu trên hệ thống chưa',
  category: 'Tình yêu là gì?',
  cooldown: 3,
  async execute(message) {
    // Lấy người dùng được tag
    const user = message.mentions.users.first();

    // Kiểm tra xem có người dùng nào được tag hay không
    if (!user) {
      return message.channel.send('Bạn phải tag người bạn muốn kiểm tra.');
    }

    // Đảm bảo user ID là một chuỗi
    const userId = String(user.id);

    // Hàm kiểm tra trạng thái tình yêu của người dùng
    const checkStatus = (userId) => new Promise((resolve, reject) => {
      dbLove.get("SELECT * FROM love_data WHERE (user1_id = ? OR user2_id = ?) AND success_time IS NOT NULL ORDER BY success_time DESC LIMIT 1", [userId, userId], (err, row) => {
        if (err) return reject(err);
        if (row) {
          row.user1_id = String(row.user1_id);
          row.user2_id = String(row.user2_id);
        }
        resolve(row);
      });
    });

    try {
      // Lấy trạng thái của người dùng từ cơ sở dữ liệu
      const userStatus = await checkStatus(userId);

      // Nếu không có trạng thái tình yêu trong cơ sở dữ liệu
      if (!userStatus) {
        const embed = new EmbedBuilder()
          .setColor('#FFB6C1')
          .setDescription(`<a:2006pinkflame:1261960949951365212> **${user.username}** hiện tại đang độc thân. <a:2006pinkflame:1261960949951365212>`);
        return message.channel.send({ embeds: [embed] });
      }

      // Xác định ID của người yêu và đảm bảo ID là chuỗi
      const partnerId = String(userStatus.user1_id === userId ? userStatus.user2_id : userStatus.user1_id);
      const partner = await message.client.users.fetch(partnerId);


      // Tính toán số ngày yêu nhau
      const successTime = new Date(userStatus.success_time);
      const currentTime = new Date();
      const daysTogether = Math.floor((currentTime - successTime) / (1000 * 60 * 60 * 24));

      const formattedDate = successTime.toLocaleDateString('vi-VN', {
        day: '2-digit',
        month: '2-digit',
        year: '2-digit'
      });

      // Xác định trạng thái tình yêu
      const status = userStatus.action === 'married' ? 'Vợ chồng' : 'Người yêu';
      const statusText = userStatus.action === 'married' ? 'cầu hôn' : 'tỏ tình';

      // Tạo Embed để trả về thông tin
      const embed = new EmbedBuilder()
        .setColor('#FFB6C1')
        .setTitle(`<a:2006pinkflame:1261960949951365212> Tình yêu của ${user.username} <a:2006pinkflame:1261960949951365212>`)
        .setDescription(`<a:THUTINH:1260970781538517012> **<@${userId}>** <a:7420bearloveuwu1:1261961349836177448> **<@${partner.id}>** <a:THUTINH:1260970781538517012>\nTrạng thái: **${status}** (${statusText})\n<a:mcw_timchat:1255340646248616006> Ngày yêu: \`${formattedDate}\`\n<:mimi_pinkcoffee:1261961305179295825> Đã yêu nhau: \`${daysTogether} ngày\``)
        .setThumbnail(user.displayAvatarURL({ dynamic: true }))
        .setTimestamp()
        .setFooter({ text: `Mimi Love - ${currentTime.toLocaleDateString()} ${currentTime.toLocaleTimeString()}` });

      message.channel.send({ embeds: [embed] });
    } catch (error) {
      console.error(error);
      message.channel.send('Đã xảy ra lỗi khi kiểm tra tình trạng tình yêu.');
    }
  }
};
