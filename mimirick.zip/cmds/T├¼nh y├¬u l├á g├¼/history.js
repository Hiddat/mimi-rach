const { EmbedBuilder } = require('discord.js');
const dbLove = require('../../db/databaseLove');

module.exports = {
  name: 'history',
  description: 'Xem lịch sử người yêu đã tỏ tình hoặc cầu hôn người khác',
  category: 'Tình yêu là gì?',
    cooldown: 3,
  async execute(message) { 
    const user = message.author;

    const checkPartner = (userId) => new Promise((resolve, reject) => {
      dbLove.get("SELECT * FROM love_data WHERE (user1_id = ? OR user2_id = ?) AND success_time IS NOT NULL ORDER BY success_time DESC LIMIT 1", [userId, userId], (err, row) => {
        if (err) return reject(err);
        resolve(row);
      });
    });

    const getHistory = (userId) => new Promise((resolve, reject) => {
      dbLove.all("SELECT * FROM love_history WHERE user_id = ? ORDER BY time DESC", [userId], (err, rows) => {
        if (err) return reject(err);
        resolve(rows);
      });
    });

    const userStatus = await checkPartner(user.id);

    if (!userStatus) {
      return message.channel.send('Bạn không có người yêu để kiểm tra lịch sử.');
    }

    const partnerId = userStatus.user1_id === user.id ? userStatus.user2_id : userStatus.user1_id;

    const history = await getHistory(partnerId);

    if (!history.length) {
      return message.channel.send(`<@${partnerId}> không có lịch sử tỏ tình hoặc cầu hôn người khác.`);
    }

    const embed = new EmbedBuilder()
      .setColor('#FFB6C1')
      .setTitle(`Lịch Sử Của <@${partnerId}>`)
      .setDescription(history.map(entry => `**<@${entry.user_id}>** đã **${entry.action}** **<@${entry.target_id}>** vào lúc \`${new Date(entry.time).toLocaleString('vi-VN')}\``).join('\n'))
      .setTimestamp()
      .setFooter({ text: `Mimi Love - ${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}` });

    message.channel.send({ embeds: [embed] });
  }
};
