const { EmbedBuilder } = require('discord.js');
const dbLove = require('../../db/databaseLove');
const gifts = require('../../data/gifts.json');

module.exports = {
  name: 'balo',
  description: 'Xem balo của bạn với các món quà đã mua hoặc sử dụng các lệnh con',
  category: 'Tình yêu là gì?',
    cooldown: 3,
  async execute(message, args) {
    const user = message.author;

    if (args.length > 0) {
      const subCommand = args[0];
      if (subCommand === 'give' && args.length >= 3) {
        return await handleGive(message, user, args);
      } else if (subCommand === 'use' && args.length >= 2) {
        return await handleUse(message, user, args);
      }
    }

    return await showInventory(message, user);
  }
};

const getInventory = (userId) => new Promise((resolve, reject) => {
  dbLove.all("SELECT item_name, emoji, quantity FROM user_inventory WHERE user_id = ? AND quantity > 0", [userId], (err, rows) => {
    if (err) return reject(err);
    resolve(rows || []);
  });
});

const getUserLoveStatus = (userId) => new Promise((resolve, reject) => {
  dbLove.get("SELECT * FROM love_data WHERE (user1_id = ? OR user2_id = ?) AND success_time IS NOT NULL ORDER BY success_time DESC LIMIT 1", [userId, userId], (err, row) => {
    if (err) return reject(err);
    resolve(row);
  });
});

const updateIntimacy = (userId, intimacy) => new Promise((resolve, reject) => {
  dbLove.run("UPDATE love_data SET intimacy_level = intimacy_level + ? WHERE user1_id = ? OR user2_id = ?", [intimacy, userId, userId], function(err) {
    if (err) return reject(err);
    resolve();
  });
});

async function showInventory(message, user) {
  const inventory = await getInventory(user.id);

  if (inventory.length === 0) {
    const embed = new EmbedBuilder()
      .setColor('#FFB6C1')
      .setTitle('<a:hopqua:1260970833506205748> Balo của bạn <a:hopqua:1260970833506205748>')
      .setDescription('<a:NQG_xc126:1255341397981266012> Balo của bạn hiện đang trống. <a:NQG_xc126:1255341397981266012>')
      .setTimestamp();
    return message.channel.send({ embeds: [embed] });
  }

  let description = '====== Balo của bạn ======\n';
  let inventoryDescription = '';
    inventory.forEach((item, index) => {
      const itemNumber = index + 1;
      description += `${itemNumber}. ${item.emoji} ${item.item_name} - **${item.quantity}**\n`;
      if ((index + 1) % 3 === 0) {
        description += '\n';
      } else {
        description += ' ⠀⠀⠀⠀ |  ⠀⠀⠀⠀';
      }
    });

  description += '\n\nHDSD:\n';
  description += '`balo give <tag user> <stt> <số lượng>`\n';
  description += '`balo use <stt> <số lượng>`\n';

  const embed = new EmbedBuilder()
    .setColor('#FFB6C1')
    .setTitle('<a:hopqua:1260970833506205748> Balo của bạn <a:hopqua:1260970833506205748> ')
    .setDescription(description)
    .setTimestamp();

  message.channel.send({ embeds: [embed] });
}

async function handleGive(message, user, args) {
  const targetUser = message.mentions.users.first();
  if (!targetUser) {
    const embed = new EmbedBuilder()
      .setColor('#FFB6C1')
      .setTitle('Lỗi')
      .setDescription('<a:NQG_xc126:1255341397981266012> Vui lòng tag người nhận. <a:NQG_xc126:1255341397981266012>')
      .setTimestamp();
    return message.channel.send({ embeds: [embed] });
  }

  let itemIndex = parseInt(args[2], 10) - 1;
  let quantity = parseInt(args[3], 10);

  // Kiểm tra nếu itemIndex không phải là số hoặc nhỏ hơn 0
  if (isNaN(itemIndex) || itemIndex < 0) {
    return message.reply('Số thứ tự của món quà phải là một số hợp lệ.');
  }

  // Kiểm tra nếu quantity không phải là số hoặc không được cung cấp
  if (isNaN(quantity) || quantity <= 0) {
    quantity = 1; // Đặt mặc định là 1
  }

  const inventory = await getInventory(user.id);
  if (itemIndex >= inventory.length) {
    const embed = new EmbedBuilder()
      .setColor('#FFB6C1')
      .setTitle('Lỗi')
      .setDescription('<a:NQG_xc126:1255341397981266012> Món quà không tồn tại trong balo của bạn. <a:NQG_xc126:1255341397981266012>')
      .setTimestamp();
    return message.channel.send({ embeds: [embed] });
  }

  const item = inventory[itemIndex];
  if (item.quantity < quantity) {
    const embed = new EmbedBuilder()
      .setColor('#FFB6C1')
      .setTitle('Lỗi')
      .setDescription('<a:NQG_xc126:1255341397981266012> Bạn không có đủ số lượng để tặng. <a:NQG_xc126:1255341397981266012>')
      .setTimestamp();
    return message.channel.send({ embeds: [embed] });
  }

  await updateInventory(user.id, item.item_name, -quantity);
  await updateInventory(targetUser.id, item.item_name, quantity);

  const embed = new EmbedBuilder()
    .setColor('#FFB6C1')
    .setTitle('<a:1900tick:1255341646271221837> Thành công <a:1900tick:1255341646271221837>')
    .setDescription(`<a:hopqua:1260970833506205748> Bạn đã tặng ${quantity} ${item.emoji} ${item.item_name} cho ${targetUser.username}. <a:hopqua:1260970833506205748>`)
    .setTimestamp();
  return message.channel.send({ embeds: [embed] });
}

// async function handleGive(message, user, args) {
//   const targetUser = message.mentions.users.first();
//   if (!targetUser) {
//     const embed = new EmbedBuilder()
//       .setColor('#FFB6C1')
//       .setTitle('Lỗi')
//       .setDescription('<a:NQG_xc126:1255341397981266012> Vui lòng tag người nhận. <a:NQG_xc126:1255341397981266012>')
//       .setTimestamp();
//     return message.channel.send({ embeds: [embed] });
//   }

//   let itemIndex = parseInt(args[2]) - 1;
//   let quantity = args[3] ? parseInt(args[3]) : 1;

//   if (isNaN(itemIndex) || itemIndex <= 0 || isNaN(quantity) || quantity <= 0) {
//     return message.reply('Vui lòng nhập số thứ tự quà theo stt trong balo và số lượng cần dùng.');
//   }

//   const inventory = await getInventory(user.id);
//   if (itemIndex < 0 || itemIndex >= inventory.length) {
//     const embed = new EmbedBuilder()
//       .setColor('#FFB6C1')
//       .setTitle('Lỗi')
//       .setDescription('<a:NQG_xc126:1255341397981266012> Món quà không tồn tại trong balo của bạn. <a:NQG_xc126:1255341397981266012>')
//       .setTimestamp();
//     return message.channel.send({ embeds: [embed] });
//   }

//   const item = inventory[itemIndex];
//   if (item.quantity < quantity) {
//     const embed = new EmbedBuilder()
//       .setColor('#FFB6C1')
//       .setTitle('Lỗi')
//       .setDescription('<a:NQG_xc126:1255341397981266012> Bạn không có đủ số lượng để tặng. <a:NQG_xc126:1255341397981266012>')
//       .setTimestamp();
//     return message.channel.send({ embeds: [embed] });
//   }

//   await updateInventory(user.id, item.item_name, -quantity);
//   await updateInventory(targetUser.id, item.item_name, quantity);

//   const embed = new EmbedBuilder()
//     .setColor('#FFB6C1')
//     .setTitle('<a:1900tick:1255341646271221837> Thành công <a:1900tick:1255341646271221837>')
//     .setDescription(`<a:hopqua:1260970833506205748> Bạn đã tặng ${quantity} ${item.emoji} ${item.item_name} cho ${targetUser.username}. <a:hopqua:1260970833506205748>`)
//     .setTimestamp();
//   return message.channel.send({ embeds: [embed] });
// }

async function handleUse(message, user, args) {
  const userLoveStatus = await getUserLoveStatus(user.id);

  if (!userLoveStatus) {
    const embed = new EmbedBuilder()
      .setColor('#FFB6C1')
      .setTitle('Lỗi')
      .setDescription('Bạn cần có người yêu để sử dụng quà.')
      .setTimestamp();
    return message.channel.send({ embeds: [embed] });
  }

  const itemIndex = parseInt(args[1]) - 1;
  const quantity = args[2] ? parseInt(args[2]) : 1;

  const inventory = await getInventory(user.id);
  if (itemIndex < 0 || itemIndex >= inventory.length) {
    const embed = new EmbedBuilder()
      .setColor('#FFB6C1')
      .setTitle('Lỗi')
      .setDescription('Món quà không tồn tại trong balo của bạn.')
      .setTimestamp();
    return message.channel.send({ embeds: [embed] });
  }

  const item = inventory[itemIndex];
  if (item.quantity < quantity) {
    const embed = new EmbedBuilder()
      .setColor('#FFB6C1')
      .setTitle('Lỗi')
      .setDescription('Bạn không có đủ số lượng để sử dụng.')
      .setTimestamp();
    return message.channel.send({ embeds: [embed] });
  }

  await updateInventory(user.id, item.item_name, -quantity);

  const gift = gifts.find(g => g.name === item.item_name);
  let intimacyPoints = 0;
  if (gift) {
    intimacyPoints = gift.intimacy * quantity;
    await updateIntimacy(user.id, intimacyPoints);
  }

  const embed = new EmbedBuilder()
    .setColor('#FFB6C1')
    .setTitle('Thành công')
    .setDescription(`Bạn đã sử dụng ${quantity} ${item.emoji} ${item.item_name}. Độ thân mật của bạn và người yêu đã tăng ${intimacyPoints} điểm.`)
    .setTimestamp();
  return message.channel.send({ embeds: [embed] });
}

const updateInventory = (userId, itemName, quantityChange) => new Promise((resolve, reject) => {
  dbLove.run(
    "INSERT INTO user_inventory (user_id, item_name, emoji, quantity) VALUES (?, ?, (SELECT emoji FROM user_inventory WHERE item_name = ?), ?) ON CONFLICT(user_id, item_name) DO UPDATE SET quantity = quantity + ? WHERE user_id = ? AND item_name = ?",
    [userId, itemName, itemName, Math.max(quantityChange, 0), quantityChange, userId, itemName],
    function(err) {
      if (err) return reject(err);
      resolve();
    }
  );
});
