const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const dbLove = require('../../db/databaseLove');
const isImageUrl = require('is-image-url');
const isHexColor = require('is-hexcolor');
const rings = {
  none: { emoji: '❌', name: 'Chưa có nhẫn' },
  basic: { emoji: '<:nhan_basic:1259698833823240283>', name: 'Nhẫn Basic' },
  gold: { emoji: '<:nhan_vang:1259699697292017767>', name: 'Nhẫn Vàng' },
  silver: { emoji: '<:nhan_bac:1259699699192172636>', name: 'Nhẫn Bạc' },
  ruby: { emoji: '<:nhan_ruby:1259699702060810262>', name: 'Nhẫn Ruby' },
  sapphire: { emoji: '<:nhan_sapphire:1259699706767085638>', name: 'Nhẫn Sapphire' },
  emerald: { emoji: '<:nhan_lucbao:1259699709380132886>', name: 'Nhẫn Lục Bảo' },
  pink_ruby: { emoji: '<:nhan_hongngoc:1259699612034531388>', name: 'Nhẫn Hồng Ngọc' },
  gemstone: { emoji: '<:nhan_daquy:1259699627033104555>', name: 'Nhẫn Đá Quý' },
  turquoise_diamond: { emoji: '<:turquoise_diamond:1277960456845262940>', name: 'Ring turquoise diamond' },
  gold2: { emoji: '<:gold2:1277960447026270218>', name: 'Ring gold' },
  zirconiacrystal: { emoji: '<:zirconiacrystal:1277960401690169431>', name: 'Ring zirconia crystal' },
  sliverpink: { emoji: '<:sliverpink:1277960391892144268>', name: 'Ring sliver pink' },
  goldgemstone: { emoji: '<:goldgemstone:1277960380861382707>', name: 'Ring gold gem stone' },
  midjourney: { emoji: '<:midjourney:1277960366005026828>', name: 'Ring midjourney' },
  deeppink: { emoji: '<:deeppink:1277960353774440490>', name: 'Ring deep pink' },
  turquoise: { emoji: '<:turquoise:1277960338779930624>', name: 'Ring turquoise' },
  Tanzanite: { emoji: '<:Tanzanite:1277960322384138290>', name: 'Ring Tanzanite' },
  pinkdiamond: { emoji: '<:pinkdiamond:1277960310065598576>', name: 'Ring pink diamond' },
  pinkruby: { emoji: '<:pinkruby:1277960265932996789>', name: 'Ring pink ruby' },
  pinksapphire: { emoji: '<:pinksapphire:1277960240335163454>', name: 'Ring pink sapphire' },
  unicornsliver: { emoji: '<:unicornsliver:1277960226922041467>', name: 'Ring unicorn sliver' },
  traitim: { emoji: '<:traitim:1277960213785350207>', name: 'Nhẫn trái tim' },
  CrimsonSovereign: { name: 'Nhẫn Hoàng Kim Rực Rỡ', emoji: '<:CrimsonSovereign:1278694004548177920>' }, // Nhẫn Hoàng Kim Rực Rỡ
  RoyalIceSapphire: { name: 'Nhẫn Băng Lam Quyền Quý', emoji: '<:RoyalIceSapphire:1278693995576430675>' }, // Nhẫn Băng Lam Quyền Quý
  GoldenRadiance: { name: 'Nhẫn Hồng Ngọc Đế Vương', emoji: '<:GoldenRadiance:1278693988152643604>' }, // Nhẫn Hồng Ngọc Đế Vương
};

const intimacyLevels = [0, 1000, 3000, 8000, 15500, 26500, 60000, 150000, 200000, 550000000, 750000000, 900000000, 100000000, 500000000, 1000000000, 2000000000]; // Example level thresholds

module.exports = {
  name: 'loveinfo',
  description: 'Xem chi tiết tình yêu của người gọi lệnh',
  category: 'Tình yêu là gì?',
  cooldown: 3,
  async execute(message) { 
    console.log(typeof message.author.id, message.author.id);

    const user = message.author;
    const userId = message.author.id;

    const checkStatus = (userId) => new Promise((resolve, reject) => {
      dbLove.get("SELECT * FROM love_data WHERE (user1_id = ? OR user2_id = ?) AND success_time IS NOT NULL ORDER BY success_time DESC LIMIT 1", [userId, userId], (err, row) => {
        if (err) return reject(err);
        resolve(row);
      });
    });

    const getAbout = (userId) => new Promise((resolve, reject) => {
      dbLove.get("SELECT about FROM user_about WHERE user_id = ?", [userId], (err, row) => {
        if (err) return reject(err);
        resolve(row ? row.about : `-# Owner bot said: "Yêu đương con cặc!"`);
      });
    });

    const getImage = (userId) => new Promise((resolve, reject) => {
      dbLove.get("SELECT image FROM user_about WHERE user_id = ?", [userId], (err, row) => {
        if (err) return reject(err);
        resolve(row ? row.image : `https://media.discordapp.net/attachments/1255044665451741256/1259505274641977414/92eae07ba79ac2651e8caec396927abc.gif?ex=668bed31&is=668a9bb1&hm=f802e737ae605dde4e9496a7aa588235577a43dc8e700a32b3e8702e80a21dc3&=&width=625&height=430`);
      });
    });

    const getUserMoney = (userId) => new Promise((resolve, reject) => {
      dbLove.get("SELECT money FROM user_money WHERE user_id = ?", [userId], (err, row) => {
        if (err) return reject(err);
        resolve(row ? row.money : 0);
      });
    });

    const updateUserMoney = (userId, amount) => new Promise((resolve, reject) => {
      dbLove.run("UPDATE user_money SET money = money + ? WHERE user_id = ?", [amount, userId], (err) => {
        if (err) return reject(err);
        resolve();
      });
    });

    const recordMotelVisit = (user1Id, user2Id, motelName, visitTime, returnTime) => new Promise((resolve, reject) => {
      dbLove.run("INSERT INTO motel_visits (user1_id, user2_id, motel_name, visit_time, return_time) VALUES (?, ?, ?, ?, ?)", [user1Id, user2Id, motelName, visitTime, returnTime], (err) => {
        if (err) return reject(err);
        resolve();
      });
    });

    const userStatus = await checkStatus(userId);
    const userAbout = await getAbout(userId);
    const userImage = await getImage(userId);

    if (!userStatus) {
      return message.channel.send('<a:2006pinkflame:1261960949951365212> Bạn hiện tại đang độc thân. <a:2006pinkflame:1261960949951365212>');
    }

    const partnerId = userStatus.user1_id === userId ? userStatus.user2_id : userStatus.user1_id;
    const partner = await message.client.users.fetch(partnerId);
    const successTime = new Date(userStatus.success_time);
    const currentTime = new Date();
    const daysTogether = Math.floor((currentTime - successTime) / (1000 * 60 * 60 * 24));

    const formattedDate = successTime.toLocaleDateString('vi-VN', {
      day: '2-digit',
      month: '2-digit',
      year: '2-digit'
    });

    const status = userStatus.action === 'married' ? 'Vợ chồng' : 'Người yêu';
    const ringInfo = userStatus.ring_type !== 'none' ? `${rings[userStatus.ring_type].emoji} ${rings[userStatus.ring_type].name}` : 'Chưa có nhẫn';

    let intimacyLevel = 0;
    let progressToNextLevel = 0;

    for (let i = 0; i < intimacyLevels.length; i++) {
      if (userStatus.intimacy_level < intimacyLevels[i]) {
        intimacyLevel = i;
        progressToNextLevel = ((userStatus.intimacy_level - intimacyLevels[i - 1]) / (intimacyLevels[i] - intimacyLevels[i - 1])) * 100;
        break;
      }
    }

    if (userStatus.intimacy_level >= intimacyLevels[intimacyLevels.length - 1]) {
      intimacyLevel = intimacyLevels.length;
      progressToNextLevel = 100;
    }

    let pregnancyInfo = '';
    let pregnancyStartDate = userStatus.pregnancy_start ? new Date(userStatus.pregnancy_start) : null;
    if (pregnancyStartDate) {
      const pregnancyDays = Math.floor((currentTime - pregnancyStartDate) / (1000 * 60 * 60 * 24));
      pregnancyInfo = `\n<a:2006pinkflame:1261960949951365212> Bạn đang mang thai được \`${pregnancyDays}\` ngày.`;
    }

            const imageUrl = userImage && isImageUrl(userImage) ? userImage : 'https://media.discordapp.net/attachments/1255044665451741256/1259505274641977414/92eae07ba79ac2651e8caec396927abc.gif?ex=668bed31&is=668a9bb1&hm=f802e737ae605dde4e9496a7aa588235577a43dc8e700a32b3e8702e80a21dc3&=&width=625&height=430';

    const embed = new EmbedBuilder()
      .setColor('#FFB6C1')
      .setTitle(`<a:2006pinkflame:1261960949951365212> Ngôi Nhà Tình Yêu Của ${user.tag} <a:2006pinkflame:1261960949951365212>`)
      .setThumbnail(user.displayAvatarURL({ dynamic: true }))
      .setDescription(`<a:THUTINH:1260970781538517012> <@${userId}> <a:7420bearloveuwu1:1261961349836177448> <@${partner.id}> <a:THUTINH:1260970781538517012>\n<a:hyc_decor_gavvang:1255342025046229033> Trạng thái: **${status}**\n<a:mcw_timchat:1255340646248616006> Ngày yêu: \`${formattedDate}\`\n<:mimi_pinkcoffee:1261961305179295825> Đã yêu nhau: \`${daysTogether} ngày\`\n<a:9761lightpinkcrown:1261960952224546818> Độ thân mật: Cấp ${intimacyLevel} (${progressToNextLevel.toFixed(2)}%)\n<a:7420bearloveuwu1:1261961349836177448>Nhẫn cưới: ${ringInfo}${pregnancyInfo}`)
      .addFields({ name: '<a:4524kawaiibow:1261961293817053205> About', value: userAbout })
      .setTimestamp()
      .setFooter({ text: `Mimi Love - ${currentTime.toLocaleDateString()} ${currentTime.toLocaleTimeString()}` });


    // Nếu xẩy ra lỗi
    // const embederror = new EmbedBuilder()
    //   .setColor('#FFB6C1')
    //   .setTitle(`<a:2006pinkflame:1261960949951365212> Ngôi Nhà Tình Yêu Của ${user.tag} <a:2006pinkflame:1261960949951365212>`)
    //   .setThumbnail(user.displayAvatarURL({ dynamic: true }))
    //   .setDescription(`<a:THUTINH:1260970781538517012> <@${userId}> <a:7420bearloveuwu1:1261961349836177448> <@${partner.id}> <a:THUTINH:1260970781538517012>\n<a:hyc_decor_gavvang:1255342025046229033> Trạng thái: **${status}**\n<a:mcw_timchat:1255340646248616006> Ngày yêu: \`${formattedDate}\`\n<:mimi_pinkcoffee:1261961305179295825> Đã yêu nhau: \`${daysTogether} ngày\`\n<a:9761lightpinkcrown:1261960952224546818> Độ thân mật: Cấp ${intimacyLevel} (${progressToNextLevel.toFixed(2)}%)\n<a:7420bearloveuwu1:1261961349836177448>Nhẫn cưới: ${ringInfo}${pregnancyInfo}`)
    //   .addFields({ name: '<a:4524kawaiibow:1261961293817053205> About', value: '-# About đã bị lỗi hãy set lại nhé bạn! ' })
    //   .setTimestamp()
    //   .setFooter({ text: `Mimi Love - ${currentTime.toLocaleDateString()} ${currentTime.toLocaleTimeString()}` });

    embed.setImage(imageUrl);
    // embederror.setImage(imageUrl);

    const motelsPath = path.join(__dirname, '../../motels.json');
    const motels = JSON.parse(fs.readFileSync(motelsPath));
    const availableMotels = motels.filter(motel => motel.status === 'open' && motel.max_couples > 0);
    const options = availableMotels.map(motel => ({
      label: motel.name,
      description: `${motel.emoji} - Giá: ${motel.hourly_rate} Xu`,
      value: JSON.stringify({ name: motel.name, rate: motel.pregnancy_rate, hourly_rate: motel.hourly_rate, return_time: motel.return_time }) // Mã hóa thông tin nhà nghỉ
    }));


    const row1 = new ActionRowBuilder()
      .addComponents(
        new StringSelectMenuBuilder()
          .setCustomId('select_motel')
          .setPlaceholder('Chọn nhà nghỉ...')
          .addOptions(options)
          .setDisabled(intimacyLevel < 10 || pregnancyStartDate !== null) // Chỉ cho phép chọn khi độ thân mật đạt cấp 10 và không mang thai
      );

    const components = [row1];
    // try{
      const messageEmbed = await message.channel.send({ embeds: [embed], components });
    // }catch(error){
    //   const messageEmbed = await message.channel.send({ embeds: [embederror], components });
    // }

    

    const filter = i => i.customId === 'select_motel' && i.userId === userId;
    const collector = messageEmbed.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async i => {
      const selectedMotelData = JSON.parse(i.values[0]);
      const selectedMotelName = selectedMotelData.name;
      const selectedMotel = availableMotels.find(motel => motel.name === selectedMotelName);

      if (!selectedMotel) {
        await i.update({ content: 'Nhà nghỉ đã chọn không khả dụng.', components: [] });
        return;
      }

      const userMoney = await getUserMoney(userId);
      if (userMoney < selectedMotel.hourly_rate) {
        await i.update({ content: 'Bạn không đủ tiền để sử dụng nhà nghỉ này.', components: [] });
        return;
      }

      await updateUserMoney(userId, -selectedMotel.hourly_rate);
      await updateUserMoney(partnerId, -selectedMotel.hourly_rate);

      const visitTime = new Date();
      const returnTime = new Date(visitTime.getTime() + selectedMotel.return_time * 1000);

      await recordMotelVisit(userId, partnerId, selectedMotel.name, visitTime.toISOString(), returnTime.toISOString());

      const isPregnant = Math.random() < selectedMotel.pregnancy_rate;
      if (isPregnant) {
        dbLove.run(`UPDATE love_data SET pregnancy_start = ?, pregnancy_health = 100, pregnancy_stage = 'Giai đoạn đầu', pregnancy_gender = '' WHERE (user1_id = ? OR user2_id = ?) AND success_time IS NOT NULL`, [new Date().toISOString(), userId, partnerId], function(err) {
          if (err) {
            console.error(err);
            return;
          }
        });
      }

      const userDM = await user.createDM();
      const partnerDM = await partner.createDM();

      if (isPregnant) {
        await userDM.send(`Chúc mừng! Bạn và ${partner.username} đã có thai sau khi đi nhà nghỉ ${selectedMotel.name}.`);
        await partnerDM.send(`Chúc mừng! Bạn và ${user.username} đã có thai sau khi đi nhà nghỉ ${selectedMotel.name}.`);
      } else {
        await userDM.send(`Bạn và ${partner.username} đã sử dụng nhà nghỉ ${selectedMotel.name}, nhưng chưa có thai.`);
        await partnerDM.send(`Bạn và ${user.username} đã sử dụng nhà nghỉ ${selectedMotel.name}, nhưng chưa có thai.`);
      }

      await i.update({
        content: `Bạn đã chọn ${selectedMotel.name} ${selectedMotel.emoji}\nTỉ lệ có thai: ${selectedMotel.pregnancy_rate * 100}%\nGiá theo giờ: ${selectedMotel.hourly_rate} VND\nThời gian quay lại: ${selectedMotel.return_time / 60} phút`,
        components: []
      });
    });
        
        collector.on('end', () => {
            messageEmbed.edit({ components: [] });
        });
  }
};
