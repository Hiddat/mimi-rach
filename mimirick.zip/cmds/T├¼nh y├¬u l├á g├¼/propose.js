const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const db = require('../../db/databaseLove');

module.exports = {
  name: 'cauhon',
  description: 'Cầu hôn một người dùng khác',
  category: 'Tình yêu là gì?',
    cooldown: 3,
  async execute(message, args) {
    const user1 = message.author;
    const user2 = message.mentions.users.first();

    if (!user2) {
      return message.reply('<a:NQG_xc126:1255341397981266012> Vui lòng tag người bạn muốn cầu hôn. <a:NQG_xc126:1255341397981266012>');
    }

    if (user1.id === user2.id) {
      return message.reply('<a:NQG_xc126:1255341397981266012> Bạn không thể cầu hôn chính mình. <a:NQG_xc126:1255341397981266012>');
    } 

    if (user2.bot) {
      return message.reply('<a:NQG_xc126:1255341397981266012> Bạn không thể cầu hôn bot. <a:NQG_xc126:1255341397981266012>');
    }

    const checkExistingRelationship = (userId) => new Promise((resolve, reject) => {
      db.get("SELECT * FROM love_data WHERE (user1_id = ? OR user2_id = ?) AND success_time IS NOT NULL", [userId, userId], (err, row) => {
        if (err) return reject(err);
        resolve(row);
      });
    });

    const createProposal = (userId1, userId2) => new Promise((resolve, reject) => {
      db.run("INSERT INTO love_data (user1_id, user2_id, action) VALUES (?, ?, 'propose')", [userId1, userId2], function(err) {
        if (err) return reject(err);
        resolve();
      });
    });

    const addHistory = (userId, action, targetId) => new Promise((resolve, reject) => {
      db.run("INSERT INTO love_history (user_id, action, target_id, time) VALUES (?, ?, ?, CURRENT_TIMESTAMP)", [userId, action, targetId], function(err) {
        if (err) return reject(err);
        resolve();
      });
    });

    const existingRelationshipUser1 = await checkExistingRelationship(user1.id);
    const existingRelationshipUser2 = await checkExistingRelationship(user2.id);

    if (existingRelationshipUser1 || existingRelationshipUser2) {
      if (existingRelationshipUser1) {
        await addHistory(user1.id, 'cầu hôn', user2.id);

        const partnerUser1Id = existingRelationshipUser1.user1_id === user1.id ? existingRelationshipUser1.user2_id : existingRelationshipUser1.user1_id;
        const partnerUser1 = await message.guild.members.fetch(partnerUser1Id);

        const embedUser1 = new EmbedBuilder()
          .setColor('#FFB6C1')
          .setTitle('<a:NQG_xc126:1255341397981266012> Thông Báo Cầu Hôn <a:NQG_xc126:1255341397981266012>')
          .setDescription(`<a:NQG_xc126:1255341397981266012> ${user1} đã cố gắng cầu hôn ${user2}, nhưng bạn đã có người yêu. <a:NQG_xc126:1255341397981266012>`)
          .setTimestamp();

        if (partnerUser1) {
          partnerUser1.send({ embeds: [embedUser1] });
        }
      }

      if (existingRelationshipUser2) {
        await addHistory(user2.id, 'cầu hôn', user1.id);

        const partnerUser2Id = existingRelationshipUser2.user1_id === user2.id ? existingRelationshipUser2.user2_id : existingRelationshipUser2.user1_id;
        const partnerUser2 = await message.guild.members.fetch(partnerUser2Id);

        const embedUser2 = new EmbedBuilder()
          .setColor('#FFB6C1')
          .setTitle('<a:NQG_xc126:1255341397981266012> Thông Báo Cầu Hôn <a:NQG_xc126:1255341397981266012>')
          .setDescription(`<a:NQG_xc126:1255341397981266012> ${user1} đã cố gắng cầu hôn ${user2}, nhưng ${user2} đã có người yêu. <a:NQG_xc126:1255341397981266012>`)
          .setTimestamp();

        if (partnerUser2) {
          partnerUser2.send({ embeds: [embedUser2] });
        }
      }

      return message.reply('<a:NQG_xc126:1255341397981266012> Bạn hoặc người bạn muốn cầu hôn đã có người yêu. <a:NQG_xc126:1255341397981266012>');
    }

    await createProposal(user1.id, user2.id);

    const embed = new EmbedBuilder()
      .setColor('#FFB6C1')
      .setTitle('💍 Lời Cầu Hôn 💍')
      .setDescription(`<a:THUTINH:1255341478855573597> ${user1} đã cầu hôn ${user2}. Bạn có đồng ý không? <a:THUTINH:1255341478855573597>`)
      .setTimestamp();

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('accept')
          .setLabel('Đồng ý')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('decline')
          .setLabel('Từ chối')
          .setStyle(ButtonStyle.Danger)
      );

    const proposalMessage = await message.channel.send({ embeds: [embed], components: [row] });

    const filter = i => (i.customId === 'accept' || i.customId === 'decline') && i.user.id === user2.id;
    const collector = proposalMessage.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async i => {
      if (i.customId === 'accept') {
        db.run("UPDATE love_data SET action = 'married', success_time = CURRENT_TIMESTAMP WHERE user1_id = ? AND user2_id = ?", [user1.id, user2.id]);
        await i.update({ content: `<a:THUTINH:1255341478855573597> ${user2} đã đồng ý lời cầu hôn của ${user1}! <a:THUTINH:1255341478855573597>`, embeds: [], components: [] });
      } else {
        db.run("DELETE FROM love_data WHERE user1_id = ? AND user2_id = ?", [user1.id, user2.id]);
        await i.update({ content: `<:mimi_pepeknickerspink:1261961303166287902> ${user2} đã từ chối lời cầu hôn của ${user1}. <:mimi_pepeknickerspink:1261961303166287902>`, embeds: [], components: [] });
      }
    });

    collector.on('end', collected => {
      if (collected.size === 0) {
        db.run("DELETE FROM love_data WHERE user1_id = ? AND user2_id = ?", [user1.id, user2.id]);
        proposalMessage.edit({ content: 'Lời cầu hôn đã hết hạn.', embeds: [], components: [] });
      }
    });
  }
};
