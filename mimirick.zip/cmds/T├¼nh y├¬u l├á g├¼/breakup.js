const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const dbLove = require('../../db/databaseLove');

module.exports = {
  name: 'chiatay',
  aliases: ['lydi', 'lyhon'],
  description: 'Chia tay với người bạn đồng hành của mình',
  category: 'Tình yêu là gì?',
  cooldown: 3,
  async execute(message) { 
    
    const user1 = message.author;

    const checkStatus = (userId) => new Promise((resolve, reject) => {
      dbLove.get("SELECT * FROM love_data WHERE (user1_id = ? OR user2_id = ?) AND success_time IS NOT NULL ORDER BY success_time DESC LIMIT 1", [userId, userId], (err, row) => {
        if (err) return reject(err);
        resolve(row);
      });
    });

    let user1Status;
    try {
      user1Status = await checkStatus(user1.id);
    } catch (error) {
      console.error('Error checking status:', error);
      return message.channel.send('Đã có lỗi xảy ra khi kiểm tra trạng thái của bạn.');
    }

    if (!user1Status) {
      return message.channel.send('Bạn không có người yêu để chia tay.');
    }

    const partnerId = user1Status.user1_id === user1.id ? user1Status.user2_id : user1Status.user1_id;

    const partnerUser = message.guild.members.cache.get(partnerId);
      if (!partnerUser) {
        return message.channel.send('Không tìm thấy người yêu của bạn trên server này.');
      }
    const content = `<@${user1.id}> đang muốn chia tay với bạn <@${partnerId}>!`
    const embed = new EmbedBuilder()
      .setColor('#FFB6C1')
      .setTitle('Lời Chia Tay')
      .setDescription(`${user1} muốn chia tay với ${partnerUser}. Bạn có đồng ý không?`)
      .setFooter({ text: 'Sau 5 phut tự động chia tay!' });

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('accept')
          .setLabel('Đồng ý')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('decline')
          .setLabel('Từ chối')
          .setStyle(ButtonStyle.Danger),
      );

    const breakupMessage = await message.channel.send({ content, embeds: [embed], components: [row] });

    const filter = i => i.user.id === partnerUser.id;

    const collector = breakupMessage.createMessageComponentCollector({ filter, componentType: ComponentType.Button, time: 300000 });

    collector.on('collect', async interaction => {
      if (interaction.customId === 'accept') {
        dbLove.run("DELETE FROM love_data WHERE user1_id = ? OR user2_id = ?", [user1.id, user1.id], function(err) {
          if (err) {
            console.error('Error deleting relationship:', err);
            return interaction.update({ content: 'Đã có lỗi xảy ra khi xóa mối quan hệ.', components: [], embeds: [] });
          }
          interaction.update({ content: `Cả hai đã đồng ý chia tay. Mối quan hệ giữa ${user1.username} và ${partnerUser.user.username} đã bị xóa.`, components: [], embeds: [] });
        });
      } else {
        interaction.update({ content: `${interaction.user.username} đã từ chối lời chia tay.`, components: [], embeds: [] });
      }
    });

    collector.on('end', collected => {
      if (collected.size === 0) {
        dbLove.run("DELETE FROM love_data WHERE user1_id = ? OR user2_id = ?", [user1.id, user1.id], function(err) {
          if (err) {
            console.error('Error deleting relationship:', err);
            return breakupMessage.edit({ content: 'Đã có lỗi xảy ra khi xóa mối quan hệ.', components: [] });
          }
          breakupMessage.edit({ content: `Lời chia tay đã tự động được chấp nhận. Mối quan hệ giữa ${user1.username} và ${partnerUser.user.username} đã bị xóa.`, components: [] });
        });
      }
    });
  }
};

// // ./cmds/breakup.js
// const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
// const dbLove = require('../../db/databaseLove');

// module.exports = {
//   name: 'chiatay',
//   aliases: ['lydi'],
//   description: 'Chia tay với người bạn đồng hành của mình',
//   category: 'Tình yêu là gì?',
//     cooldown: 3,
//   async execute(message) { 
    
//     const user1 = message.author;
//     const user2 = message.mentions.users.first();

//     if (!user2) {
//       return message.channel.send('Bạn phải tag người bạn muốn chia tay.');
//     }

//     const checkStatus = (userId) => new Promise((resolve, reject) => {
//       dbLove.get("SELECT * FROM love_data WHERE (user1_id = ? OR user2_id = ?) AND success_time IS NOT NULL ORDER BY success_time DESC LIMIT 1", [userId, userId], (err, row) => {
//         if (err) return reject(err);
//         resolve(row);
//       });
//     });

//     const user1Status = await checkStatus(user1.id);

//     if (!user1Status) {
//       return message.channel.send('Bạn không có người yêu để chia tay.');
//     }

//     const partnerId = user1Status.user1_id === user1.id ? user1Status.user2_id : user1Status.user1_id;

//     if (partnerId !== user2.id) {
//       return message.channel.send('Người bạn tag không phải là người yêu hiện tại của bạn.');
//     }

//     const partnerUser = message.guild.members.cache.get(user2.id);

//     if (!partnerUser) {
//       return message.channel.send('Không tìm thấy người yêu của bạn trên server này.');
//     }

//     const embed = new EmbedBuilder()
//       .setColor('#FFB6C1')
//       .setTitle('Lời Chia Tay')
//       .setDescription(`${user1} muốn chia tay với ${partnerUser}. Bạn có đồng ý không?`);

//     const row = new ActionRowBuilder()
//       .addComponents(
//         new ButtonBuilder()
//           .setCustomId('accept')
//           .setLabel('Đồng ý')
//           .setStyle(ButtonStyle.Success),
//         new ButtonBuilder()
//           .setCustomId('decline')
//           .setLabel('Từ chối')
//           .setStyle(ButtonStyle.Danger),
//       );

//     const breakupMessage = await message.channel.send({ embeds: [embed], components: [row] });

//     const filter = i => i.user.id === partnerUser.id;

//     const collector = breakupMessage.createMessageComponentCollector({ filter, componentType: ComponentType.Button, time: 60000 });

//     collector.on('collect', async interaction => {
//       if (interaction.customId === 'accept') {
//         dbLove.run("DELETE FROM love_data WHERE user1_id = ? OR user2_id = ?", [user1.id, user1.id], function(err) {
//           if (err) {
//             return console.error(err.message);
//           }
//           interaction.update({ content: `Cả hai đã đồng ý chia tay. Mối quan hệ giữa ${user1.username} và ${partnerUser.user.username} đã bị xóa.`, components: [], embeds: [] });
//         });
//       } else {
//         interaction.update({ content: `${interaction.user.username} đã từ chối lời chia tay.`, components: [], embeds: [] });
//       }
//     });

//     collector.on('end', collected => {
//       if (collected.size === 0) {
//         breakupMessage.edit({ content: 'Không có phản hồi. Lời chia tay đã hết hạn.', components: [] });
//       }
//     });
//   }
// };
