const { EmbedBuilder } = require('discord.js');

let activePlayers = new Set();

module.exports = {
  name: 'timchu',
  description: 'Trò chơi tìm từ',
  category: 'Fun/Games',
  cooldown: 5,
  async execute(message, args) {
    if (activePlayers.has(message.author.id)) {
      return message.reply('Bạn đang tham gia một trò chơi. Vui lòng hoàn thành hoặc đợi lượt chơi hiện tại kết thúc trước khi bắt đầu một lượt chơi mới.');
    }

    const fetch = await import('node-fetch').then(mod => mod.default);
    const apiKeys = [
      'zazkCB7r3srXQeCTknP66A==X8T8Do6MRMPfVv4u',
      'TpnHZrNXL0p9NUN2pQdOwA==Z8HmChG11zw4tgxQ',
      'njaebZrRqUZKKtF5tBILIQ==gEME5ZqUx9ofvPyp',
      'dya/hzG1miX2lQv1Hl7iKQ==BofNbav7VUypzNCE'
    ];

    let maxWordLength = 6;
    if (args[0] && !isNaN(args[0])) {
      maxWordLength = parseInt(args[0]);
    }

    let targetWord = '';
    let wordLength = 0;

    const searchingEmbed = new EmbedBuilder()
      .setColor('#FFA500')
      .setTitle('Trò Chơi Tìm Từ')
      .setDescription(`Bot đang tìm một từ có số chữ cái từ 2 đến ${maxWordLength}...`)
      .setTimestamp();

    const messageEmbed = await message.channel.send({ embeds: [searchingEmbed] });

    try {
      while (wordLength > maxWordLength || wordLength < 2) {
        targetWord = await fetchWordFromApis(apiKeys);
        wordLength = targetWord.length;
      }
    } catch (error) {
      console.error('Error fetching word from APIs:', error);
      return message.channel.send('Không thể tìm thấy từ phù hợp. Vui lòng thử lại sau.');
    }

    let attempts = 0;
    const maxAttempts = 6;
    activePlayers.add(message.author.id);

    const filter = response => {
      return response.author.id === message.author.id && response.content.length === wordLength;
    };

    const sendHint = (guess, target) => {
      let hint = '';
      for (let i = 0; i < wordLength; i++) {
        if (guess[i] === target[i]) {
          hint += '🟩'; // Đúng vị trí
        } else if (target.includes(guess[i])) {
          hint += '🟨'; // Đúng chữ cái nhưng sai vị trí
        } else {
          hint += '🟥'; // Sai chữ cái
        }
      }
      return hint;
    };

    const foundWordEmbed = new EmbedBuilder()
      .setColor('#FFB6C1')
      .setTitle('Trò Chơi Tìm Từ')
      .setDescription(`Bot đã chọn một từ với ${wordLength} chữ cái. Hãy đoán từ đó! Bạn có ${maxAttempts} cơ hội.`)
      .setTimestamp();

    await messageEmbed.edit({ embeds: [foundWordEmbed] });

    while (attempts < maxAttempts) {
      try {
        const collected = await message.channel.awaitMessages({ filter, max: 1, time: 30000, errors: ['time'] });
        const guess = collected.first().content.toUpperCase();
        attempts++;

        if (guess === targetWord) {
          activePlayers.delete(message.author.id);
          return message.channel.send('🟩🟩🟩 Chúc mừng! Bạn đã đoán đúng từ!');
        }

        const hint = sendHint(guess, targetWord);
        await message.channel.send(`${hint} (Còn lại ${maxAttempts - attempts} cơ hội)`);

        if (attempts >= maxAttempts) {
          activePlayers.delete(message.author.id);
          return message.channel.send(`Bạn đã hết cơ hội. Từ đúng là: ${targetWord}`);
        }
      } catch (error) {
        console.error(error);
        activePlayers.delete(message.author.id);
        return message.channel.send('Bạn đã hết thời gian để đoán.');
      }
    }

    activePlayers.delete(message.author.id);
  }
};
async function fetchWordFromApis(apiKeys) {
  const url = 'https://api.api-ninjas.com/v1/randomword';
  for (const apiKey of apiKeys) {
    try {
      const response = await fetch(url, { headers: { 'X-Api-Key': apiKey } });
      if (!response.ok) throw new Error('Network response was not ok');
      const data = await response.json();
      console.log(data);  // Ghi log phản hồi để kiểm tra cấu trúc

      if (data.word && Array.isArray(data.word) && data.word[0]) {
        return data.word[0].toUpperCase();
      }
    } catch (error) {
      console.error(`Error fetching word with API key ${apiKey}:`, error);
    }
  }
  throw new Error('All API keys failed');
}


// const { EmbedBuilder } = require('discord.js');

// let activePlayers = new Set();

// module.exports = {
//   name: 'timchu',
//   description: 'Trò chơi tìm từ',
//   category: 'Fun/Games',
//     cooldown: 5,
//   async execute(message, args) {
//     if (activePlayers.has(message.author.id)) {
//       return message.reply('Bạn đang tham gia một trò chơi. Vui lòng hoàn thành hoặc đợi lượt chơi hiện tại kết thúc trước khi bắt đầu một lượt chơi mới.');
//     }

//     const fetch = await import('node-fetch').then(mod => mod.default);
//     const apiKey = 'zazkCB7r3srXQeCTknP66A==X8T8Do6MRMPfVv4u';  // Thay bằng API key thực tế của bạn

//     let maxWordLength = 6;
//     if (args[0] && !isNaN(args[0])) {
//       maxWordLength = parseInt(args[0]);
//     }

//     let targetWord = '';
//     let wordLength = 0;

//     const searchingEmbed = new EmbedBuilder()
//       .setColor('#FFA500')
//       .setTitle('Trò Chơi Tìm Từ')
//       .setDescription(`Bot đang tìm một từ có số chữ cái từ 2 đến ${maxWordLength}...`)
//       .setTimestamp();

//     const messageEmbed = await message.channel.send({ embeds: [searchingEmbed] });

//     // Lặp cho đến khi tìm được từ có độ dài từ 2 đến maxWordLength chữ cái
//     while (wordLength > maxWordLength || wordLength < 2) {
//       const response = await fetch('https://api.api-ninjas.com/v1/randomword', {
//         headers: { 'X-Api-Key': apiKey }
//       });
//       const data = await response.json();
//       console.log(data);  // Ghi log phản hồi để kiểm tra cấu trúc

//       // Truy cập đúng cách vào từ trong mảng
//       if (data.word && Array.isArray(data.word) && data.word[0]) {
//         targetWord = data.word[0].toUpperCase();
//         wordLength = targetWord.length;
//       }
//     }

//     let attempts = 0;
//     const maxAttempts = 5;
//     activePlayers.add(message.author.id);

//     const filter = response => {
//       return response.author.id === message.author.id && response.content.length === wordLength;
//     };

//     const sendHint = (guess, target) => {
//       let hint = '';
//       for (let i = 0; i < wordLength; i++) {
//         if (guess[i] === target[i]) {
//           hint += '🟩'; // Đúng vị trí
//         } else if (target.includes(guess[i])) {
//           hint += '🟨'; // Đúng chữ cái nhưng sai vị trí
//         } else {
//           hint += '🟥'; // Sai chữ cái
//         }
//       }
//       return hint;
//     };

//     const foundWordEmbed = new EmbedBuilder()
//       .setColor('#FFB6C1')
//       .setTitle('Trò Chơi Tìm Từ')
//       .setDescription(`Bot đã chọn một từ với ${wordLength} chữ cái. Hãy đoán từ đó! Bạn có ${maxAttempts} cơ hội.`)
//       .setTimestamp();

//     await messageEmbed.edit({ embeds: [foundWordEmbed] });

//     while (attempts < maxAttempts) {
//       try {
//         const collected = await message.channel.awaitMessages({ filter, max: 1, time: 30000, errors: ['time'] });
//         const guess = collected.first().content.toUpperCase();
//         attempts++;

//         if (guess === targetWord) {
//           activePlayers.delete(message.author.id);
//           return message.channel.send('🟩🟩🟩 Chúc mừng! Bạn đã đoán đúng từ!');
//         }

//         const hint = sendHint(guess, targetWord);
//         await message.channel.send(`${hint} (Còn lại ${maxAttempts - attempts} cơ hội)`);

//         if (attempts >= maxAttempts) {
//           activePlayers.delete(message.author.id);
//           return message.channel.send(`Bạn đã hết cơ hội. Từ đúng là: ${targetWord}`);
//         }
//       } catch (error) {
//         console.error(error);
//         activePlayers.delete(message.author.id);
//         return message.channel.send('Bạn đã hết thời gian để đoán.');
//       }
//     }

//     activePlayers.delete(message.author.id);
//   }
// };
