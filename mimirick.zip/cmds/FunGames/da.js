const { EmbedBuilder } = require('discord.js');
const fetch = require('node-fetch');

module.exports = {
    name: 'da',
    description: 'Đá một người dùng',
    category: 'Fun/Games',
    cooldown: 5,
    async execute(message, args) { 
        const user = message.mentions.users.first();
        if (!user) {
            return message.reply('Bạn cần tag một người dùng để đá.');
        }

        if (user.id === message.author.id) {
            return message.reply('Bạn không thể tự đá chính mình.');
        }

        const gif = await getGif('kick');

        const embed = new EmbedBuilder()
            .setColor('#FF69B4')
            .setDescription(`<@${message.author.id}> muốn đá <@${user.id}>`)
            .setImage(gif)
            .setTimestamp();

        message.channel.send({ embeds: [embed] });
    },
};

async function getGif(action) {
    const useGiphy = Math.random() > 0.5;

    if (useGiphy) {
        const response = await fetch(`https://api.giphy.com/v1/gifs/random?api_key=EUO3OirxU8XwZRR7ZdTes73gRWmJr8Hz&tag=${action}&rating=g`);
        const data = await response.json();
        return data.data.images.original.url;
    } else {
        try{
            const response = await fetch(`https://nekos.life/api/v2/img/${action}`);
            const data = await response.json();
            return data.url;
        } catch (error) {
            console.error(error)
            const response = await fetch(`https://api.giphy.com/v1/gifs/random?api_key=EUO3OirxU8XwZRR7ZdTes73gRWmJr8Hz&tag=${action}&rating=g`);
            const data = await response.json();
            return data.data.images.original.url;
        }
    }
}
