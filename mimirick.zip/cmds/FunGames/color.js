const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');

module.exports = {
    name: 'color',
    description: 'Hiển thị bảng màu hex cho phép người dùng chọn và lấy mã màu.',
    category: 'Fun/Games',
    cooldown: 5,
    aliases: [],
    async execute(message) { 
        const colors = [
            { name: 'Red', hex: '#FF0000' },
            { name: 'Green', hex: '#00FF00' },
            { name: 'Blue', hex: '#0000FF' },
            { name: 'Yellow', hex: '#FFFF00' },
            { name: 'Cyan', hex: '#00FFFF' },
            { name: 'Magenta', hex: '#FF00FF' },
            { name: 'Random', hex: `#${Math.floor(Math.random() * 16777215).toString(16)}` }
        ];

        const embed = new EmbedBuilder()
            .setTitle('Chọn màu')
            .setColor('#FFB6C1')
            .setDescription('Bấm vào một trong các nút bên dưới để chọn màu.');

        const row = new ActionRowBuilder().addComponents(
            colors.map(color => new ButtonBuilder()
                .setCustomId(color.name.toLowerCase())
                .setLabel(color.name)
                .setStyle(ButtonStyle.Primary)
                .setCustomId(color.hex)
            )
        );

        const responseMessage = await message.channel.send({ embeds: [embed], components: [row] });

        const collector = responseMessage.createMessageComponentCollector({ componentType: ComponentType.Button, time: 60000 });

        collector.on('collect', async interaction => {
            const selectedColor = colors.find(color => color.hex === interaction.customId);
            const colorEmbed = new EmbedBuilder()
                .setTitle(`Màu bạn đã chọn: ${selectedColor.name}`)
                .setDescription(`Mã màu: ${selectedColor.hex}`)
                .setColor(selectedColor.hex);

            await interaction.update({ embeds: [colorEmbed], components: [] });
        });

        collector.on('end', () => {
            responseMessage.edit({ components: [] });
        });
    },
};
