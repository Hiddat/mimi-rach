const fs = require('fs');
const path = require('path');
const moment = require('moment');
const gameDataPath = path.resolve(__dirname, '../../gameData.json');
const upgradeFilePath = path.resolve(__dirname, '../../upgradeloto.json');
const activeGames = new Map(); // Lưu trữ các trò chơi đang hoạt động

module.exports = {
  name: 'loto',
  category: 'Fun/Games',
  cooldown: 60,
  description: 'Chơi trò chơi Lô Tô',
  async execute(message, args) {
    const players = message.mentions.users;
    const mimiBot = { id: '1207923287519268875', username: 'Mimi#0462' }; // Tạo object cho bot

    // Kiểm tra xem có thể bắt đầu trò chơi không
    const gameStatus = canStartGame(message.guild);

    if (!gameStatus.canStart) {
      await message.channel.send(gameStatus.reason);
      return;
    }

    // Nếu không tag ai hoặc cú pháp sai -> Chơi với Mimi Bot
    if (players.size === 0 || players.size > 2) {
      message.channel.send(`Bạn sẽ chơi với <@1207923287519268875>!`);
      const mimiBots = '1207923287519268875';
      let specificUser;
      specificUser = await message.client.users.fetch(mimiBots);
      startGame(message.author, specificUser, message); // Bắt đầu trò chơi với bot
      return;
    }

    // Nếu chỉ có 1 người được tag
    if (players.size === 1) {
      const taggedPlayer = players.first();
      startGame(message.author, taggedPlayer, message);
    }

    // Nếu có 2 người được tag
    if (players.size === 2) {
      const [player1, player2] = players;
      startGame(player1, player2, message);
    }
  }
};

// Các hàm liên quan tới trò chơi và quản lý trạng thái

function loadGamesFromJson() {
  if (!fs.existsSync(gameDataPath)) {
    return;
  }

  const jsonData = JSON.parse(fs.readFileSync(gameDataPath, 'utf8'));
  const gamesData = jsonData.games;

  Object.keys(gamesData).forEach(guildId => {
    if (!activeGames.has(guildId)) {
      activeGames.set(guildId, new Map());
    }

    const serverGames = activeGames.get(guildId);

    Object.keys(gamesData[guildId]).forEach(threadId => {
      const game = gamesData[guildId][threadId];
      serverGames.set(threadId, {
        players: game.players.map(id => ({ id })),
        guessedNumbers: game.guessedNumbers,
        lotoCards: game.lotoCards,
        threadLink: game.threadLink
      });
    });
  });
}

function saveGamesToJson(activeGames) {
  const jsonData = {};

  activeGames.forEach((serverGames, guildId) => {
    jsonData[guildId] = {};

    serverGames.forEach((gameData, threadId) => {
      jsonData[guildId][threadId] = {
        players: gameData.players.map(player => player.id),
        guessedNumbers: gameData.guessedNumbers,
        lotoCards: gameData.lotoCards,
        threadLink: gameData.threadLink
      };
    });
  });

  fs.writeFileSync(gameDataPath, JSON.stringify({ games: jsonData }, null, 2));
}

function isPremiumServer(guildId) {
  const data = JSON.parse(fs.readFileSync(upgradeFilePath));
  const upgradeInfo = data.upgrades.find(upgrade => upgrade.serverId === guildId);

  if (!upgradeInfo) {
    return false;
  }

  const expiresAt = moment(upgradeInfo.expiresAt);
  const now = moment();
  return now.isBefore(expiresAt);
}

function canStartGame(guild) {
  const guildId = guild.id;
  const memberCount = guild.memberCount;

  const serverGames = activeGames.get(guildId) || new Map();
  const activeGameCount = serverGames.size;

  const hasPremium = isPremiumServer(guildId);

  if (!hasPremium) {
    if (memberCount < 200) {
      return { canStart: false, reason: "Server có dưới 200 thành viên và không có gói Premium." };
    } else if (activeGameCount >= 3) {
      return { canStart: false, reason: "Server không có Premium, chỉ được phép tối đa 3 trò chơi hoạt động cùng lúc." };
    }
  } else {
    if (activeGameCount >= 15) {
      return { canStart: false, reason: "Server có Premium, nhưng đã đạt giới hạn 15 trò chơi hoạt động cùng lúc." };
    }
  }

  return { canStart: true };
}

async function startGame(player1, player2, message) {
  const thread = await message.channel.threads.create({
    name: `${player1.username} vs ${player2.username}`,
    autoArchiveDuration: 60,
    reason: 'Trò chơi Lô Tô giữa hai người chơi',
  });

  const guildId = message.guild.id;
  const threadId = thread.id;

  if (!activeGames.has(guildId)) {
    activeGames.set(guildId, new Map());
  }

  const serverGames = activeGames.get(guildId);
  serverGames.set(threadId, {
    players: [player1, player2],
    guessedNumbers: [],
    lotoCards: {
      [player1.id]: generateLotoCard(),
      [player2.id]: generateLotoCard()
    },
    threadLink: thread.url
  });

  saveGamesToJson(activeGames);

  sendLotoCard(player1, serverGames.get(threadId).lotoCards[player1.id]);
  sendLotoCard(player2, serverGames.get(threadId).lotoCards[player2.id]);

  startTurn(player1, player2, thread);
  setGameTimeout(thread);
}

function endGame(thread, message, guildId) {
  thread.send(message);

  const threadId = thread.id;
  const serverGames = activeGames.get(guildId);

  if (serverGames) {
    serverGames.delete(threadId);
    if (serverGames.size === 0) {
      activeGames.delete(guildId);
    }
  }

  saveGamesToJson(activeGames);

  setTimeout(() => {
    thread.setArchived(true);
  }, 3 * 60 * 1000); // Đóng thread sau 3 phút
}

function sendLotoCard(player, lotoCard) {
  const lotoCardMessage = `Đây là tấm Lô Tô của bạn:\n${formatLotoCard(lotoCard)}\nChúc bạn may mắn!`;
  player.send(lotoCardMessage).catch(console.error);
}

function generateLotoCard() {
  let card = [];
  for (let i = 0; i < 3; i++) {
    let row = [];
    for (let j = 0; j < 9; j++) {
      row.push(Math.floor(Math.random() * 90) + 1);
    }
    card.push(row);
  }
  return card;
}

function formatLotoCard(lotoCard) {
  return lotoCard.map(row => row.join(' | ')).join('\n');
}

// Hàm bắt đầu lượt và để bot tự chọn số khi đến lượt của nó
async function startTurn(player1, player2, thread) {
  const players = [player1, player2];
  let currentTurn = 0;
  const guildId = thread.guildId;
  const threadId = thread.id;

  async function handleTurn(player) {
    const serverGames = activeGames.get(guildId);
    const gameData = serverGames.get(threadId);
    const guessedNumbers = gameData.guessedNumbers;

    if (player.id === '1207923287519268875') {
      // Bot tự động chọn số
      const availableNumbers = Array.from({ length: 90 }, (_, i) => i + 1).filter(num => !guessedNumbers.includes(num));
      const botChoice = availableNumbers[Math.floor(Math.random() * availableNumbers.length)];

      await thread.send(`<@1207923287519268875> chọn số: ${botChoice}`);
      guessedNumbers.push(botChoice);
      gameData.guessedNumbers = guessedNumbers;
      checkWinCondition(player, botChoice, thread, guildId, threadId);

      currentTurn = (currentTurn + 1) % players.length;
      handleTurn(players[currentTurn]);
      return;
    }

    // Xử lý lượt của người chơi
    await thread.send(`Danh sách số đã đoán: ${guessedNumbers.length ? guessedNumbers.join(', ') : 'Chưa có số nào được đoán'}`);
    await thread.send(`Đến lượt của <@${player.id}>! Vui lòng chọn một số từ 1 đến 90 mà chưa được đoán.`);

    const filter = response => response.author.id === player.id && !isNaN(response.content) && response.content >= 1 && response.content <= 90;
    const collector = thread.createMessageCollector({ filter, time: 60000 });

    collector.on('collect', response => {
      const chosenNumber = parseInt(response.content);

      if (guessedNumbers.includes(chosenNumber)) {
        thread.send(`<@${player.id}>, số ${chosenNumber} đã được đoán. Vui lòng chọn số khác.`);
      } else {
        guessedNumbers.push(chosenNumber);
        gameData.guessedNumbers = guessedNumbers;
        checkWinCondition(player, chosenNumber, thread, guildId, threadId);

        currentTurn = (currentTurn + 1) % players.length;
        handleTurn(players[currentTurn]);
        collector.stop();
      }
    });

    collector.on('end', collected => {
      if (!collected.size) {
        thread.send(`Lượt của <@${player.id}> đã kết thúc vì không phản hồi. Chuyển lượt cho người chơi tiếp theo.`);
        currentTurn = (currentTurn + 1) % players.length;
        handleTurn(players[currentTurn]);
      }
    });
  }

  handleTurn(players[currentTurn]);
}

function setGameTimeout(thread) {
  const gameDuration = 90 * 60 * 1000; // 90 phút
  setTimeout(() => {
    thread.send(`Trò chơi đã kết thúc do vượt quá thời gian 90 phút.`);
    endGame(thread, 'Trò chơi đã kết thúc tự động.', thread.guildId);
  }, gameDuration);
}

function checkWinCondition(player, chosenNumber, thread, guildId, threadId) {
  const serverGames = activeGames.get(guildId);
  const gameData = serverGames.get(threadId);
  const lotoCard = gameData.lotoCards[player.id];

  lotoCard.forEach(row => {
    for (let i = 0; i < row.length; i++) {
      if (row[i] === chosenNumber) {
        row[i] = 'X'; // Đánh dấu số đã chọn
      }
    }
  });

  const oneRowComplete = lotoCard.some(row => row.every(cell => cell === 'X'));
  const twoRowsComplete = lotoCard.filter(row => row.every(cell => cell === 'X')).length === 2;
  const fullHouse = lotoCard.every(row => row.every(cell => cell === 'X'));

  if (fullHouse) {
    thread.send(`<@${player.id}> đã hoàn thành **full house** và chiến thắng trò chơi!`);
    endGame(thread, `Trò chơi đã kết thúc. Người chiến thắng là <@${player.id}>!`, guildId);
  } else if (twoRowsComplete) {
    thread.send(`<@${player.id}> đã hoàn thành **hai hàng**!`);
  } else if (oneRowComplete) {
    thread.send(`<@${player.id}> đã hoàn thành **một hàng**!`);
  }
}
