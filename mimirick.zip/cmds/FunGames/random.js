module.exports = {
    name: 'random',
    aliases: ['rd'],
    category: 'Fun/Games',
    cooldown: 5,
    description: 'Trả về một số ngẫu nhiên từ 1 đến số mà bạn dùng nhập.',
    execute(message, args) {
        // Kiểm tra xem người dùng có cung cấp tham số hay không
        if (!args[0]) {
            return message.reply('Bạn cần cung cấp một số để random.');
        }

        // Chuyển đổi tham số thành số nguyên
        const max = parseInt(args[0]);
        if (isNaN(max) || max <= 0) {
            return message.reply('Bạn cần cung cấp một số nguyên lớn hơn 0.');
        }

        // Tạo số ngẫu nhiên từ 1 đến max
        const randomNumber = Math.floor(Math.random() * max) + 1;
        message.reply(`<a:tick:1254376731356430361> Số random của bạn là: ${randomNumber}`);
    },
};
