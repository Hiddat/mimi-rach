const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'rollthedice',
  aliases: ['rtd'],
  cooldown: 10,
  description: 'Chơi trò chơi Roll the Dice để giải trí.',
 category: 'Fun/Games',
  async execute(message, args) { 
    const user = message.author;

    // Tạo số ngẫu nhiên từ 1 đến 12 để mô phỏng lắc xúc xắc
    const roll = Math.floor(Math.random() * 12) + 1;
    const embed = new EmbedBuilder()
      .setColor('#FFB6C1')
      .setTitle('🎲 Roll the Dice 🎲')
      .setDescription(`Bạn đã lắc xúc xắc và ra số ${roll}. Hãy đoán xem số tiếp theo sẽ là bao nhiêu (từ 1 đến 12)?`)
      .setTimestamp();

    const msg = await message.channel.send({ embeds: [embed] });

    const filter = response => {
      return response.author.id === user.id && !isNaN(response.content) && parseInt(response.content) >= 1 && parseInt(response.content) <= 12;
    };

    try {
      const collected = await message.channel.awaitMessages({ filter, max: 1, time: 15000, errors: ['time'] });
      const userGuess = parseInt(collected.first().content);
      const newRoll = Math.floor(Math.random() * 12) + 1;
      let resultMessage;

      if (userGuess === newRoll) {
        resultMessage = `Xúc xắc ra số ${newRoll}. Bạn đã đoán đúng! Chúc mừng bạn! 🎉`;
      } else {
        resultMessage = `Xúc xắc ra số ${newRoll}. Bạn đã đoán sai! Thử lại lần sau nhé!`;
      }

      const resultEmbed = new EmbedBuilder()
        .setColor('#FFB6C1')
        .setTitle('🎲 Roll the Dice 🎲')
        .setDescription(resultMessage)
        .setTimestamp()
        .setFooter({ text: 'Chúc may mắn lần sau!' });

      await msg.edit({ embeds: [resultEmbed] });
    } catch (err) {
      message.channel.send('Bạn đã hết thời gian để đoán.');
    }
  }
};
