const { EmbedBuilder } = require('discord.js');
const getGif = require('../../utils/getGif');

module.exports = {
    name: 'wave',
    description: 'Vẫy tay chào',
    category: 'Fun/Games',
    aliases: ['hello'],
    cooldown: 5,
    async execute(message, args) { 
        const gif = await getGif('wave');

        const embed = new EmbedBuilder()
            .setColor('#FF69B4')
            .setDescription(`<@${message.author.id}> đang vẫy tay chào`)
            .setImage(gif)
            .setTimestamp();

        message.channel.send({ embeds: [embed] });
    },
};
