const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'roulette',
  aliases: ['rl'],
  description: 'Chơi trò chơi Roulette để giải trí.',
 category: 'Fun/Games',
  cooldown: 10,
  async execute(message, args) {
    const user = message.author;

    const choices = ['red', 'black', 'green'];
    const betChoice = args[1] && choices.includes(args[1].toLowerCase()) ? args[1].toLowerCase() : 'red';

    // Add a rolling animation
    const rollEmbed = new EmbedBuilder()
      .setColor('#FFB6C1')
      .setTitle('🎰 Roulette 🎰')
      .setDescription('🎡 Đang quay...')
      .setTimestamp();

    const rollMessage = await message.channel.send({ embeds: [rollEmbed] });

    // Simulate the roulette roll
    setTimeout(async () => {
      const roll = Math.random();
      let result;

      if (roll < 0.47) {
        result = 'red';
      } else if (roll < 0.94) {
        result = 'black';
      } else {
        result = 'green';
      }

      let resultMessage;

      if (result === betChoice) {
        resultMessage = `Kết quả là ${result}. Bạn đã đoán đúng! Chúc mừng bạn! 🎉`;
      } else {
        resultMessage = `Kết quả là ${result}. Bạn đã đoán sai! Thử lại lần sau nhé!`;
      }

      const resultEmbed = new EmbedBuilder()
        .setColor('#FFB6C1')
        .setTitle('🎰 Roulette 🎰')
        .setDescription(resultMessage)
        .setTimestamp()
        .setFooter({ text: 'Chúc may mắn lần sau!' });

      await rollMessage.edit({ embeds: [resultEmbed] });
    }, 3000); // 3 seconds delay for the rolling animation
  }
};
