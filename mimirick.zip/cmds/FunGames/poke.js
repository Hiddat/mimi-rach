const { EmbedBuilder } = require('discord.js');
const getGif = require('../../utils/getGif');

module.exports = {
    name: 'poke',
    description: 'Chọc một người dùng',
    category: 'Fun/Games',
    aliases: ['prod'],
    cooldown: 5,
    async execute(message, args) { 
        const user = message.mentions.users.first();
        if (!user) {
            return message.reply('Bạn cần tag một người dùng để chọc.');
        }

        if (user.id === message.author.id) {
            return message.reply('Bạn không thể tự chọc chính mình.');
        }

        const gif = await getGif('poke');

        const embed = new EmbedBuilder()
            .setColor('#FF69B4')
            .setDescription(`<@${message.author.id}> muốn chọc <@${user.id}>`)
            .setImage(gif)
            .setTimestamp();

        message.channel.send({ embeds: [embed] });
    },
};
