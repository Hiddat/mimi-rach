const { EmbedBuilder } = require('discord.js');
const fetch = require('node-fetch');

const games = new Map();

module.exports = {
    name: 'teamtrivia',
    description: 'Trò chơi đố vui đồng đội',
    category: 'Fun/Games',
    aliases: ['triviateam', 'ttrivia'],
    cooldown: 5,
    async execute(message, args) {
        if (games.has(message.channel.id)) {
            return message.reply('Hiện tại đã có một trò chơi đố vui trong kênh này. Vui lòng chờ đến khi kết thúc trò chơi.');
        }

        const response = await fetch('https://opentdb.com/api.php?amount=1&type=multiple');
        const data = await response.json();
        const trivia = data.results[0];
        const correctAnswer = trivia.correct_answer;
        const answers = [...trivia.incorrect_answers, correctAnswer].sort(() => Math.random() - 0.5);

        const triviaEmbed = new EmbedBuilder()
            .setColor('#FFA500')
            .setTitle('Team Trivia')
            .setDescription(`${trivia.question}\n${answers.map((ans, i) => `**${String.fromCharCode(65 + i)}.** ${ans}`).join('\n')}`)
            .setTimestamp();

        const msg = await message.channel.send({ embeds: [triviaEmbed] });

        games.set(message.channel.id, {
            correctAnswer,
            msg,
            triviaEmbed
        });

        const filter = response => {
            return response.author.id !== message.author.bot && /^[A-D]$/i.test(response.content);
        };

        const collector = message.channel.createMessageCollector({ filter, time: 60000 });

        collector.on('collect', async m => {
            const game = games.get(message.channel.id);
            const answerIndex = m.content.toUpperCase().charCodeAt(0) - 65;
            const answer = answers[answerIndex];

            if (answer === game.correctAnswer) {
                collector.stop();
                games.delete(message.channel.id);
                return message.channel.send(`Chúc mừng! Bạn đã trả lời đúng: ${game.correctAnswer}`);
            } else {
                return message.channel.send(`Sai rồi! ${m.author}, hãy thử lại.`);
            }
        });

        collector.on('end', collected => {
            if (collected.size === 0) {
                message.reply('Trò chơi đã hết thời gian.');
                games.delete(message.channel.id);
            } else {
                message.channel.send(`Trò chơi kết thúc! Đáp án đúng là: ${games.get(message.channel.id).correctAnswer}`);
                games.delete(message.channel.id);
            }
        });
    }
};
