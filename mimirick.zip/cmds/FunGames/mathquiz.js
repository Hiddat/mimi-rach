const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'mathquiz',
    description: 'Trò chơi đố vui toán học',
    category: 'Fun/Games',
    cooldown: 5,
    async execute(message, args) {
        const generateQuestion = () => {
            const num1 = Math.floor(Math.random() * 10) + 1;
            const num2 = Math.floor(Math.random() * 10) + 1;
            const operators = ['+', '-', '*'];
            const operator = operators[Math.floor(Math.random() * operators.length)];
            let answer;
            switch (operator) {
                case '+':
                    answer = num1 + num2;
                    break;
                case '-':
                    answer = num1 - num2;
                    break;
                case '*':
                    answer = num1 * num2;
                    break;
            }
            return {
                question: `${num1} ${operator} ${num2}`,
                answer: answer
            };
        };

        const quiz = generateQuestion();
        const filter = response => {
            return response.author.id === message.author.id && !isNaN(response.content);
        };

        const questionEmbed = new EmbedBuilder()
            .setColor('#FFA500')
            .setTitle('Math Quiz')
            .setDescription(`Giải bài toán sau: ${quiz.question}`)
            .setTimestamp();

        await message.channel.send({ embeds: [questionEmbed] });

        try {
            const collected = await message.channel.awaitMessages({ filter, max: 1, time: 15000, errors: ['time'] });
            const answer = parseInt(collected.first().content);

            if (answer === quiz.answer) {
                return message.channel.send('Chính xác! Bạn thật thông minh!');
            } else {
                return message.channel.send(`Sai rồi! Đáp án đúng là ${quiz.answer}.`);
            }
        } catch (error) {
            return message.channel.send('Bạn đã hết thời gian!');
        }
    }
};
