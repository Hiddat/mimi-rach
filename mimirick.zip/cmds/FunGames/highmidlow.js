const { EmbedBuilder } = require('discord.js');
const cooldowns = new Map();

module.exports = {
  name: 'highmidlow',
  aliases: ['hml'],
  description: 'Chơi trò chơi High-Mid-Low để giải trí.',
 category: 'Fun/Games',
  cooldown: 10,
  async execute(message) { 
    const user = message.author;

    const initialNumber = Math.floor(Math.random() * 100) + 1;
    const guess = await message.channel.send(`Số hiện tại là ${initialNumber}. Bạn đoán số tiếp theo sẽ cao hơn (high), thấp hơn (low) hay ở giữa (mid)?`);

    const filter = response => {
      return response.author.id === user.id && ['high', 'low', 'mid'].includes(response.content.toLowerCase());
    };

    try {
      const collected = await message.channel.awaitMessages({ filter, max: 1, time: 15000, errors: ['time'] });
      const response = collected.first().content.toLowerCase();
      let newNumber = Math.floor(Math.random() * 100) + 1;
      let resultMessage;

      const isCorrectGuess = 
        (response === 'high' && newNumber > initialNumber) || 
        (response === 'low' && newNumber < initialNumber) || 
        (response === 'mid' && newNumber > initialNumber - 10 && newNumber < initialNumber + 10);

      if (isCorrectGuess) {
        resultMessage = `Số tiếp theo là ${newNumber}. Bạn đã đoán đúng! Chúc mừng bạn! 🎉`;
      } else {
        resultMessage = `Số tiếp theo là ${newNumber}. Bạn đã đoán sai! Thử lại lần sau nhé!`;
      }

      const resultEmbed = new EmbedBuilder()
        .setColor('#FFB6C1')
        .setTitle('🎲 High-Mid-Low 🎲')
        .setDescription(resultMessage)
        .setTimestamp()
        .setFooter({ text: 'Chúc may mắn lần sau!' });

      await guess.edit({ embeds: [resultEmbed] });
      cooldowns.set(user.id, Date.now());

    } catch (err) {
      message.channel.send('Bạn đã hết thời gian để đoán.');
    }
  }
};
