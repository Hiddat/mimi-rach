const { EmbedBuilder } = require('discord.js');
const cooldowns = new Map();

module.exports = {
  name: 'diceroll',
  aliases: ['dr'],
  cooldown: 10,
  description: 'Chơi trò chơi Dice Roll để giải trí.',
 category: 'Fun/Games',
  async execute(message) { 
    const user = message.author;

    const guess = await message.channel.send(`Bạn đoán số xúc xắc là gì (1-6)?`);

    const filter = response => {
      return response.author.id === user.id && !isNaN(response.content) && parseInt(response.content) >= 1 && parseInt(response.content) <= 6;
    };

    try {
      const collected = await message.channel.awaitMessages({ filter, max: 1, time: 15000, errors: ['time'] });
      const response = parseInt(collected.first().content);
      const newRoll = Math.floor(Math.random() * 6) + 1;
      let resultMessage;

      if (response === newRoll) {
        resultMessage = `Xúc xắc là ${newRoll}. Bạn đã đoán đúng! 🎉`;
      } else {
        resultMessage = `Xúc xắc là ${newRoll}. Bạn đã đoán sai! Thử lại lần sau nhé!`;
      }

      const resultEmbed = new EmbedBuilder()
        .setColor('#FFB6C1')
        .setTitle('🎲 Dice Roll 🎲')
        .setDescription(resultMessage)
        .setTimestamp()
        .setFooter({ text: 'Chúc may mắn lần sau!' });

      await guess.edit({ embeds: [resultEmbed] });
      cooldowns.set(user.id, Date.now());

    } catch (err) {
      message.channel.send('Bạn đã hết thời gian để đoán.');
    }
  }
};
