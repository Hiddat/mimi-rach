const { EmbedBuilder } = require('discord.js');
const getGif = require('../../utils/getGif');

module.exports = {
    name: 'hug',
    description: 'Ôm một người dùng',
    category: 'Fun/Games',
    aliases: ['embrace'],
    cooldown: 5,
    async execute(message, args) { 
        const user = message.mentions.users.first();
        if (!user) {
            return message.reply('Bạn cần tag một người dùng để ôm.');
        }

        if (user.id === message.author.id) {
            return message.reply('Bạn không thể tự ôm chính mình.');
        }

        const gif = await getGif('hug');

        const embed = new EmbedBuilder()
            .setColor('#FF69B4')
            .setDescription(`<@${message.author.id}> muốn ôm <@${user.id}>`)
            .setImage(gif)
            .setTimestamp();

        message.channel.send({ embeds: [embed] });
    },
};
