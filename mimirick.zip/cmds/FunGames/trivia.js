const { EmbedBuilder } = require('discord.js');
const fetch = require('node-fetch');

module.exports = {
    name: 'trivia',
    description: 'Trò chơi đố vui kiến thức',
    category: 'Fun/Games',
    aliases: ['quiz'],
    cooldown: 5,
    async execute(message, args) {
        const response = await fetch('https://opentdb.com/api.php?amount=1&type=multiple');
        const data = await response.json();
        const trivia = data.results[0];
        const correctAnswer = trivia.correct_answer;
        const answers = [...trivia.incorrect_answers, correctAnswer].sort(() => Math.random() - 0.5);

        const filter = response => {
            return response.author.id === message.author.id && answers.includes(response.content);
        };

        const triviaEmbed = new EmbedBuilder()
            .setColor('#FFA500')
            .setTitle('Trivia Quiz')
            .setDescription(`${trivia.question}\n${answers.join('\n')}`)
            .setTimestamp();

        await message.channel.send({ embeds: [triviaEmbed] });

        try {
            const collected = await message.channel.awaitMessages({ filter, max: 1, time: 15000, errors: ['time'] });
            const answer = collected.first().content;

            if (answer === correctAnswer) {
                return message.channel.send('Chính xác! Bạn thật thông minh!');
            } else {
                return message.channel.send(`Sai rồi! Đáp án đúng là ${correctAnswer}.`);
            }
        } catch (error) {
            return message.channel.send('Bạn đã hết thời gian!');
        }
    }
};
