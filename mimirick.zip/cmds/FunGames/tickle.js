const { EmbedBuilder } = require('discord.js');
const getGif = require('../../utils/getGif');

module.exports = {
    name: 'tickle',
    description: 'Cù léc một người dùng',
    category: 'Fun/Games',
    aliases: ['tease'],
    cooldown: 5,
    async execute(message, args) { 
        const user = message.mentions.users.first();
        if (!user) {
            return message.reply('Bạn cần tag một người dùng để cù léc.');
        }

        if (user.id === message.author.id) {
            return message.reply('Bạn không thể tự cù léc chính mình.');
        }

        const gif = await getGif('tickle');

        const embed = new EmbedBuilder()
            .setColor('#FF69B4')
            .setDescription(`<@${message.author.id}> muốn cù léc <@${user.id}>`)
            .setImage(gif)
            .setTimestamp();

        message.channel.send({ embeds: [embed] });
    },
};
