const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'doanso',
  aliases: ['gn', 'guessnumber'],
  cooldown: 10,
  description: 'Chơi trò chơi đoán số để giải trí.',
 category: 'Fun/Games',
  async execute(message) { 
    const user = message.author;

    const numberToGuess = Math.floor(Math.random() * 20) + 1;
    const embed = new EmbedBuilder()
      .setColor('#FFB6C1')
      .setTitle('🔢 Đoán Số 🔢')
      .setDescription('Bot đã chọn một số từ 1 đến 20. Hãy đoán số đó!')
      .setTimestamp();

    const msg = await message.channel.send({ embeds: [embed] });

    const filter = response => {
      return response.author.id === user.id && !isNaN(response.content);
    };

    try {
      const collected = await message.channel.awaitMessages({ filter, max: 1, time: 15000, errors: ['time'] });
      const guess = parseInt(collected.first().content);
      let resultMessage;

      if (guess === numberToGuess) {
        resultMessage = `Bạn đã đoán đúng số! 🎉`;
      } else {
        resultMessage = `Bạn đã đoán sai. Số đúng là ${numberToGuess}. Thử lại lần sau nhé!`;
      }

      const resultEmbed = new EmbedBuilder()
        .setColor('#FFB6C1')
        .setTitle('🔢 Đoán Số 🔢')
        .setDescription(resultMessage)
        .setTimestamp()
        .setFooter({ text: 'Chúc may mắn lần sau!' });

      await msg.edit({ embeds: [resultEmbed] });
    } catch (err) {
      message.channel.send('Bạn đã hết thời gian để đoán.');
    }
  }
};
