const { EmbedBuilder } = require('discord.js');

const words = ['programming', 'javascript', 'discord', 'developer', 'bot'];

module.exports = {
    name: 'anagram',
    description: 'Trò chơi giải ô chữ',
    category: 'Fun/Games',
    aliases: ['jumble', 'wordgame'],
    cooldown: 5,
    async execute(message, args) {
        const word = words[Math.floor(Math.random() * words.length)];
        const shuffled = word.split('').sort(() => Math.random() - 0.5).join('');

        const anagramEmbed = new EmbedBuilder()
            .setColor('#FFA500')
            .setTitle('Trò chơi giải ô chữ')
            .setDescription(`Sắp xếp lại các chữ cái này để tạo thành một từ có nghĩa: \`${shuffled}\``)
            .setTimestamp();

        await message.channel.send({ embeds: [anagramEmbed] });

        const filter = response => {
            return response.author.id === message.author.id && response.content.toLowerCase() === word;
        };

        try {
            const collected = await message.channel.awaitMessages({ filter, max: 1, time: 30000, errors: ['time'] });
            return message.channel.send(`Chúc mừng! Bạn đã đoán đúng từ: ${word}`);
        } catch (error) {
            return message.channel.send(`Bạn đã hết thời gian! Từ đúng là: ${word}`);
        }
    }
};
