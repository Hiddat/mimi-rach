const fs = require('fs');
const path = require('path');
const { defaultCoins } = require('../../config.json');

const voteDataPath = path.join(__dirname, '../../data/uservote.json');
let voteData = {};

if (fs.existsSync(voteDataPath)) {
    voteData = JSON.parse(fs.readFileSync(voteDataPath));
}

module.exports = {
    name: 'pray',
    category: 'Fun/Games',
    cooldown: 3,
    description: 'Cầu nguyện cho một người dùng',
    execute(message, args) {
        if (!args.length) {
            return message.reply('Vui lòng tag người dùng bạn muốn cầu nguyện.');
        }

        const user = message.mentions.users.first();
        if (!user) {
            return message.reply('Vui lòng tag người dùng hợp lệ.');
        }

        const prayerPoints = Math.floor(Math.random() * 101); // Điểm cầu nguyện ngẫu nhiên từ 0 đến 100
        const userId = user.id;
        const usernameTag = user.tag;

        if (!voteData[userId]) {
            voteData[userId] = {
                username: usernameTag,
                userId: userId,
                votes: 0,
                gaveCoins: 0,
                prayerPoints: 0
            };
        }

        voteData[userId].prayerPoints += prayerPoints;

        fs.writeFileSync(voteDataPath, JSON.stringify(voteData, null, 2));

        message.reply(`Bạn đã cầu nguyện cho ${usernameTag} và nhận được ${prayerPoints} điểm cầu nguyện.`);
    }
};
