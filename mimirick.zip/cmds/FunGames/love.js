const { EmbedBuilder, AttachmentBuilder } = require('discord.js');
const Canvas = require('canvas');
const fetch = require('node-fetch');
const sharp = require('sharp');

module.exports = {
    name: 'love',
    description: 'Kiểm tra % tình yêu giữa hai người dùng',
    category: 'Fun/Games',
    cooldown: 5,
    async execute(message, args) {
        let user1, user2;

        const mentions = message.mentions.users;
        if (mentions.size === 1) {
            user1 = message.author;
            user2 = mentions.first();
        } else if (mentions.size === 2) {
            user1 = mentions.first();
            user2 = mentions.last();
        } else {
            user1 = message.author;
            const allMembers = await message.guild.members.fetch();
            const nonBotMembers = allMembers.filter(member => !member.user.bot && member.id !== message.author.id);
            if (nonBotMembers.size === 0) {
                return message.reply('Không có thành viên nào khác trong server để kiểm tra tình yêu.');
            }
            const randomMember = nonBotMembers.random();
            user2 = randomMember ? randomMember.user : null;
        }

        if (!user2) {
            return message.reply('Không thể tìm thấy người dùng phù hợp để kiểm tra tình yêu.');
        }

        if (user1.id === user2.id) {
            return message.reply('Bạn không thể kiểm tra tình yêu với chính mình.');
        }

        const lovePercentage = Math.floor(Math.random() * 101);
        const loveLevel = lovePercentage > 50 ? '💖' : '💔';

        // Define random messages based on love percentage
        const loveMessages = {
            low: [
                "Tình yêu này có vẻ khó khăn rồi...",
                "Không hợp nhau lắm đâu!",
                "Đường tình này không dễ."
            ],
            medium: [
                "Có chút gì đó, nhưng cần cố gắng hơn.",
                "Tình yêu đang chớm nở!",
                "Có tiềm năng, tiếp tục thôi!"
            ],
            high: [
                "Hai bạn rất hợp nhau!",
                "Trời sinh một cặp!",
                "Tình yêu tuyệt vời!"
            ]
        };

        let loveMessage = "";
        if (lovePercentage <= 25) {
            loveMessage = loveMessages.low[Math.floor(Math.random() * loveMessages.low.length)];
        } else if (lovePercentage <= 50) {
            loveMessage = loveMessages.medium[Math.floor(Math.random() * loveMessages.medium.length)];
        } else {
            loveMessage = loveMessages.high[Math.floor(Math.random() * loveMessages.high.length)];
        }

        // Tải ảnh đại diện của người dùng
        const avatar1Buffer = await fetchImageBuffer(user1.displayAvatarURL({ format: 'png', size: 256 }));
        const avatar2Buffer = await fetchImageBuffer(user2.displayAvatarURL({ format: 'png', size: 256 }));

        // Chuyển đổi định dạng ảnh với sharp nếu cần
        const avatar1Converted = await sharp(avatar1Buffer).png().toBuffer();
        const avatar2Converted = await sharp(avatar2Buffer).png().toBuffer();

        // Tạo canvas và vẽ hình ảnh
        const canvas = Canvas.createCanvas(1600, 800);  // Tăng kích thước canvas
        const ctx = canvas.getContext('2d');

        // Vẽ ảnh đại diện của người dùng bên trái và bên phải
        const avatar1Img = await Canvas.loadImage(avatar1Converted);
        const avatar2Img = await Canvas.loadImage(avatar2Converted);

        ctx.save();
        ctx.beginPath();
        ctx.arc(300, 300, 250, 0, Math.PI * 2, true);
        ctx.closePath();
        ctx.clip();
        ctx.drawImage(avatar1Img, 50, 50, 500, 500);  // Điều chỉnh vị trí và kích thước ảnh
        ctx.restore();

        ctx.save();
        ctx.beginPath();
        ctx.arc(1300, 300, 250, 0, Math.PI * 2, true);
        ctx.closePath();
        ctx.clip();
        ctx.drawImage(avatar2Img, 1050, 50, 500, 500);  // Điều chỉnh vị trí và kích thước ảnh
        ctx.restore();

        // Vẽ trái tim tùy thuộc vào phần trăm tình yêu
        const heartImage = lovePercentage > 50 
            ? './assets/traitim.png' // Trái tim hoàn thiện
            : 'https://mimibot.fun/traitimvo.png'; // Trái tim nứt

        const hearts = await Canvas.loadImage(heartImage);
        ctx.drawImage(hearts, 535, 70, 500, 500);  // Điều chỉnh vị trí và kích thước trái tim

        // Vẽ thanh phần trăm tình yêu
        drawLoveBar(ctx, lovePercentage);

        // Tạo tệp đính kèm từ canvas
        const buffer = canvas.toBuffer('image/png');
        const attachment = new AttachmentBuilder(buffer, { name: 'love-image.png' });

        const embed = new EmbedBuilder()
            .setColor('#FF69B4')
            .setTitle('💖 Love Calculator 💖')
            .setDescription(`**<@${user1.id}>** và **<@${user2.id}>** có **${lovePercentage}%** tình yêu! ${loveLevel}\n${loveMessage}`)
            .setImage('attachment://love-image.png')
            .setTimestamp();

        message.channel.send({
            embeds: [embed],
            files: [attachment]
        });
    },
};

// Function to draw the progress bar
function drawLoveBar(ctx, percentage) {
    // Draw background bar
    ctx.fillStyle = '#333';  // Background color of the bar
    ctx.fillRect(300, 600, 1000, 50);  // Background bar

    // Calculate the width of the percentage bar
    const barWidth = (percentage / 100) * 1000;

    // Draw the percentage bar
    const gradient = ctx.createLinearGradient(300, 600, 300 + barWidth, 600);
    gradient.addColorStop(0, '#FF69B4');  // Start color (pink)
    gradient.addColorStop(1, '#8B0000');  // End color (dark red)

    ctx.fillStyle = gradient;
    ctx.fillRect(300, 600, barWidth, 50);

    // Add the percentage text
    ctx.fillStyle = '#FFF';  // Text color
    ctx.font = '30px Arial';
    ctx.fillText(`${percentage}%`, 750, 635);  // Center text
}

async function fetchImageBuffer(url) {
    const response = await fetch(url);
    const buffer = await response.buffer();
    return buffer;
}
