const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'randomcolor',
    cooldown: 5,
    description: 'Random mã màu hex ngẫu nhiên.',
    category: 'Fun/Games',
    aliases: [],
    execute(message) {
        const randomColor = Math.floor(Math.random() * 16777215).toString(16);
        const colorHex = `#${randomColor}`;

        const embed = new EmbedBuilder()
            .setTitle('Màu ngẫu nhiên')
            .setDescription(`Mã màu: ${colorHex}`)
            .setColor(colorHex);

        message.channel.send({ embeds: [embed] });
    },
};
