const { EmbedBuilder } = require('discord.js');
const cooldowns = new Map();

module.exports = {
  name: 'oddeven',
  aliases: ['oe'],
  description: 'Chơi trò chơi Odd-Even để giải trí.',
 category: 'Fun/Games',
  cooldown: 10,
  async execute(message) { 
    const user = message.author;

    const initialNumber = Math.floor(Math.random() * 100) + 1;
    const guess = await message.channel.send(`Số hiện tại là ${initialNumber}. Bạn đoán số tiếp theo sẽ là số lẻ (odd) hay số chẵn (even)?`);

    const filter = response => {
      return response.author.id === user.id && ['odd', 'even'].includes(response.content.toLowerCase());
    };

    try {
      const collected = await message.channel.awaitMessages({ filter, max: 1, time: 15000, errors: ['time'] });
      const response = collected.first().content.toLowerCase();
      let newNumber = Math.floor(Math.random() * 100) + 1;
      let resultMessage;

      const isCorrectGuess = (response === 'odd' && newNumber % 2 !== 0) || (response === 'even' && newNumber % 2 === 0);

      if (isCorrectGuess) {
        resultMessage = `Số tiếp theo là ${newNumber}. Bạn đã đoán đúng! Chúc mừng bạn! 🎉`;
      } else {
        resultMessage = `Số tiếp theo là ${newNumber}. Bạn đã đoán sai! Thử lại lần sau nhé!`;
      }

      const resultEmbed = new EmbedBuilder()
        .setColor('#FFB6C1')
        .setTitle('🎲 Odd-Even 🎲')
        .setDescription(resultMessage)
        .setTimestamp()
        .setFooter({ text: 'Chúc may mắn lần sau!' });

      await guess.edit({ embeds: [resultEmbed] });
      cooldowns.set(user.id, Date.now());

    } catch (err) {
      message.channel.send('Bạn đã hết thời gian để đoán.');
    }
  }
};
