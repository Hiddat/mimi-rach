module.exports = {
    name: 'choose',
    description: 'Chọn ngẫu nhiên một trong hai từ, ngăn cách nhau bằng dấu phẩy.',
    usage: 'cho 2 lựa chọn ngăn cách nhau dấu \` , \`',
    category: 'Fun/Games',
    cooldown: 5,
    aliases: ['pick', 'chọn'],
    async execute(message, args) { 
        if (args.length === 0) {
            return message.reply('Bạn phải cung cấp hai từ ngăn cách nhau bằng dấu phẩy.');
        }

        const choices = args.join(' ').split(',');
        if (choices.length !== 2) {
            return message.reply('Bạn phải cung cấp chính xác hai từ ngăn cách nhau bằng dấu phẩy.');
        }

        const choice = choices[Math.floor(Math.random() * choices.length)].trim();
        message.reply(`<a:1900tick:1255341646271221837> Có cái việc chọn lựa thôi cũng không làm được? Như mình thì: \` ${choice} \``);
    },
};
