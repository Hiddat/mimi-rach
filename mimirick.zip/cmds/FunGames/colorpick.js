const { EmbedBuilder } = require('discord.js');
const cooldowns = new Map();

module.exports = {
  name: 'colorpick',
  aliases: ['cp'],
  description: 'Chơi trò chơi Color-Pick để giải trí với ba lựa chọn màu sắc: đỏ (red), xanh (blue), và vàng (yellow).',
 category: 'Fun/Games',
  cooldown: 10,
  async execute(message, args) { 
    const user = message.author;

    const initialNumber = Math.floor(Math.random() * 100) + 1;
    const guess = await message.channel.send(`Số hiện tại là ${initialNumber}. Bạn đoán số tiếp theo sẽ thuộc nhóm màu đỏ (red), xanh (blue) hay vàng (yellow)?`);

    const filter = response => {
      return response.author.id === user.id && ['red', 'blue', 'yellow'].includes(response.content.toLowerCase());
    };

    try {
      const collected = await message.channel.awaitMessages({ filter, max: 1, time: 15000, errors: ['time'] });
      const response = collected.first().content.toLowerCase();
      let newNumber = Math.floor(Math.random() * 100) + 1;
      let resultMessage;

      const isCorrectGuess = 
        (response === 'red' && newNumber <= 33) || 
        (response === 'blue' && newNumber > 33 && newNumber <= 66) || 
        (response === 'yellow' && newNumber > 66);

      if (isCorrectGuess) {
        resultMessage = `Số tiếp theo là ${newNumber}. Bạn đã đoán đúng!`;
      } else {
        resultMessage = `Số tiếp theo là ${newNumber}. Bạn đã đoán sai! Thử lại lần sau nhé!`;
      }

      const resultEmbed = new EmbedBuilder()
        .setColor('#FFB6C1')
        .setTitle('🎲 Color-Pick 🎲')
        .setDescription(resultMessage)
        .setTimestamp()
        .setFooter({ text: 'Chúc may mắn lần sau!' });

      await guess.edit({ embeds: [resultEmbed] });
      cooldowns.set(user.id, Date.now());

    } catch (err) {
      message.channel.send('Bạn đã hết thời gian để đoán.');
    }
  }
};
