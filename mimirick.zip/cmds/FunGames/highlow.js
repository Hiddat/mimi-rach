const { EmbedBuilder } = require('discord.js');
const cooldowns = new Map();

module.exports = {
  name: 'highlow',
  aliases: ['hl'],
  description: 'Chơi trò chơi High-Low để giải trí.',
 category: 'Fun/Games',
  cooldown: 10,
  async execute(message) { 
    const user = message.author;

    const initialNumber = Math.floor(Math.random() * 100) + 1;
    const guess = await message.channel.send(`Số hiện tại là ${initialNumber}. Bạn đoán số tiếp theo sẽ cao hơn (h) hay thấp hơn (l)?`);

    const filter = response => {
      return response.author.id === user.id && ['h', 'l'].includes(response.content.toLowerCase());
    };

    try {
      const collected = await message.channel.awaitMessages({ filter, max: 1, time: 15000, errors: ['time'] });
      const response = collected.first().content.toLowerCase();
      let newNumber = Math.floor(Math.random() * 100) + 1;
      let resultMessage;

      const isCorrectGuess = (response === 'h' && newNumber > initialNumber) || (response === 'l' && newNumber < initialNumber);

      if (isCorrectGuess) {
        resultMessage = `Số tiếp theo là ${newNumber}. Bạn đã đoán đúng! Chúc mừng bạn! 🎉`;
      } else {
        resultMessage = `Số tiếp theo là ${newNumber}. Bạn đã đoán sai! Thử lại lần sau nhé!`;
      }

      const resultEmbed = new EmbedBuilder()
        .setColor('#FFB6C1')
        .setTitle('🎲 High-Low 🎲')
        .setDescription(resultMessage)
        .setTimestamp()
        .setFooter({ text: 'Chúc may mắn lần sau!' });

      await guess.edit({ embeds: [resultEmbed] });
      cooldowns.set(user.id, Date.now());

    } catch (err) {
      message.channel.send('Bạn đã hết thời gian để đoán.');
    }
  }
};
