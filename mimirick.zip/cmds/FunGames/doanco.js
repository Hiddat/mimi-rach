const { EmbedBuilder } = require('discord.js');
const fetch = require('node-fetch');

module.exports = {
  name: 'doanco',
  aliases: ['gf', 'guessflag'],
  cooldown: 10,
  description: 'Chơi trò chơi đoán cờ để giải trí.',
  category: 'Fun/Games',
  async execute(message) { 
    const countries = await fetch('https://restcountries.com/v3.1/all')
      .then(res => res.json())
      .then(data => data.map(country => ({
        name: country.name.common,
        flag: country.flags.png // Use the PNG version of the flag
      })));

    const selectedCountry = countries[Math.floor(Math.random() * countries.length)];
    const embed = new EmbedBuilder()
      .setColor('#FFB6C1')
      .setTitle('🇺🇳 Đoán Cờ Quốc Gia 🇺🇳')
      .setDescription('Bạn có 12 giây để đoán cờ của quốc gia này!')
      .setImage(selectedCountry.flag)
      .setTimestamp();

    const msg = await message.channel.send({ embeds: [embed] });

    const filter = response => {
      return response.author.id === message.author.id;
    };

    try {
      const collected = await message.channel.awaitMessages({ filter, max: 1, time: 20000, errors: ['time'] });
      const userGuess = collected.first().content.toLowerCase();
      const countryName = selectedCountry.name.toLowerCase();

      let resultMessage;

      if (userGuess === countryName) {
        resultMessage = `Chính xác! Quốc gia là **${selectedCountry.name}**!`;
      } else {
        resultMessage = `Sai rồi! Quốc gia chính xác là **${selectedCountry.name}**.`;
      }

      const resultEmbed = new EmbedBuilder()
        .setColor('#FFB6C1')
        .setTitle('🇺🇳 Đoán Cờ Quốc Gia 🇺🇳')
        .setDescription(resultMessage)
        .setTimestamp()
        .setFooter({ text: 'Chúc may mắn lần sau!' });

      await msg.edit({ embeds: [resultEmbed] });
    } catch (err) {
      const resultEmbed = new EmbedBuilder()
        .setColor('#FF0000')
        .setTitle('🇺🇳 Đoán Cờ Quốc Gia 🇺🇳')
        .setDescription(`Bạn đã hết thời gian! Quốc gia chính xác là **${selectedCountry.name}**.`)
        .setTimestamp()
        .setFooter({ text: 'Chúc may mắn lần sau!' });

      await msg.edit({ embeds: [resultEmbed] });
    }
  }
};
