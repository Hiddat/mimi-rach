const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const dbLove = require('../../db/databaseLove');
const fs = require('fs');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();

const rankingPath = path.resolve(__dirname, '../../data/ranking.json');

// Load rank limits if the file exists
let rankLimits = [];
try {
    rankLimits = JSON.parse(fs.readFileSync(path.join(__dirname, '../../rankLimits.json'), 'utf-8'));
} catch (error) {
    console.error('Error reading rankLimits.json:', error);
    rankLimits = [];
}
const intimacyLevels = [0, 1000, 3000, 8000, 15500, 26500, 60000, 150000, 200000, 550000000, 750000000, 900000000, 100000000, 500000000, 1000000000, 2000000000]; // Example level thresholds

// const intimacyLevels = [0, 1000, 3000, 8000, 15500, 26500, 60000, 150000, 200000, 1000000, 550000000, 900000000, 100000000, 500000000, 1000000000, 2000000000];

module.exports = {
    name: 'ranking',
    aliases: ['lvl', 'exp', 'xp', 'cap'],
    description: 'Hiển thị cấp độ và kinh nghiệm của bạn',
    category: 'Economy',
    cooldown: 30,
    async execute(message) {
        const userId = message.author.id;
        const guildId = message.guild.id;

        // Fetch initial data for the ranking command
        const userMoney = await getUserMoney(userId);
        const userRankPosition = await getUserRankPosition(userId);
        const cashRankPosition = await getCashRankPosition(userId);
        const { rank: intimacyRankPosition, intimacyLevel } = await getIntimacyRankPosition(userId);

        // Fetch the user's data from the database
        const userData = await getUserData(userId);

        // Calculate the user's rank limits based on their level
        const userRank = rankLimits.find(limit => limit.level === userData.level) || rankLimits[0];
        const { limitSend, limitReceive } = userRank;

        // Fetch daily transfer and receive limits
        const userDailyTransfer = await getDailyTransfer(userId);
        const userDailyReceive = await getDailyReceive(userId);


        // Fetch "Nối từ" data from the ranking JSON file
        const noituData = getNoituData(userId, guildId);

        // Create the initial embed
        const embed = new EmbedBuilder()
            .setColor('#FFB6C1')
            .setTitle('Thông Tin Cấp Độ')
            .addFields(
                { name: 'Name', value: `<@${userId}>`, inline: true },
                { name: 'Rank', value: `\`${userData.level}\` (#${userRankPosition || 'N/A'})`, inline: true },
                { name: 'Experience', value: `\`${userData.experience.toLocaleString()}\``, inline: true },
                { name: 'Receive Limit', value: `\`${userDailyReceive.toLocaleString()} / ${limitReceive.toLocaleString()}\``, inline: true },
                { name: 'Give Limit', value: `\`${userDailyTransfer.toLocaleString()} / ${limitSend.toLocaleString()}\``, inline: true },
                { name: 'Cash', value: `**${userMoney.toLocaleString()} <:xumimi:1261591338290511973>** (#${cashRankPosition || 'N/A'})`, inline: true },
                { name: 'Intimacy', value: `**${intimacyLevel || 0}** (#${intimacyRankPosition || 'N/A'})`, inline: true },
                { name: 'Thông tin Nối từ', value: `Ở server name: \`${message.guild.name}\``, inline: false },
                { name: 'Nối từ thắng', value: `\`${noituData.win}\``, inline: true },
                { name: 'Đã trả lời đúng', value: `\`${noituData.true}/${noituData.total} từ (${(noituData.true / noituData.total * 100).toFixed(2)}%)\``, inline: true }
            )
            .setTimestamp();

        // Add buttons for Top rankings
        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('top_cash_server')
                    .setLabel('Top Cash Server')
                    .setEmoji('💰')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('top_cash_global')
                    .setLabel('Top Cash')
                    .setEmoji('🌐')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('top_intimacy')
                    .setLabel('Top Intimacy')
                    .setEmoji('💞')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('top_rank')
                    .setLabel('Top Rank')
                    .setEmoji('🎖️')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('top_noitu')
                    .setLabel('Top Nối Từ')
                    .setEmoji('🔤')
                    .setStyle(ButtonStyle.Primary)
            );

        // Send the initial embed with buttons
        const messageEmbed = await message.channel.send({ embeds: [embed], components: [row] });

        // Button interaction handling
        const collector = messageEmbed.createMessageComponentCollector({ time: 60000 });

        collector.on('collect', async interaction => {
            try {
                if (interaction.user.id !== message.author.id) {
                    return interaction.reply({ content: 'Bạn không có quyền sử dụng nút này.', ephemeral: true });
                }

                let updatedEmbed;

                switch (interaction.customId) {
                    case 'top_cash_server':
                        const guildIds = message.guild;
                        updatedEmbed = await getTopCashServer(guildIds);
                        break;
                    case 'top_cash_global':
                        updatedEmbed = await getTopCashGlobal();
                        break;
                    case 'top_intimacy':
                        updatedEmbed = await getTopIntimacy();
                        break;
                    case 'top_rank':
                        updatedEmbed = await getTopRank();
                        break;
                    case 'top_noitu':
                        updatedEmbed = await getTopNoitu(guildId);
                        break;
                }

                await interaction.update({ embeds: [updatedEmbed], components: [row] });
            } catch (error) {
                console.error('Error during button interaction:', error);
                await interaction.reply({ content: 'Đã xảy ra lỗi khi xử lý yêu cầu của bạn.', ephemeral: true });
            }
        });

        collector.on('end', async () => {
            try {
                await messageEmbed.edit({ components: [] });
            } catch (error) {
                console.error('Error while editing the message after collector end:', error);
            }
        });
    }
};

async function getTopCashServer(guild) {
    try {
        if (!guild || !guild.id) {
            throw new Error('Invalid guild object');
        }

        console.log('Fetching all users with money from the database.');

        const rows = await new Promise((resolve, reject) => {
            dbLove.all("SELECT user_id, money FROM user_money ORDER BY money DESC", [], (err, rows) => {
                if (err) {
                    console.error('Database query error (Top Cash Server):', err);
                    return reject(err);
                }
                resolve(rows);
            });
        });

        if (rows.length === 0) {
            console.warn('No data found in user_money table.');
            throw new Error('No data found in user_money table');
        }

        console.log('Fetching members from the guild:', guild.id);

        // Fetch all members in the current guild
        const members = await guild.members.fetch();

        // Filter rows to include only users who are members of the current guild
        const serverMembers = rows.filter(row => members.has(String(row.user_id)));

        if (serverMembers.length === 0) {
            console.warn('No members in the current server have money records.');
            throw new Error('No members in the current server have money records');
        }

        // Sort by money and take the top 20
        const topMembers = serverMembers.slice(0, 20);

        let description = '';
        topMembers.forEach((member, index) => {
            description += `${index + 1}. <@${member.user_id}> - ${member.money.toLocaleString('en-US')}\n`;
        });

        return new EmbedBuilder()
            .setTitle('Top 20 Cash Server')
            .setDescription(description)
            .setColor('#FFD700')
            .setTimestamp();

    } catch (error) {
        console.error('Error fetching Top Cash Server:', error);
        return new EmbedBuilder()
            .setTitle('Lỗi')
            .setDescription('Không thể tải top cash server.')
            .setColor('#FF0000')
            .setTimestamp();
    }
}


async function getTopNoitu(guildId) {
    try {
        const rankData = require(rankingPath);
        const players = rankData[guildId]?.players || [];

        if (players.length === 0) {
            throw new Error('No data found for Top Nối Từ');
        }

        const sortedPlayers = players.sort((a, b) => b.win - a.win).slice(0, 20);

        let description = '';
        sortedPlayers.forEach((player, index) => {
            description += `${index + 1}. <@${player.id}> - ${player.win}\n`;
        });

        return new EmbedBuilder()
            .setTitle('Top 20 Nối Từ')
            .setDescription(description)
            .setColor('#00BFFF')
            .setTimestamp();
    } catch (error) {
        console.error('Error fetching Top Nối Từ:', error);
        return new EmbedBuilder()
            .setTitle('Lỗi')
            .setDescription('Không thể tải top nối từ.')
            .setColor('#FF0000')
            .setTimestamp();
    }
}


async function getTopCashGlobal() {
    try {
        const rows = await new Promise((resolve, reject) => {
            dbLove.all("SELECT user_id, money FROM user_money ORDER BY money DESC LIMIT 20", [], (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });
        });

        let description = '';
        rows.forEach((row, index) => {
            description += `${index + 1}. <@${row.user_id}> - ${row.money.toLocaleString('en-US')}\n`;
        });

        return new EmbedBuilder()
            .setTitle('Top 20 Cash Global')
            .setDescription(description)
            .setColor('#FFD700')
            .setTimestamp();
    } catch (error) {
        console.error('Error fetching top cash global:', error);
        return new EmbedBuilder()
            .setTitle('Lỗi')
            .setDescription('Không thể tải top cash global.')
            .setColor('#FF0000')
            .setTimestamp();
    }
}

async function getTopIntimacy() {
    try {
        const rows = await new Promise((resolve, reject) => {
            dbLove.all("SELECT user1_id, user2_id, intimacy_level FROM love_data ORDER BY intimacy_level DESC LIMIT 20", [], (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });
        });

        let description = '';
        rows.forEach((row, index) => {
            const intimacyLevel = getIntimacyLevel(row.intimacy_level);
            description += `${index + 1}. <@${row.user1_id}> 💞 <@${row.user2_id}> - ${intimacyLevel}\n`;
        });

        return new EmbedBuilder()
            .setTitle('Top 20 Intimacy')
            .setDescription(description)
            .setColor('#FF69B4')
            .setTimestamp();
    } catch (error) {
        console.error('Error fetching top intimacy:', error);
        return new EmbedBuilder()
            .setTitle('Lỗi')
            .setDescription('Không thể tải top intimacy.')
            .setColor('#FF0000')
            .setTimestamp();
    }
}

async function getTopRank() {
    try {
        const rows = await new Promise((resolve, reject) => {
            dbLove.all("SELECT user_id, level FROM user_data ORDER BY level DESC LIMIT 20", [], (err, rows) => {
                if (err) return reject(err);
                resolve(rows);
            });
        });

        let description = '';
        rows.forEach((row, index) => {
            description += `${index + 1}. <@${row.user_id}> - ${row.level}\n`;
        });

        return new EmbedBuilder()
            .setTitle('Top 20 Rank')
            .setDescription(description)
            .setColor('#FFA500')
            .setTimestamp();
    } catch (error) {
        console.error('Error fetching top rank:', error);
        return new EmbedBuilder()
            .setTitle('Lỗi')
            .setDescription('Không thể tải top rank.')
            .setColor('#FF0000')
            .setTimestamp();
    }
}

function getIntimacyLevel(intimacyPoints) {
    return intimacyLevels.findIndex(level => intimacyPoints < level) || intimacyLevels.length;
}

function getUserMoney(userId) {
    return new Promise((resolve, reject) => {
        dbLove.get("SELECT money FROM user_money WHERE user_id = ?", [userId], (err, row) => {
            if (err) return reject(err);
            resolve(row ? row.money : 0);
        });
    });
}

function getUserRankPosition(userId) {
    return new Promise((resolve, reject) => {
        dbLove.all("SELECT user_id, level, experience FROM user_data ORDER BY experience DESC", [], (err, rows) => {
            if (err) return reject(err);
            const rank = rows.findIndex(row => row.user_id === userId) + 1;
            resolve(rank || 0); // Return 0 if the rank is not found
        });
    });
}

function getCashRankPosition(userId) {
    return new Promise((resolve, reject) => {
        dbLove.all("SELECT user_id, money FROM user_money ORDER BY money DESC", [], (err, rows) => {
            if (err) return reject(err);
            const rank = rows.findIndex(row => row.user_id === userId) + 1;
            resolve(rank || 0); // Return 0 if the rank is not found
        });
    });
}

function getIntimacyRankPosition(userId) {
    return new Promise((resolve, reject) => {
        dbLove.all("SELECT user1_id, user2_id, intimacy_level FROM love_data ORDER BY intimacy_level DESC", [], (err, rows) => {
            if (err) return reject(err);
            const rank = rows.findIndex(row => row.user1_id === userId || row.user2_id === userId) + 1;
            const intimacyLevel = rows.find(row => row.user1_id === userId || row.user2_id === userId)?.intimacy_level || 0;
            resolve({ rank: rank || 0, intimacyLevel });
        });
    });
}

function getUserData(userId) {
    return new Promise((resolve, reject) => {
        dbLove.get("SELECT level, experience FROM user_data WHERE user_id = ?", [userId], (err, row) => {
            if (err) return reject(err);
            resolve(row ? row : { level: 1, experience: 0 });
        });
    });
}

function getDailyTransfer(userId) {
    return new Promise((resolve, reject) => {
        dbLove.get("SELECT daily_transfer FROM user_daily_transfer WHERE user_id = ? AND date = DATE('now', 'localtime')", [userId], (err, row) => {
            if (err) return reject(err);
            resolve(row ? row.daily_transfer : 0);
        });
    });
}

function getDailyReceive(userId) {
    return new Promise((resolve, reject) => {
        dbLove.get("SELECT daily_receive FROM user_daily_receive WHERE user_id = ? AND date = DATE('now', 'localtime')", [userId], (err, row) => {
            if (err) return reject(err);
            resolve(row ? row.daily_receive : 0);
        });
    });
}

function getNoituData(userId, guildId) {
    try {
        const rankData = require(rankingPath);
        const guildData = rankData[guildId] || { players: [] };
        const userData = guildData.players.find(player => player.id === userId) || { win: 0, true: 0, total: 0 };

        return {
            win: userData.win,
            true: userData.true,
            total: userData.total
        };
    } catch (error) {
        console.error('Error fetching Nối từ data:', error);
        return { win: 0, true: 0, total: 0 };
    }
}
