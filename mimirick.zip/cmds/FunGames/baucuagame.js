const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'baucuagame',
    aliases: ['bcg', 'baucuag'],
    cooldown: 10,
    category: 'Fun/Games',
    description: 'Chơi Bầu Cua mà không cần cá cược tiền.',
    async execute(message, args) {
        const baucuaEmojis = [
            '<:bau:1254379355065286757>',
            '<:cua:1254379406374211665>',
            '<:tom:1254379822314950737>',
            '<:ca:1254379517582245898>',
            '<:ga:1254379593637564528>',
            '<:nai:1254379752807202942>'
        ];
        const options = ['bầu', 'cua', 'tôm', 'cá', 'gà', 'hươu'];
        const rollingEmoji = '<a:lac:1254379696897130589>';

        if (args.length < 1) {
            return message.reply('Vui lòng chọn một trong các tùy chọn: bầu, cua, tôm, cá, gà, hươu.');
        }

        const betChoice = args[0].toLowerCase();
        if (!options.includes(betChoice)) {
            return message.reply('Vui lòng chọn một trong các tùy chọn hợp lệ: bầu, cua, tôm, cá, gà, hươu.');
        }

        let resultMessage = `${rollingEmoji} <:dotpink:1280728743769542817> ${rollingEmoji} <:dotpink:1280728743769542817> ${rollingEmoji}`;
        const sentMessage = await message.channel.send(resultMessage);

        const dice1 = Math.floor(Math.random() * 6);
        const dice2 = Math.floor(Math.random() * 6);
        const dice3 = Math.floor(Math.random() * 6);

        setTimeout(async () => {
            resultMessage = `# ${baucuaEmojis[dice1]} <:dotpink:1280728743769542817> ${rollingEmoji} <:dotpink:1280728743769542817> ${rollingEmoji}`;
            await sentMessage.edit(resultMessage);
        }, 1000);

        setTimeout(async () => {
            resultMessage = `# ${baucuaEmojis[dice1]} <:dotpink:1280728743769542817> ${baucuaEmojis[dice2]} <:dotpink:1280728743769542817> ${rollingEmoji}`;
            await sentMessage.edit(resultMessage);
        }, 2000);

        setTimeout(async () => {

            const results = [dice1, dice2, dice3].map(dice => options[dice]);
            const winCount = results.filter(result => result === betChoice).length;
            resultMessage = `# ${baucuaEmojis[dice1]} <:dotpink:1280728743769542817> ${baucuaEmojis[dice2]} <:dotpink:1280728743769542817> ${baucuaEmojis[dice3]}`;
            await sentMessage.edit(resultMessage);

            let finalMessage;

            if (winCount === 0) {
                finalMessage = `Rất tiếc! Bạn không trúng với lựa chọn ${betChoice}.`;
            } else {
                finalMessage = `Chúc mừng! Bạn đã trúng ${winCount} lần với ${betChoice}!`;
            }

            message.channel.send(finalMessage);
        }, 3000);
    },
};
