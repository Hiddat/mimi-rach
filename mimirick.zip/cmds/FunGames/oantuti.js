const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'rps',
    description: 'Trò chơi oẳn tù tì',
    category: 'Fun/Games',
    aliases: ['rockpaperscissors', 'rsp'],
    cooldown: 5,
    async execute(message, args) {
        const choices = ['rock', 'paper', 'scissors'];
        const botChoice = choices[Math.floor(Math.random() * choices.length)];

        const filter = response => {
            return response.author.id === message.author.id && choices.includes(response.content.toLowerCase());
        };

        const promptEmbed = new EmbedBuilder()
            .setColor('#FFA500')
            .setTitle('Rock-Paper-Scissors')
            .setDescription('Chọn: rock, paper, hoặc scissors')
            .setTimestamp();

        await message.channel.send({ embeds: [promptEmbed] });

        try {
            const collected = await message.channel.awaitMessages({ filter, max: 1, time: 15000, errors: ['time'] });
            const playerChoice = collected.first().content.toLowerCase();

            const resultEmbed = new EmbedBuilder()
                .setColor('#FF69B4')
                .setTitle('Rock-Paper-Scissors')
                .setDescription(`Bạn chọn: ${playerChoice}\nBot chọn: ${botChoice}`)
                .setTimestamp();

            if (playerChoice === botChoice) {
                resultEmbed.addFields({ name: 'Kết quả', value: 'Hòa!' });
            } else if (
                (playerChoice === 'rock' && botChoice === 'scissors') ||
                (playerChoice === 'paper' && botChoice === 'rock') ||
                (playerChoice === 'scissors' && botChoice === 'paper')
            ) {
                resultEmbed.addFields({ name: 'Kết quả', value: 'Bạn thắng!' });
            } else {
                resultEmbed.addFields({ name: 'Kết quả', value: 'Bot thắng!' });
            }

            return message.channel.send({ embeds: [resultEmbed] });
        } catch (error) {
            return message.channel.send('Bạn đã hết thời gian!');
        }
    }
};
