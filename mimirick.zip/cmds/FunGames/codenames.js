const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const fs = require('fs');

// Map để lưu trữ thông tin về game và người chơi
const gameSessions = new Map();
const playerGameMap = new Map();

module.exports = {
    name: 'codenames',
    description: 'Bắt đầu trò chơi Codenames!',
    category: 'Fun/Games',
    cooldown: 10,

    execute: async (message, args) => {
        const serverId = message.guild.id;
        const channelId = message.channel.id;
        const gameId = `${serverId}-${channelId}`;

        // Kiểm tra nếu trò chơi đã bắt đầu trong kênh này
        if (gameSessions.has(gameId)) {
            return message.reply('Đã có một trò chơi đang diễn ra trong kênh này.');
        }

        // Tạo embed để hỏi người chơi chọn ngôn ngữ
        const embed = new EmbedBuilder()
            .setTitle('Chọn ngôn ngữ cho trò chơi')
            .setDescription('Vui lòng chọn ngôn ngữ từ khóa cho trò chơi Codenames.')
            .setColor('#FFB6C1'); // Màu hồng pastel

        // Tạo nút chọn Tiếng Anh và Tiếng Việt
        const englishButton = new ButtonBuilder()
            .setCustomId('english')
            .setLabel('English')
            .setStyle(ButtonStyle.Primary);

        const vietnameseButton = new ButtonBuilder()
            .setCustomId('vietnamese')
            .setLabel('Tiếng Việt')
            .setStyle(ButtonStyle.Secondary);

        const row = new ActionRowBuilder().addComponents(englishButton, vietnameseButton);

        // Gửi tin nhắn lựa chọn ngôn ngữ
        const sentMessage = await message.channel.send({ embeds: [embed], components: [row] });

        const collector = message.channel.createMessageComponentCollector({ time: 15000 });

        collector.on('collect', async (interaction) => {
            if (interaction.customId === 'english' || interaction.customId === 'vietnamese') {
                const language = interaction.customId === 'english' ? 'english' : 'vietnamese';
                const wordList = loadWordList(language);

                // Khởi tạo trò chơi và lưu vào gameSessions
                startGame(serverId, channelId, language, wordList);

                // Vô hiệu hóa các nút và cập nhật ngôn ngữ đã chọn
                await interaction.update({
                    content: `Ngôn ngữ đã chọn: **${language === 'english' ? 'English' : 'Tiếng Việt'}**`,
                    components: []
                });

                // Khởi chạy logic chính của trò chơi
                gameLogic(message, gameId);
            }
        });

        collector.on('end', collected => {
            if (collected.size === 0) {
                sentMessage.edit({ content: 'Đã hết thời gian chọn ngôn ngữ.', components: [] });
            }
        });
    }
};

// Hàm tải tệp JSON chứa từ khóa dựa trên ngôn ngữ
function loadWordList(language) {
    const filePath = language === 'english' ? './data/english.json' : './data/vietnamese.json';

    try {
        const data = fs.readFileSync(filePath, 'utf8');
        return JSON.parse(data).words;
    } catch (err) {
        console.error('Không thể đọc tệp từ khóa:', err);
        return [];
    }
}

// Hàm khởi tạo trò chơi
function startGame(serverId, channelId, language, wordList) {
    const gameId = `${serverId}-${channelId}`;
    const gameInfo = {
        players: [],
        redTeam: [],
        blueTeam: [],
        spymasterRed: null,
        spymasterBlue: null,
        currentTurn: 'red',
        currentClue: null, // Gợi ý hiện tại
        guessesRemaining: 0, // Số lần đoán còn lại
        guessedWords: [], // Để lưu các từ đã được đoán
        wordList: wordList,
        startTime: Date.now(),
        isStarted: true,
        redWordsFound: 0,
        blueWordsFound: 0,
        maxDuration: 90 * 60 * 1000 // 90 phút
    };

    gameSessions.set(gameId, gameInfo);

    // Tự động kết thúc trò chơi sau 90 phút nếu chưa có đội nào thắng
    setTimeout(() => {
        endGame(gameId);
    }, gameInfo.maxDuration);
}

// Hàm quản lý logic trò chơi
function gameLogic(message, gameId) {
    const gameInfo = gameSessions.get(gameId);
    if (!gameInfo) return;

    // Tạo Embed hiển thị thông tin trò chơi với số thứ tự và tag người chơi
    const playerList = gameInfo.players.map((player, index) => `${index + 1}. <@${player.id}>`).join('\n');

    const embed = new EmbedBuilder()
        .setTitle('Codenames Game')
        .setDescription('Ấn nút bên dưới để tham gia hoặc rời khỏi trò chơi.')
        .addFields({ name: 'Người chơi hiện tại:', value: gameInfo.players.length > 0 ? playerList : 'Chưa có ai tham gia.' })
        .setColor('#F5B7B1'); // Màu hồng pastel

    // Nút tham gia và rời khỏi
    const joinButton = new ButtonBuilder()
        .setCustomId('join')
        .setLabel('Tham gia')
        .setStyle(ButtonStyle.Primary);

    const leaveButton = new ButtonBuilder()
        .setCustomId('leave')
        .setLabel('Rời khỏi')
        .setStyle(ButtonStyle.Secondary);

    const startButton = new ButtonBuilder()
        .setCustomId('start')
        .setLabel('Bắt đầu')
        .setStyle(ButtonStyle.Success)
        .setDisabled(true); // Bắt đầu chỉ khi đủ người chơi

    const row = new ActionRowBuilder().addComponents(joinButton, leaveButton, startButton);

    // Gửi Embed cùng với các nút
    const sentMessage = message.channel.send({ embeds: [embed], components: [row] });

    // Xử lý sự kiện khi người chơi tương tác
    const collector = message.channel.createMessageComponentCollector();

    collector.on('collect', async (interaction) => {
        const userId = interaction.user.id;

        if (interaction.customId === 'join') {
            // Kiểm tra nếu người chơi đã tham gia trò chơi khác
            if (playerGameMap.has(userId) && playerGameMap.get(userId) !== gameId) {
                await interaction.reply({ content: 'Bạn đang tham gia trò chơi khác. Hoàn thành hoặc rời khỏi trò chơi đó trước.', ephemeral: true });
                return;
            }

            // Thêm người chơi vào trò chơi
            gameInfo.players.push({ id: userId, username: interaction.user.username });
            playerGameMap.set(userId, gameId);

            // Vô hiệu hóa nút tham gia nếu đủ 16 người
            if (gameInfo.players.length >= 16) {
                joinButton.setDisabled(true);
            }

            // Cập nhật Embed hiển thị danh sách người chơi
            const updatedPlayerList = gameInfo.players.map((player, index) => `${index + 1}. <@${player.id}>`).join('\n');

            const updatedEmbed = new EmbedBuilder()
                .setTitle('Codenames Game')
                .setDescription('Ấn nút bên dưới để tham gia hoặc rời khỏi trò chơi.')
                .addFields({ name: 'Người chơi hiện tại:', value: updatedPlayerList })
                .setColor('#F5B7B1');

            // Cập nhật tin nhắn với danh sách người chơi mới và các nút
            await interaction.update({
                embeds: [updatedEmbed],
                components: [row]
            });
        }

        // Xử lý khi người chơi rời khỏi trò chơi
        if (interaction.customId === 'leave') {
            if (gameInfo.players.some(player => player.id === userId)) {
                gameInfo.players = gameInfo.players.filter(player => player.id !== userId);
                playerGameMap.delete(userId);

                // Kích hoạt lại nút "Tham gia" nếu số người chơi dưới 16
                if (gameInfo.players.length < 16) {
                    joinButton.setDisabled(false);
                }

                // Cập nhật Embed hiển thị danh sách người chơi
                const updatedPlayerList = gameInfo.players.map((player, index) => `${index + 1}. <@${player.id}>`).join('\n');

                const updatedEmbed = new EmbedBuilder()
                    .setTitle('Codenames Game')
                    .setDescription('Ấn nút bên dưới để tham gia hoặc rời khỏi trò chơi.')
                    .addFields({ name: 'Người chơi hiện tại:', value: gameInfo.players.length > 0 ? updatedPlayerList : 'Chưa có ai tham gia.' })
                    .setColor('#F5B7B1');

                // Cập nhật tin nhắn với danh sách người chơi mới và các nút
                await interaction.update({
                    embeds: [updatedEmbed],
                    components: [row]
                });
            } else {
                await interaction.reply({ content: 'Bạn chưa tham gia trò chơi này.', ephemeral: true });
            }
        }

        // Khi trò chơi bắt đầu
        if (interaction.customId === 'start') {
            if (gameInfo.players.length < 4) {
                await interaction.reply({ content: 'Cần ít nhất 4 người chơi để bắt đầu trò chơi!', ephemeral: true });
            } else {
                startCodenamesGame(gameInfo, interaction);
            }
        }
    });
}


// Hàm Spymaster đưa ra gợi ý
module.exports.giveClue = (message, args) => {
    const gameId = `${message.guild.id}-${message.channel.id}`;
    const gameInfo = gameSessions.get(gameId);

    if (!gameInfo || !gameInfo.isStarted) {
        return message.reply('Hiện không có trò chơi nào đang diễn ra.');
    }

    const currentSpymaster = gameInfo.currentTurn === 'red' ? gameInfo.spymasterRed : gameInfo.spymasterBlue;

    if (message.author.id !== currentSpymaster.id) {
        return message.reply('Chỉ Spymaster của đội hiện tại mới được đưa ra gợi ý!');
    }

    const [clueWord, clueCount] = args;
    const numberOfGuesses = parseInt(clueCount);

    if (!clueWord || isNaN(numberOfGuesses) || numberOfGuesses <= 0) {
        return message.reply('Gợi ý không hợp lệ. Vui lòng cung cấp từ gợi ý và số lượng từ có thể đoán.');
    }

    // Lấy danh sách từ khóa của đội hiện tại
    const teamWords = gameInfo.currentTurn === 'red' ? gameInfo.wordList.slice(0, 9) : gameInfo.wordList.slice(9, 17);

    // Kiểm tra xem từ gợi ý có chứa từ khóa của đội không
    for (const word of teamWords) {
        if (clueWord.toLowerCase().includes(word.toLowerCase())) {
            message.channel.send(`Spymaster của đội ${gameInfo.currentTurn === 'red' ? 'Đỏ' : 'Xanh'} đã nhắc đến từ khóa "${word}". Đội ${gameInfo.currentTurn === 'red' ? 'Đỏ' : 'Xanh'} thua!`);
            endGame(gameId);
            return;
        }
    }

    gameInfo.currentClue = clueWord;
    gameInfo.guessesRemaining = numberOfGuesses;

    message.channel.send(`Spymaster đã đưa ra gợi ý: **${clueWord}** với ${numberOfGuesses} lượt đoán.`);
};

// Lệnh đoán từ trong trò chơi
module.exports.guessWord = (message, args) => {
    const gameId = `${message.guild.id}-${message.channel.id}`;
    const gameInfo = gameSessions.get(gameId);

    if (!gameInfo || !gameInfo.isStarted) {
        return message.reply('Hiện không có trò chơi nào đang diễn ra.');
    }

    const word = args[0].toLowerCase();
    const currentTeam = gameInfo.currentTurn === 'red' ? gameInfo.redTeam : gameInfo.blueTeam;
    const spymaster = gameInfo.currentTurn === 'red' ? gameInfo.spymasterRed : gameInfo.spymasterBlue;

    // Kiểm tra người chơi có thuộc đội hiện tại không
    if (!currentTeam.some(player => player.id === message.author.id)) {
        return message.reply('Bạn không thuộc đội hiện tại hoặc không phải lượt của đội bạn.');
    }

    // Kiểm tra nếu Spymaster đang đoán
    if (spymaster.id === message.author.id) {
        return message.reply('Spymaster không được đoán từ.');
    }

    // Kiểm tra nếu từ đã được đoán
    if (gameInfo.guessedWords.includes(word)) {
        return message.reply('Từ này đã được đoán trước đó!');
    }

    // Tiến hành đoán từ và cập nhật trạng thái trò chơi
    const correct = checkWord(word, gameInfo);

    if (correct) {
        message.reply(`Tuyệt vời! Bạn đã đoán đúng từ **${word}**.`);
        gameInfo.guessedWords.push(word);
        gameInfo.guessesRemaining--;

        // Kiểm tra điều kiện chiến thắng
        if (gameInfo.redWordsFound === 9) {
            message.channel.send('Đội Đỏ đã thắng!');
            endGame(gameId);
        } else if (gameInfo.blueWordsFound === 8) {
            message.channel.send('Đội Xanh đã thắng!');
            endGame(gameId);
        } else if (gameInfo.guessesRemaining <= 0) {
            message.channel.send('Hết lượt đoán! Chuyển sang đội khác.');
            switchTurn(gameInfo, message);
        }
    } else {
        message.reply(`Rất tiếc! Bạn đã đoán sai từ **${word}**.`);
        switchTurn(gameInfo, message);
    }
};

// Chuyển lượt
function switchTurn(gameInfo, message) {
    gameInfo.currentTurn = gameInfo.currentTurn === 'red' ? 'blue' : 'red';
    gameInfo.currentClue = null; // Xóa gợi ý hiện tại
    gameInfo.guessesRemaining = 0; // Reset lượt đoán
    message.channel.send(`Lượt chơi hiện tại đã chuyển sang đội ${gameInfo.currentTurn === 'red' ? 'Đỏ' : 'Xanh'}.`);
}

// Hàm kết thúc trò chơi
function endGame(gameId) {
    const gameInfo = gameSessions.get(gameId);

    if (gameInfo) {
        gameInfo.players.forEach(player => {
            playerGameMap.delete(player.id); // Xóa người chơi khỏi Map
        });
        gameSessions.delete(gameId); // Xóa trò chơi khỏi session
        console.log(`Trò chơi ${gameId} đã kết thúc.`);
    }
}

// Hàm kiểm tra từ đoán
function checkWord(word, gameInfo) {
    const redWords = gameInfo.wordList.slice(0, 9);
    const blueWords = gameInfo.wordList.slice(9, 17);
    const assassinWord = gameInfo.wordList[17];

    if (word === assassinWord) {
        message.channel.send('Rất tiếc! Bạn đã đoán phải từ tử thần. Trò chơi kết thúc.');
        endGame(gameInfo);
        return false;
    }

    if (redWords.includes(word)) {
        gameInfo.redWordsFound++;
        return true;
    }

    if (blueWords.includes(word)) {
        gameInfo.blueWordsFound++;
        return true;
    }

    return false;
}
