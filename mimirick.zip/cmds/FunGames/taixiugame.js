const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'taixiugame',
    aliases: ['txg', 'taixiug'],
    cooldown: 10,
    category: 'Fun/Games',
    description: 'Chơi tài xỉu với xúc xắc mà không cần cá cược tiền.',
    async execute(message, args) {
        const diceEmojis = [
            '<:1nut:1254378800175644682>',
            '<:2nut:1254379058821861421>',
            '<:3nut:1254379121115533397>',
            '<:4nut:1254379177616871484>',
            '<:5nut:1254379234768453674>',
            '<:6nut:1254379319501783121>'
        ];
        const rollingEmoji = '<a:doxucxac:1254379627321888920>';

        if (args.length < 1) {
            return message.reply('Vui lòng chọn tài hoặc xỉu.');
        }

        const betChoice = args[0].toLowerCase();
        if (!['tài', 'xỉu'].includes(betChoice)) {
            return message.reply('Vui lòng chọn một trong hai tùy chọn: tài hoặc xỉu.');
        }

        let initialMessage = `${rollingEmoji} <:dotpink:1280728743769542817> ${rollingEmoji} <:dotpink:1280728743769542817> ${rollingEmoji}`;
        const sentMessage = await message.channel.send(initialMessage);

        const dice1 = Math.floor(Math.random() * 6) + 1;
        const dice2 = Math.floor(Math.random() * 6) + 1;
        const dice3 = Math.floor(Math.random() * 6) + 1;
        const total = dice1 + dice2 + dice3;

        let result = 'xỉu';
        if (total >= 11 && total <= 18) {
            result = 'tài';
        }

        setTimeout(async () => {
            initialMessage = `# ${diceEmojis[dice1 - 1]} <:dotpink:1280728743769542817> ${rollingEmoji} <:dotpink:1280728743769542817> ${rollingEmoji}`;
            await sentMessage.edit(initialMessage);
        }, 1000);

        setTimeout(async () => {
            initialMessage = `# ${diceEmojis[dice1 - 1]} <:dotpink:1280728743769542817> ${diceEmojis[dice2 - 1]} <:dotpink:1280728743769542817> ${rollingEmoji}`;
            await sentMessage.edit(initialMessage);
        }, 2000);

        setTimeout(async () => {
            initialMessage = `# ${diceEmojis[dice1 - 1]} <:dotpink:1280728743769542817> ${diceEmojis[dice2 - 1]} <:dotpink:1280728743769542817> ${diceEmojis[dice3 - 1]}
 Tổng điểm: ${total} (${result}).`;
            await sentMessage.edit(initialMessage);

            let resultMessage;

            if (result === betChoice) {
                resultMessage = `Chúc mừng! Bạn đã đoán đúng ${betChoice}!`;
            } else {
                resultMessage = `Rất tiếc! Bạn đã đoán sai ${betChoice}!`;
            }

            message.channel.send(resultMessage);
        }, 3000);
    },
};
