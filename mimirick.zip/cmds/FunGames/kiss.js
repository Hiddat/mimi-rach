const { EmbedBuilder } = require('discord.js');
const getGif = require('../../utils/getGif');

module.exports = {
    name: 'kiss',
    description: 'Hôn một người dùng',
    category: 'Fun/Games',
    aliases: ['smack'],
    cooldown: 5,
    async execute(message, args) { 
        const user = message.mentions.users.first();
        if (!user) {
            return message.reply('Bạn cần tag một người dùng để hôn.');
        }

        if (user.id === message.author.id) {
            return message.reply('Bạn không thể tự hôn chính mình.');
        }

        const gif = await getGif('kiss');

        const embed = new EmbedBuilder()
            .setColor('#FF69B4')
            .setDescription(`<@${message.author.id}> muốn hôn <@${user.id}>`)
            .setImage(gif)
            .setTimestamp();

        message.channel.send({ embeds: [embed] });
    },
};
