const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const fs = require('fs');
const path = require('path');
const configPath = path.join(__dirname, '../../config.json');

module.exports = {
    name: 'listadmin',
    description: 'Quản lý danh sách admin (owner-only)',
    category: 'Owner Bot',
    execute(message) {
        const ownerId = '1145030539074600970';

        if (message.author.id !== ownerId) {
            return message.reply('Chỉ có owner mới có thể sử dụng lệnh này.');
        }

        // Load current config and adminIds
        const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
        const adminIds = config.adminIds || [];

        const generateAdminListEmbed = () => {
            let description = adminIds.map((adminId, index) => `${index + 1}. <@${adminId}>`).join('\n') || 'Chưa có admin nào.';
            return new EmbedBuilder()
                .setColor(0xffc0cb) // Pastel pink
                .setTitle('LIST ADMIN WORD CHAIN')
                .setDescription(`Danh sách admin hiện tại:\n${description}`);
        };

        const embed = generateAdminListEmbed();

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('addAdmin')
                    .setLabel('Thêm admin')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('removeAdmin')
                    .setLabel('Xoá admin')
                    .setStyle(ButtonStyle.Danger)
            );

        message.channel.send({ embeds: [embed], components: [row] }).then((msg) => {
            const filter = (interaction) => interaction.user.id === ownerId;
            const collector = msg.createMessageComponentCollector({ filter, componentType: ComponentType.Button, time: 60000 });

            collector.on('collect', async (interaction) => {
                if (interaction.customId === 'addAdmin') {
                    await interaction.reply({ content: 'Vui lòng tag hoặc nhập ID của người dùng để thêm admin.', ephemeral: true });

                    const filterMessage = (m) => m.author.id === ownerId;
                    const collected = await message.channel.awaitMessages({ filter: filterMessage, max: 1, time: 30000, errors: ['time'] }).catch(() => null);

                    if (!collected) {
                        return interaction.followUp({ content: 'Hết thời gian thêm admin.', ephemeral: true });
                    }

                    const adminToAdd = collected.first().mentions.users.first() || collected.first().content.trim();

                    if (!adminToAdd || adminIds.includes(adminToAdd.id || adminToAdd)) {
                        return interaction.followUp({ content: 'Người này đã là admin hoặc không hợp lệ.', ephemeral: true });
                    }

                    // Add the new admin and update config
                    adminIds.push(adminToAdd.id || adminToAdd);
                    config.adminIds = adminIds;
                    fs.writeFileSync(configPath, JSON.stringify(config, null, 2)); // Save updated config

                    const updatedEmbed = generateAdminListEmbed();
                    await msg.edit({ embeds: [updatedEmbed] });
                    interaction.followUp({ content: 'Admin đã được thêm thành công.', ephemeral: true });
                }

                if (interaction.customId === 'removeAdmin') {
                    await interaction.reply({ content: 'Vui lòng nhập số thứ tự của admin bạn muốn xoá.', ephemeral: true });

                    const filterMessage = (m) => m.author.id === ownerId;
                    const collected = await message.channel.awaitMessages({ filter: filterMessage, max: 1, time: 30000, errors: ['time'] }).catch(() => null);

                    if (!collected) {
                        return interaction.followUp({ content: 'Hết thời gian xoá admin.', ephemeral: true });
                    }

                    const index = parseInt(collected.first().content.trim()) - 1;

                    if (isNaN(index) || index < 0 || index >= adminIds.length) {
                        return interaction.followUp({ content: 'Số thứ tự không hợp lệ.', ephemeral: true });
                    }

                    // Remove the admin and update config
                    adminIds.splice(index, 1);
                    config.adminIds = adminIds;
                    fs.writeFileSync(configPath, JSON.stringify(config, null, 2)); // Save updated config

                    const updatedEmbed = generateAdminListEmbed();
                    await msg.edit({ embeds: [updatedEmbed] });
                    interaction.followUp({ content: 'Admin đã được xoá thành công.', ephemeral: true });
                }
            });

            collector.on('end', () => {
                msg.edit({ components: [] }); // Disable buttons after collector ends
            });
        });
    },
};
