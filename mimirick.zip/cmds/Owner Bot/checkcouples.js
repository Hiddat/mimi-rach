const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const dbLove = require('../../db/databaseLove');

const rings = {
  none: { emoji: '❌', name: 'Chưa có nhẫn' },
  basic: { emoji: '<:nhan_basic:1259698833823240283>', name: 'Nhẫn Basic' },
  gold: { emoji: '<:nhan_vang:1259699697292017767>', name: 'Nhẫn Vàng' },
  silver: { emoji: '<:nhan_bac:1259699699192172636>', name: 'Nhẫn Bạc' },
  ruby: { emoji: '<:nhan_ruby:1259699702060810262>', name: 'Nhẫn Ruby' },
  sapphire: { emoji: '<:nhan_sapphire:1259699706767085638>', name: 'Nhẫn Sapphire' },
  emerald: { emoji: '<:nhan_lucbao:1259699709380132886>', name: 'Nhẫn Lục Bảo' },
  pink_ruby: { emoji: '<:nhan_hongngoc:1259699612034531388>', name: 'Nhẫn Hồng Ngọc' },
  gemstone: { emoji: '<:nhan_daquy:1259699627033104555>', name: 'Nhẫn Đá Quý' },
  turquoise_diamond: { emoji: '<:turquoise_diamond:1277960456845262940>', name: 'Ring turquoise diamond' },
  gold2: { emoji: '<:gold2:1277960447026270218>', name: 'Ring gold' },
  zirconiacrystal: { emoji: '<:zirconiacrystal:1277960401690169431>', name: 'Ring zirconia crystal' },
  sliverpink: { emoji: '<:sliverpink:1277960391892144268>', name: 'Ring sliver pink' },
  goldgemstone: { emoji: '<:goldgemstone:1277960380861382707>', name: 'Ring gold gem stone' },
  midjourney: { emoji: '<:midjourney:1277960366005026828>', name: 'Ring midjourney' },
  deeppink: { emoji: '<:deeppink:1277960353774440490>', name: 'Ring deep pink' },
  turquoise: { emoji: '<:turquoise:1277960338779930624>', name: 'Ring turquoise' },
  Tanzanite: { emoji: '<:Tanzanite:1277960322384138290>', name: 'Ring Tanzanite' },
  pinkdiamond: { emoji: '<:pinkdiamond:1277960310065598576>', name: 'Ring pink diamond' },
  pinkruby: { emoji: '<:pinkruby:1277960265932996789>', name: 'Ring pink ruby' },
  pinksapphire: { emoji: '<:pinksapphire:1277960240335163454>', name: 'Ring pink sapphire' },
  unicornsliver: { emoji: '<:unicornsliver:1277960226922041467>', name: 'Ring unicorn sliver' },
  traitim: { emoji: '<:traitim:1277960213785350207>', name: 'Nhẫn trái tim' },
  CrimsonSovereign: { name: 'Nhẫn Hoàng Kim Rực Rỡ', emoji: '<:CrimsonSovereign:1278694004548177920>' }, // Nhẫn Hoàng Kim Rực Rỡ
  RoyalIceSapphire: { name: 'Nhẫn Băng Lam Quyền Quý', emoji: '<:RoyalIceSapphire:1278693995576430675>' }, // Nhẫn Băng Lam Quyền Quý
  GoldenRadiance: { name: 'Nhẫn Hồng Ngọc Đế Vương', emoji: '<:GoldenRadiance:1278693988152643604>' }, // Nhẫn Hồng Ngọc Đế Vương
};

module.exports = {
  name: 'checkcouples',
  aliases: ['cc'],
  category: 'Owner Bot',
  description: 'Kiểm tra những cặp đôi có sẵn.',
  async execute(message, args) {
    const ownerID = '1145030539074600970';

    if (message.author.id !== ownerID) {
      return message.reply('Bạn không có quyền sử dụng lệnh này.');
    }

    const pageSize = 10;
    let currentPage = 0;

    const getCouples = (offset, limit) => new Promise((resolve, reject) => {
      dbLove.all(
        `SELECT user1_id, user2_id, intimacy_level, success_time, ring_type 
         FROM love_data 
         LIMIT ? OFFSET ?`, 
         [limit, offset],
         (err, rows) => {
          if (err) return reject(err);
          resolve(rows);
        }
      );
    });

    const totalCouplesQuery = () => new Promise((resolve, reject) => {
      dbLove.get("SELECT COUNT(*) as count FROM love_data", (err, row) => {
        if (err) return reject(err);
        resolve(row.count);
      });
    });

    const totalCouples = await totalCouplesQuery();
    const totalPages = Math.ceil(totalCouples / pageSize);

    const loadPage = async (page) => {
      const couples = await getCouples(page * pageSize, pageSize);
      let description = '';

      for (const couple of couples) {
        const user1 = message.client.users.cache.get(couple.user1_id) || await message.client.users.fetch(couple.user1_id);
        const user2 = message.client.users.cache.get(couple.user2_id) || await message.client.users.fetch(couple.user2_id);

        const startDate = new Date(couple.success_time);
        const now = new Date();
        const daysTogether = Math.floor((now - startDate) / (1000 * 60 * 60 * 24));

        const ring = rings[couple.ring_type] || rings.none;

        description += `**${user1.username}** 💖 **${user2.username}**\n`;
        description += `Điểm thân mật: ${couple.intimacy_level}\n`;
        description += `Nhẫn: ${ring.emoji} ${ring.name}\n`;
        description += `Số ngày yêu nhau: ${daysTogether}\n\n`;
      }

      return new EmbedBuilder()
        .setTitle('Danh Sách Các Cặp Đôi')
        .setDescription(description)
        .setColor('#FFB6C1')
        .setTimestamp();
    };

    const initialEmbed = new EmbedBuilder()
      .setTitle('Danh Sách Các Cặp Đôi')
      .setDescription(`Tổng số cặp đôi đang yêu nhau: **${totalCouples}**`)
      .setColor('#FFB6C1')
      .setTimestamp();

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('previous')
          .setLabel('Quay về')
          .setStyle(ButtonStyle.Primary)
          .setDisabled(currentPage === 0),
        new ButtonBuilder()
          .setCustomId('next')
          .setLabel('Trang sau')
          .setStyle(ButtonStyle.Primary)
          .setDisabled(currentPage >= totalPages - 1)
      );

    const messageEmbed = await message.channel.send({
      embeds: [initialEmbed, await loadPage(currentPage)],
      components: [row]
    });

    const collector = messageEmbed.createMessageComponentCollector({ time: 60000 });

    collector.on('collect', async (interaction) => {
  if (interaction.customId === 'previous') {
    currentPage--;
  } else if (interaction.customId === 'next') {
    currentPage++;
  }

  await interaction.deferUpdate(); // Ensure interaction is acknowledged

  await interaction.editReply({
    embeds: [initialEmbed, await loadPage(currentPage)],
    components: [
      new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('previous')
            .setLabel('Quay về')
            .setStyle(ButtonStyle.Primary)
            .setDisabled(currentPage === 0),
          new ButtonBuilder()
            .setCustomId('next')
            .setLabel('Trang sau')
            .setStyle(ButtonStyle.Primary)
            .setDisabled(currentPage >= totalPages - 1)
        )
    ]
  });
});

collector.on('end', async () => {
  // Disable the buttons after the collector ends
  await messageEmbed.edit({
    components: [
      new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('previous')
            .setLabel('Quay về')
            .setStyle(ButtonStyle.Primary)
            .setDisabled(true), // Disable after collection ends
          new ButtonBuilder()
            .setCustomId('next')
            .setLabel('Trang sau')
            .setStyle(ButtonStyle.Primary)
            .setDisabled(true)
        )
    ]
  });
});

  },
};
