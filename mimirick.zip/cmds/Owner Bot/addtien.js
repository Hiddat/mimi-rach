// ./cmds/addtien.js
const { EmbedBuilder } = require('discord.js');
const dbLove = require('../../db/databaseLove');

module.exports = {
  name: 'bro',
  description: '',
  category: 'Owner Bot',
  async execute(message, args) {
    const ownerId = '1145030539074600970';
    const user = message.author;

    if (user.id !== ownerId) {
      return;
    }

    let targetUser;
    let amount;

    if (args.length === 2) {
      if (args[0].startsWith('<@') && args[0].endsWith('>')) {
        targetUser = message.mentions.users.first();
        amount = parseInt(args[1]);
      } else {
        targetUser = message.mentions.users.last();
        amount = parseInt(args[0]);
      }
    } else if (args.length === 1) {
      targetUser = message.mentions.users.first();
      amount = parseInt(args[0]);
    } else {
      return message.channel.send('Cách sử dụng: .addtien <user tag> <số tiền> hoặc .addtien <số tiền> <user tag>');
    }

    if (!targetUser || isNaN(amount)) {
      return message.channel.send('Vui lòng cung cấp người dùng và số tiền hợp lệ.');
    }

    const updateUserMoney = (userId, amount) => new Promise((resolve, reject) => {
      dbLove.run("INSERT INTO user_money (user_id, money) VALUES (?, ?) ON CONFLICT(user_id) DO UPDATE SET money = money + ?", [userId, amount, amount], function(err) {
        if (err) return reject(err);
        resolve();
      });
    });

    await updateUserMoney(targetUser.id, amount);

    const embed = new EmbedBuilder()
      .setColor('#FFB6C1')
      .setTitle('Thêm Tiền Thành Công')
      .setDescription(`${targetUser.username} đã được thêm ${amount} <:xumimi:1261591338290511973>!`)
      .setTimestamp();

    message.channel.send({ embeds: [embed] });
  }
};
