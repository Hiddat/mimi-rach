const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const dbLove = require('../../db/databaseLove');

module.exports = {
  name: 'hotrochiatay',
  aliases: ['htct'],
  description: 'Hỗ trợ owner ép buộc chia tay',
  category: 'Owner Bot',
  cooldown: 3,
  async execute(message) {
    const ownerId = '1145030539074600970'; // ID owner
    const userOwner = message.author.id;

    // Kiểm tra xem có phải owner không
    if (userOwner !== ownerId) {
      return message.channel.send('Chỉ có owner mới được sử dụng lệnh này.');
    }

    const user2 = message.mentions.users.first();
    if (!user2) {
      return message.channel.send('Bạn phải tag người mà bạn muốn hỗ trợ chia tay.');
    }

    // Kiểm tra trạng thái của người dùng được tag
    const checkStatus = (userId) => new Promise((resolve, reject) => {
      dbLove.get("SELECT * FROM love_data WHERE (user1_id = ? OR user2_id = ?) AND success_time IS NOT NULL ORDER BY success_time DESC LIMIT 1", [userId, userId], (err, row) => {
        if (err) return reject(err);
        resolve(row);
      });
    });

    let user2Status;
    try {
      user2Status = await checkStatus(user2.id);
    } catch (error) {
      console.error('Error checking status:', error);
      return message.channel.send('Đã có lỗi xảy ra khi kiểm tra trạng thái của người này.');
    }

    // Nếu không có người yêu
    if (!user2Status) {
      return message.channel.send(`<@${user2.id}> hiện không có người yêu để chia tay.`);
    }

    // Gửi thông báo chia tay cho người được tag
    const embed = new EmbedBuilder()
      .setColor('#FFB6C1')
      .setTitle('Hỗ Trợ Chia Tay')
      .setDescription(`Bạn có đồng ý chia tay với người yêu cũ của mình không?`);

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('accept')
          .setLabel('Đồng ý')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('decline')
          .setLabel('Từ chối')
          .setStyle(ButtonStyle.Danger),
      );

    const breakupMessage = await message.channel.send({ content: `<@${user2.id}>`, embeds: [embed], components: [row] });

    const filter = i => i.user.id === user2.id;

    const collector = breakupMessage.createMessageComponentCollector({ filter, componentType: ComponentType.Button, time: 300000 });

    collector.on('collect', async interaction => {
      if (interaction.customId === 'accept') {
        dbLove.run("DELETE FROM love_data WHERE user1_id = ? OR user2_id = ?", [user2.id, user2.id], function(err) {
          if (err) {
            console.error('Error deleting relationship:', err);
            return interaction.update({ content: 'Đã có lỗi xảy ra khi xóa mối quan hệ.', components: [], embeds: [] });
          }
          interaction.update({ content: `Mối quan hệ của <@${user2.id}> đã được xóa thành công.`, components: [], embeds: [] });
        });
      } else {
        interaction.update({ content: `<@${interaction.user.id}> đã từ chối chia tay.`, components: [], embeds: [] });
      }
    });

    collector.on('end', collected => {
      if (collected.size === 0) {
        breakupMessage.edit({ content: 'Không có phản hồi. Lệnh chia tay đã hết hạn.', components: [] });
      }
    });
  }
};
