const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const fs = require('fs');
const path = require('path');

// Đường dẫn đến tệp upgradeloto.json
const upgradePath = path.join(__dirname, '../../upgradeloto.json');

// Hàm hỗ trợ phân tích thời gian
const parseDuration = (duration) => {
    const regex = /^(\d+)([dwm y])$/i;
    const match = duration.match(/^(\d+)([dwmy])$/i);
    if (!match) return null;

    const value = parseInt(match[1]);
    const unit = match[2].toLowerCase();

    const now = new Date();
    switch (unit) {
        case 'd':
            now.setDate(now.getDate() + value);
            break;
        case 'w':
            now.setDate(now.getDate() + value * 7);
            break;
        case 'm':
            now.setMonth(now.getMonth() + value);
            break;
        case 'y':
            now.setFullYear(now.getFullYear() + value);
            break;
        default:
            return null;
    }
    return now.toISOString();
};

module.exports = {
    name: 'upgradeloto',
    description: 'Quản lý nâng cấp premium cho các server (owner-only)',
    category: 'Owner Bot',
    execute(message) {
        const ownerId = '1145030539074600970'; // Thay bằng ID chủ sở hữu bot của bạn

        if (message.author.id !== ownerId) {
            return message.reply('Chỉ có owner mới có thể sử dụng lệnh này.');
        }

        // Load current upgrades
        let upgradeData;
        try {
            upgradeData = JSON.parse(fs.readFileSync(upgradePath, 'utf-8'));
        } catch (error) {
            return message.reply('Không thể đọc tệp cấu hình nâng cấp.');
        }

        const upgrades = upgradeData.upgrades || [];

        const generateUpgradeListEmbed = () => {
            let description = upgrades.map((upgrade, index) => {
                const expiresAt = new Date(upgrade.expiresAt);
                return `${index + 1}. Server ID: \`${upgrade.serverId}\` | Hết hạn: ${expiresAt.toLocaleString()}`;
            }).join('\n') || 'Chưa có bản nâng cấp nào.';
            return new EmbedBuilder()
                .setColor(0x00ff00) // Màu xanh lá
                .setTitle('DANH SÁCH NÂNG CẤP PREMIUM')
                .setDescription(`Danh sách các bản nâng cấp hiện tại:\n${description}`);
        };

        const embed = generateUpgradeListEmbed();

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('addUpgrade')
                    .setLabel('Thêm nâng cấp')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('removeUpgrade')
                    .setLabel('Xoá nâng cấp')
                    .setStyle(ButtonStyle.Danger)
            );

        message.channel.send({ embeds: [embed], components: [row] }).then((msg) => {
            const filter = (interaction) => interaction.user.id === ownerId;
            const collector = msg.createMessageComponentCollector({ filter, componentType: ComponentType.Button, time: 60000 });

            collector.on('collect', async (interaction) => {
                if (interaction.customId === 'addUpgrade') {
                    await interaction.reply({ content: 'Vui lòng nhập ID server và thời gian hết hạn (ví dụ: `1248609173894336563 30d`).', ephemeral: true });

                    const filterMessage = (m) => m.author.id === ownerId;
                    const collected = await message.channel.awaitMessages({ filter: filterMessage, max: 1, time: 30000, errors: ['time'] }).catch(() => null);

                    if (!collected) {
                        return interaction.followUp({ content: 'Hết thời gian thêm nâng cấp.', ephemeral: true });
                    }

                    const input = collected.first().content.trim();
                    const parts = input.split(' ');
                    if (parts.length !== 2) {
                        return interaction.followUp({ content: 'Định dạng không hợp lệ. Vui lòng nhập theo định dạng: `ID_Server Thời_gian` (ví dụ: `1248609173894336563 30d`).', ephemeral: true });
                    }

                    const serverId = parts[0];
                    const duration = parts[1];

                    // Kiểm tra ID server có hợp lệ không (có thể thêm kiểm tra xem server có tồn tại hay không nếu cần)
                    if (!/^\d+$/.test(serverId)) {
                        return interaction.followUp({ content: 'ID server không hợp lệ.', ephemeral: true });
                    }

                    // Phân tích thời gian
                    const expiresAt = parseDuration(duration);
                    if (!expiresAt) {
                        return interaction.followUp({ content: 'Thời gian không hợp lệ. Sử dụng các đơn vị: d (ngày), w (tuần), m (tháng), y (năm).', ephemeral: true });
                    }

                    // Kiểm tra xem server đã có bản nâng cấp chưa
                    if (upgrades.find(u => u.serverId === serverId)) {
                        return interaction.followUp({ content: 'Server này đã có bản nâng cấp.', ephemeral: true });
                    }

                    // Thêm bản nâng cấp mới
                    upgrades.push({ serverId, expiresAt });
                    upgradeData.upgrades = upgrades;
                    try {
                        fs.writeFileSync(upgradePath, JSON.stringify(upgradeData, null, 2));
                    } catch (error) {
                        return interaction.followUp({ content: 'Không thể lưu dữ liệu nâng cấp.', ephemeral: true });
                    }

                    const updatedEmbed = generateUpgradeListEmbed();
                    await msg.edit({ embeds: [updatedEmbed] });
                    interaction.followUp({ content: 'Nâng cấp đã được thêm thành công.', ephemeral: true });
                }

                if (interaction.customId === 'removeUpgrade') {
                    await interaction.reply({ content: 'Vui lòng nhập số thứ tự của bản nâng cấp bạn muốn xoá.', ephemeral: true });

                    const filterMessage = (m) => m.author.id === ownerId;
                    const collected = await message.channel.awaitMessages({ filter: filterMessage, max: 1, time: 30000, errors: ['time'] }).catch(() => null);

                    if (!collected) {
                        return interaction.followUp({ content: 'Hết thời gian xoá nâng cấp.', ephemeral: true });
                    }

                    const index = parseInt(collected.first().content.trim()) - 1;

                    if (isNaN(index) || index < 0 || index >= upgrades.length) {
                        return interaction.followUp({ content: 'Số thứ tự không hợp lệ.', ephemeral: true });
                    }

                    // Xoá bản nâng cấp
                    const removed = upgrades.splice(index, 1);
                    upgradeData.upgrades = upgrades;
                    try {
                        fs.writeFileSync(upgradePath, JSON.stringify(upgradeData, null, 2));
                    } catch (error) {
                        return interaction.followUp({ content: 'Không thể lưu dữ liệu nâng cấp.', ephemeral: true });
                    }

                    const updatedEmbed = generateUpgradeListEmbed();
                    await msg.edit({ embeds: [updatedEmbed] });
                    interaction.followUp({ content: `Nâng cấp cho server \`${removed[0].serverId}\` đã được xoá thành công.`, ephemeral: true });
                }
            });

            collector.on('end', () => {
                msg.edit({ components: [] }); // Vô hiệu hóa các nút sau khi hết thời gian
            });
        });
    },
};
