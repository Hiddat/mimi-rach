const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const sqlite3 = require('sqlite3').verbose();
const dbCaptcha = new sqlite3.Database('./captcha.db', sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE);

module.exports = {
    name: 'checkban',
    description: 'Kiểm tra trạng thái ban của người dùng và gỡ bỏ nếu cần',
    execute(message, args) {
        console.log('Lệnh checkban được kích hoạt'); // Log khi lệnh được kích hoạt

        // Chỉ cho phép owner sử dụng lệnh này
        const ownerId = '1145030539074600970';
        if (message.author.id !== ownerId) {
            console.log('Người dùng không có quyền sử dụng lệnh này.');
            return message.reply('Bạn không có quyền sử dụng lệnh này.');
        }

        // Kiểm tra xem người dùng có được tag hay không
        const targetUser = message.mentions.users.first();
        if (!targetUser) {
            console.log('Không có người dùng nào được tag.');
            return message.reply('Vui lòng tag người dùng cần kiểm tra.');
        }

        const userId = targetUser.id;

        console.log(`Đang truy xuất thông tin từ cơ sở dữ liệu cho userId: ${userId}`);

        // Lấy thông tin từ database
        dbCaptcha.get(`SELECT * FROM captcha_users WHERE userId = ?`, [userId], (err, row) => {
            if (err) {
                console.error('Lỗi khi truy xuất thông tin từ cơ sở dữ liệu:', err);
                return message.reply('Có lỗi xảy ra khi truy xuất thông tin.');
            }

            if (!row) {
                console.log('Không tìm thấy dữ liệu captcha cho người dùng này.');
                return message.reply('Người dùng này không có dữ liệu xác minh captcha.');
            }

            console.log('Thông tin người dùng đã được truy xuất:', row);

            const now = Date.now();
            let isBanned = false;
            let banEndTime;

            // Kiểm tra nếu người dùng đã bị cấm
            if (row.captcha_status === 'banned') {
                isBanned = true;
                if (row.ban_expire_at && row.ban_expire_at > now) {
                    banEndTime = `<t:${Math.floor(row.ban_expire_at / 1000)}:R>`;
                } else {
                    banEndTime = 'Không có'; // Không có thời hạn hết hạn cụ thể
                }
            }

            const embed = new EmbedBuilder()
                .setColor('#FFB6C1') // Màu hồng pastel
                .setTitle(`Trạng thái của ${targetUser.tag}`)
                .addFields(
                    { name: 'Bị ban', value: isBanned ? 'Có' : 'Không', inline: true },
                    { name: 'Thời gian hết hạn ban', value: isBanned ? banEndTime : 'Không có', inline: true }
                );

            const components = [];
            if (isBanned) {
                const removeBanButton = new ButtonBuilder()
                    .setCustomId(`remove_ban_${userId}`)
                    .setLabel('Gỡ ban')
                    .setStyle(ButtonStyle.Danger);

                const actionRow = new ActionRowBuilder().addComponents(removeBanButton);
                components.push(actionRow);
            }

            message.reply({ embeds: [embed], components }).then(sentMessage => {
                console.log('Tin nhắn đã được gửi và đang chờ tương tác nút.');

                // Tạo một collector để thu thập các tương tác với nút
                const filter = interaction => interaction.customId === `remove_ban_${userId}` && interaction.user.id === ownerId;
                const collector = sentMessage.createMessageComponentCollector({ filter, time: 60000 });

                collector.on('collect', interaction => {
                    console.log('Nút gỡ ban đã được nhấn.');
                    if (interaction.customId === `remove_ban_${userId}`) {
                        // Gỡ bỏ ban của người dùng
                        dbCaptcha.run(`DELETE FROM captcha_users WHERE userId = ?`, [userId], (err) => {
                            if (err) {
                                console.error('Lỗi khi gỡ bỏ ban:', err);
                                return interaction.reply({ content: 'Có lỗi xảy ra khi gỡ bỏ ban.', ephemeral: true });
                            }
                            interaction.update({ content: `Đã gỡ bỏ ban và xóa tất cả thông tin captcha của ${targetUser.tag}.`, components: [], embeds: [] });
                        });
                    }
                });

                collector.on('end', collected => {
                    if (collected.size === 0) {
                        console.log('Nút gỡ ban đã hết hạn.');
                        sentMessage.edit({ content: 'Nút gỡ ban đã hết hạn.', components: [] });
                    }
                });
            }).catch(err => {
                console.error('Lỗi khi gửi tin nhắn:', err);
                message.reply('Có lỗi xảy ra khi gửi tin nhắn.');
            });
        });
    }
};
