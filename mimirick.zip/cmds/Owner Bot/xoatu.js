const fs = require('fs');
const { adminIds } = require('../../config.json'); // Danh sách admin từ config.json

module.exports = {
    name: 'xoa',
    category: 'Owner Bot',
    description: 'Xóa từ trong từ điển nếu tồn tại (chỉ dành cho admin)',
    async execute(message, args) {
        // Kiểm tra nếu người dùng là admin
        if (!adminIds.includes(message.author.id)) {
            return message.reply('Bạn không có quyền sử dụng lệnh này.');
        }

        // Kiểm tra nếu có đúng 2 từ
        const words = args.join(' ').trim().split(/\s+/);
        if (words.length !== 2) {
            return message.react('<a:mmb_error:1254379860101562391>'); // Phản hồi lỗi nếu không phải 2 từ
        }

        const targetWords = words.join(' ').toLowerCase();
        const wordsFilePath = './data/words.txt';
        const wordsFilePaths = './data/official-words.txt';
        const fileContent = fs.readFileSync(wordsFilePath, 'utf-8').split('\n');
        const lowerCaseFileContent = fileContent.map(line => line.toLowerCase());

        // Kiểm tra nếu từ tồn tại trong file
        const index = lowerCaseFileContent.indexOf(targetWords);
        if (index !== -1) {
            // Nếu tồn tại, xóa dòng và ghi lại file
            fileContent.splice(index, 1);
            fs.writeFileSync(wordsFilePath, fileContent.join('\n'));
            fs.writeFileSync(wordsFilePaths, fileContent.join('\n'));

            // Thả emoji xác nhận
            await message.react('<a:Verify:1254379893421244427>');
        } else {
            // Nếu không tồn tại, thả emoji lỗi
            await message.react('<a:mmb_error:1254379860101562391>');
        }
    },
};
