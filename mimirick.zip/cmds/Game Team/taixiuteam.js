const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionsBitField } = require('discord.js');
const dbLove = require('../../db/databaseLove');
const { MAX_BET } = require('../../config.json');

module.exports = {
    name: 'taixiuteam',
    aliases: ['txt'],
    category: 'Game cược xu mimi theo Team',
    cooldown: 10,
    description: 'Fun/Games',
    async execute(message, args) {
        if (args.length < 2) {
            return message.reply('Vui lòng nhập số tiền cược và số lượng người chơi tối đa.');
        }

        let betAmount = parseInt(args[0]);
        let maxPlayers = parseInt(args[1]);

        if (isNaN(betAmount) || betAmount <= 0 || isNaN(maxPlayers) || maxPlayers <= 0 || maxPlayers > 20) {
            return message.reply('Vui lòng nhập số tiền cược và số lượng người chơi tối đa hợp lệ (tối đa 20 người).');
        }

        if (maxPlayers < 2){
            maxPlayers = 2;
        }

        if (betAmount > MAX_BET) {
            return message.reply(`Số tiền cược không được vượt quá ${MAX_BET.toLocaleString()} <:xumimi:1261591338290511973>.`);
        }

        let players = [];
        let gameStarted = false;

        const embed = new EmbedBuilder()
            .setTitle('Trò chơi Tài Xỉu Đội')
            .setDescription(`Danh sách người chơi - ${betAmount} <:xumimi:1261591338290511973>:\n\n(Trống)`)
            .setColor('#FFD700')
            .setTimestamp();

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('join')
                    .setLabel('Tham gia')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('leave')
                    .setLabel('Rời khỏi')
                    .setStyle(ButtonStyle.Danger),
                new ButtonBuilder()
                    .setCustomId('start')
                    .setLabel('Bắt đầu')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(true), // Bắt đầu game phải có ít nhất 2 người tham gia
                new ButtonBuilder()
                    .setCustomId('end')
                    .setLabel('Tắt game')
                    .setStyle(ButtonStyle.Secondary)
            );

        const sentMessage = await message.channel.send({ embeds: [embed], components: [row] });

        const filter = i => ['join', 'leave', 'start', 'end'].includes(i.customId) && !gameStarted;
        const collector = sentMessage.createMessageComponentCollector({ filter, time: 5 * 60 * 1000 });

        collector.on('collect', async interaction => {
            const userId = interaction.user.id;
            const isGameManager = userId === message.author.id || interaction.member.permissions.has(PermissionsBitField.Flags.ManageGuild);

            if (interaction.customId === 'join') {
                if (players.length >= maxPlayers) {
                    return interaction.reply({ content: `Số lượng người chơi đã đạt giới hạn (${maxPlayers}).`, ephemeral: true });
                }

                const totalNeeded = betAmount * maxPlayers;
                const userMoney = await getUserMoney(userId);
                if (userMoney < totalNeeded) {
                    return interaction.reply({ content: `Bạn cần ít nhất ${totalNeeded.toLocaleString()} <:xumimi:1261591338290511973> để tham gia trò chơi.`, ephemeral: true });
                }

                if (players.find(p => p.id === userId)) {
                    return interaction.reply({ content: 'Bạn đã tham gia trò chơi rồi.', ephemeral: true });
                }

                const choiceRow = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId('tai')
                            .setLabel('Tài')
                            .setStyle(ButtonStyle.Primary),
                        new ButtonBuilder()
                            .setCustomId('xiu')
                            .setLabel('Xỉu')
                            .setStyle(ButtonStyle.Primary)
                    );

                await interaction.reply({ content: 'Vui lòng chọn loại cược của bạn.', components: [choiceRow], ephemeral: true });

                const choiceFilter = i => ['tai', 'xiu'].includes(i.customId) && i.user.id === userId;
                const choiceCollector = interaction.channel.createMessageComponentCollector({ filter: choiceFilter, max: 1, time: 60000 });

                choiceCollector.on('collect', async choiceInteraction => {
                    const choice = choiceInteraction.customId === 'tai' ? 'tài' : 'xỉu';
                    players.push({ id: userId, tag: choiceInteraction.user.tag, choice: choice });

                    embed.setDescription(players.map((p, index) => `**${index + 1}. <@${p.id}> - ${p.choice.toUpperCase()}**`).join('\n\n'));
                    await sentMessage.edit({ embeds: [embed] });

                    if (players.length >= 2) {
                        row.components[2].setDisabled(false); // Enable the start button when there are at least 2 players
                        await sentMessage.edit({ components: [row] }); // Update the message with the enabled start button
                    }

                    await choiceInteraction.update({ content: `Bạn đã chọn ${choice.toUpperCase()}.`, components: [] });
                });

            } else if (interaction.customId === 'leave') {
                const playerIndex = players.findIndex(p => p.id === userId);
                if (playerIndex === -1) {
                    return interaction.reply({ content: 'Bạn không có trong danh sách tham gia.', ephemeral: true });
                }

                players.splice(playerIndex, 1);
                embed.setDescription(players.length ? players.map((p, index) => `**${index + 1}. <@${p.id}> - ${p.choice.toUpperCase()}**`).join('\n\n') : '(Trống)');
                await sentMessage.edit({ embeds: [embed] });

                if (players.length < 2) {
                    row.components[2].setDisabled(true); // Disable the start button if less than 2 players remain
                    await sentMessage.edit({ components: [row] });
                }

                await interaction.reply({ content: 'Bạn đã rời khỏi trò chơi.', ephemeral: true });

            } else if (interaction.customId === 'start') {
                if (!isGameManager) {
                    return interaction.reply({ content: 'Bạn không có quyền bắt đầu trò chơi.', ephemeral: true });
                }

                if (players.length < 2) {
                    return interaction.reply({ content: 'Cần ít nhất 2 người để bắt đầu trò chơi.', ephemeral: true });
                }

                gameStarted = true;
                collector.stop();

                // Bắt đầu quay xúc xắc và xử lý kết quả
                const rollingEmoji = '<a:doxucxac:1254379627321888920>';
                const diceEmojis = [
                    '<:1nut:1254378800175644682>',
                    '<:2nut:1254379058821861421>',
                    '<:3nut:1254379121115533397>',
                    '<:4nut:1254379177616871484>',
                    '<:5nut:1254379234768453674>',
                    '<:6nut:1254379319501783121>'
                ];

                const dice1 = Math.floor(Math.random() * 6) + 1;
                const dice2 = Math.floor(Math.random() * 6) + 1;
                const dice3 = Math.floor(Math.random() * 6) + 1;
                const total = dice1 + dice2 + dice3;
                const result = total >= 11 && total <= 18 ? 'tài' : 'xỉu';

                embed.setDescription(`# Xúc xắc 1: ${rollingEmoji}\n\n# Xúc xắc 2: ${rollingEmoji}\n\n# Xúc xắc 3: ${rollingEmoji}`);
                await sentMessage.edit({ embeds: [embed] });

                setTimeout(async () => {
                    embed.setDescription(`# Xúc xắc 1: ${diceEmojis[dice1 - 1]}\n\n# Xúc xắc 2: ${rollingEmoji}\n\n# Xúc xắc 3: ${rollingEmoji}`);
                    await sentMessage.edit({ embeds: [embed] });
                }, 1000);

                setTimeout(async () => {
                    embed.setDescription(`# Xúc xắc 1: ${diceEmojis[dice1 - 1]}\n\n# Xúc xắc 2: ${diceEmojis[dice2 - 1]}\n\n# Xúc xắc 3: ${rollingEmoji}`);
                    await sentMessage.edit({ embeds: [embed] });
                }, 2000);

                setTimeout(async () => {
                    embed.setDescription(`# Xúc xắc 1: ${diceEmojis[dice1 - 1]}\n\n# Xúc xắc 2: ${diceEmojis[dice2 - 1]}\n\n# Xúc xắc 3: ${diceEmojis[dice3 - 1]}\n\nTổng điểm: ${total} (${result.toUpperCase()})`);
                    await sentMessage.edit({ embeds: [embed] });

                    // Sau khi quay xúc xắc, xử lý kết quả và gửi danh sách người thắng, thua
                    const winners = players.filter(p => p.choice === result);
                    const losers = players.filter(p => p.choice !== result);

                    let winnerTags = '';
                    let loserTags = '';

                    if (winners.length === players.length || losers.length === players.length) {
                        // Nếu tất cả người chơi đều thắng hoặc thua, không ai mất tiền
                        winnerTags = losers.length ? 'Tất cả người chơi đều thua, không ai mất tiền.' : 'Tất cả người chơi đều thắng, không ai nhận thêm tiền.';
                        loserTags = '';
                    } else {
                        // Cập nhật tiền của người thắng và thua
                        await updatePlayerMoney(winners, losers, betAmount);
                        winnerTags = winners.map(p => `<@${p.id}> - Nhận ${betAmount * losers.length} <:xumimi:1261591338290511973>`).join('\n');
                        loserTags = losers.map(p => `<@${p.id}> - Mất ${betAmount * winners.length} <:xumimi:1261591338290511973>`).join('\n');
                    }

                    const resultEmbed = new EmbedBuilder()
                        .setColor('#FFD700')
                        .setTitle('Kết quả Tài Xỉu Đội')
                        .setDescription(`**Kết quả**: ${result.toUpperCase()}\n\n**Người thắng**:\n${winnerTags || '(Không có ai)'}\n\n**Người thua**:\n${loserTags || '(Không có ai)'}`)
                        .addFields(
                            { name: 'Xúc xắc 1', value: diceEmojis[dice1 - 1], inline: true },
                            { name: 'Xúc xắc 2', value: diceEmojis[dice2 - 1], inline: true },
                            { name: 'Xúc xắc 3', value: diceEmojis[dice3 - 1], inline: true },
                            { name: 'Tổng điểm', value: `${total} (${result.toUpperCase()})`, inline: true }
                        )
                        .setTimestamp();

                    // Hiển thị kết quả sau 5 giây
                    setTimeout(async () => {
                        await sentMessage.edit({ embeds: [resultEmbed], components: [] });
                    }, 5000);
                }, 3000);

            } else if (interaction.customId === 'end') {
                if (!isGameManager) {
                    return interaction.reply({ content: 'Bạn không có quyền tắt trò chơi.', ephemeral: true });
                }

                gameStarted = true;
                collector.stop();

                embed.setDescription('Trò chơi đã bị hủy.');
                await sentMessage.edit({ embeds: [embed], components: [] });
                await interaction.reply({ content: 'Trò chơi đã bị hủy.', ephemeral: true });
            }
        });

        collector.on('end', async () => {
            if (!gameStarted) {
                embed.setDescription('Trò chơi đã kết thúc do không đủ người tham gia hoặc hết thời gian.');
                await sentMessage.edit({ embeds: [embed], components: [] });
            }
        });

        async function getUserMoney(userId) {
            return new Promise((resolve, reject) => {
                dbLove.get("SELECT money FROM user_money WHERE user_id = ?", [userId], (err, row) => {
                    if (err) return reject(err);
                    resolve(row ? row.money : 0);
                });
            });
        }

        async function updatePlayerMoney(winners, losers, betAmount) {
            const winAmount = betAmount * losers.length;
            const lossAmount = betAmount * winners.length;

            const updateMoney = (userId, amount) => new Promise((resolve, reject) => {
                dbLove.run("UPDATE user_money SET money = money + ? WHERE user_id = ?", [amount, userId], function(err) {
                    if (err) return reject(err);
                    resolve();
                });
            });

            for (const winner of winners) {
                await updateMoney(winner.id, winAmount);
            }

            for (const loser of losers) {
                await updateMoney(loser.id, -lossAmount);
            }
        }
    },
};

