const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, PermissionsBitField } = require('discord.js');
const dbLove = require('../../db/databaseLove'); // Dùng cho việc kiểm tra tiền tệ
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./db/xocdia_history.db');

// Tạo bảng games_history nếu chưa tồn tại
db.run(`
  CREATE TABLE IF NOT EXISTS games_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    host_id TEXT,
    bet_amount INTEGER,
    result TEXT,
    date_played TEXT
  )
`);

module.exports = {
    name: 'xocdia',
    description: 'Trò chơi Xóc Đĩa',
    async execute(message, args) {
        // Kiểm tra quyền
        const hasPermission = message.member.permissions.has(PermissionsBitField.Flags.ManageGuild) ||
                              message.member.permissions.has(PermissionsBitField.Flags.ManageChannels) ||
                              message.member.permissions.has(PermissionsBitField.Flags.ManageMessages) ||
                              message.member.roles.cache.some(role => role.name === 'Mimi Games');

        if (!hasPermission) {
            return message.channel.send("Bạn không có quyền sử dụng lệnh này. Hoặc có role name: \`Mimi Games'\`");
        }

        // Kiểm tra nếu có game khác đang hoạt động trong kênh
        if (message.client.xocdiaGames && message.client.xocdiaGames.has(message.channel.id)) {
            return message.channel.send("Hiện đã có một trò chơi Xóc Đĩa đang diễn ra trong kênh này.");
        }

        const host = message.author;
        const numPlayers = parseInt(args[0]);
        const betAmount = parseInt(args[1]);

        // Kiểm tra tham số số người chơi và số tiền cược có phải là số hợp lệ không
        if (isNaN(numPlayers) || isNaN(betAmount) || numPlayers < 2 || numPlayers > 30 || betAmount <= 0) {
            return message.channel.send("Vui lòng nhập số người chơi hợp lệ (từ 2 đến 30) và số tiền cược hợp lệ (lớn hơn 0).\nVi dụ: \`.xocdia 2 500\`\nTrong đó: 2 là số lượng người chơi, 500 số tiền cược.");
        }

        const getUserMoney = (userId) => new Promise((resolve, reject) => {
            dbLove.get("SELECT money FROM user_money WHERE user_id = ?", [userId], (err, row) => {
                if (err) return reject(err);
                resolve(row ? row.money : 0);
            });
        });

        const updateUserMoney = (userId, amount) => new Promise((resolve, reject) => {
            dbLove.run("UPDATE user_money SET money = money + ? WHERE user_id = ?", [amount, userId], function(err) {
                if (err) return reject(err);
                resolve();
            });
        });

        const hostMoney = await getUserMoney(host.id);
        const totalBet = betAmount * numPlayers;

        if (hostMoney < totalBet) {
            return message.channel.send(`Bạn không có đủ tiền để bắt đầu trò chơi. Cần có tối thiểu ${totalBet.toLocaleString()} <:xumimi:1261591338290511973>.`);
        }

        // Tạo Embed hiển thị thông tin trò chơi
        const embed = new EmbedBuilder()
            .setColor('#FFB6C1')
            .setTitle('Trò Chơi Xóc Đĩa')
            .setDescription(`Số tiền cược: **${betAmount.toLocaleString()} <:xumimi:1261591338290511973>**\nDanh sách người tham gia:`)
            .setImage('https://mimibot.fun/xocdia.png')
            .setTimestamp();

        // Tạo các nút điều khiển
        const joinButton = new ButtonBuilder()
            .setCustomId('join')
            .setLabel('Tham Gia')
            .setStyle(ButtonStyle.Primary);

        const leaveButton = new ButtonBuilder()
            .setCustomId('leave')
            .setLabel('Rời')
            .setStyle(ButtonStyle.Danger);

        const startButton = new ButtonBuilder()
            .setCustomId('start')
            .setLabel('Bắt đầu')
            .setStyle(ButtonStyle.Success);

        const endGameButton = new ButtonBuilder()
            .setCustomId('end')
            .setLabel('Tắt game')
            .setStyle(ButtonStyle.Secondary);

        const row = new ActionRowBuilder()
            .addComponents(joinButton, leaveButton, startButton, endGameButton);

        const sentMessage = await message.channel.send({
            embeds: [embed],
            components: [row]
        });

        // Bắt đầu thời gian đếm ngược cho trò chơi
        message.client.xocdiaGames = message.client.xocdiaGames || new Map();
        message.client.xocdiaGames.set(message.channel.id, true);

        const filter = (interaction) => interaction.isButton();
        const collector = sentMessage.createMessageComponentCollector({ filter, time: 180000 }); // Thời gian chờ 3 phút để bắt đầu

        let players = [];

        collector.on('collect', async (interaction) => {
            const user = interaction.user;

            // Người bấm nút tham gia
            if (interaction.customId === 'join') {
                if (user.id === host.id) {
                    return interaction.reply({ content: 'Chủ host không thể tham gia.', ephemeral: true });
                }
                
                if (players.find(p => p.id === user.id)) {
                    return interaction.reply({ content: 'Bạn đã tham gia rồi.', ephemeral: true });
                }

                // Hiển thị các lựa chọn cược cho người chơi
                const betOptionsRow = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder().setCustomId('4white').setLabel('4 Trắng').setStyle(ButtonStyle.Primary),
                        new ButtonBuilder().setCustomId('3white1red').setLabel('3 Trắng 1 Đỏ').setStyle(ButtonStyle.Primary),
                        new ButtonBuilder().setCustomId('2white2red').setLabel('2 Trắng 2 Đỏ').setStyle(ButtonStyle.Primary),
                        new ButtonBuilder().setCustomId('1white3red').setLabel('1 Trắng 3 Đỏ').setStyle(ButtonStyle.Primary),
                        new ButtonBuilder().setCustomId('4red').setLabel('4 Đỏ').setStyle(ButtonStyle.Primary)
                    );

                await interaction.reply({ content: 'Chọn loại cược của bạn:', components: [betOptionsRow], ephemeral: true });

                const betCollector = interaction.channel.createMessageComponentCollector({ filter, time: 30000 });

                betCollector.on('collect', betInteraction => {
                    const betChoice = betInteraction.customId;

                    players.push({ id: user.id, choice: betChoice });
                    embed.setDescription(embed.description + `\n${players.length}. <@${user.id}> - ${betChoice}`);
                    sentMessage.edit({ embeds: [embed] });
                    betInteraction.reply({ content: `Bạn đã chọn cược: ${betChoice}`, ephemeral: true });
                    betCollector.stop();
                });
            }

            // Người bấm nút rời khỏi trò chơi
            if (interaction.customId === 'leave') {
                players = players.filter(p => p.id !== user.id);
                embed.setDescription('Danh sách người tham gia đã được cập nhật.');
                sentMessage.edit({ embeds: [embed] });
                interaction.reply({ content: 'Bạn đã rời khỏi trò chơi.', ephemeral: true });
            }

            // Bắt đầu trò chơi
            if (interaction.customId === 'start' && interaction.user.id === host.id) {
                if (players.length === 0) {
                    return interaction.reply({ content: 'Chưa có người chơi nào tham gia.', ephemeral: true });
                }

                // Gửi tin nhắn với emoji xóc đĩa xoay ban đầu
                let xocDiaMessage = `# <a:xucxac:1262719486960730155> <:dotpink:1280728743769542817> <a:xucxac:1262719486960730155> <:dotpink:1280728743769542817> <a:xucxac:1262719486960730155> <:dotpink:1280728743769542817> <a:xucxac:1262719486960730155> `;
                const resultMessage = await message.channel.send(xocDiaMessage);

                // Kết quả trò chơi
                const resultArray = ['4white', '3white1red', '2white2red', '1white3red', '4red'][Math.floor(Math.random() * 5)];
                const resultEmojis = [];

                // Biến đổi các emoji cho từng kết quả
                if (resultArray === '4white') resultEmojis.push('<a:mattrang:1283442615408263242>', '<a:mattrang:1283442615408263242>', '<a:mattrang:1283442615408263242>', '<a:mattrang:1283442615408263242>');
                if (resultArray === '3white1red') resultEmojis.push('<a:mattrang:1283442615408263242>', '<a:mattrang:1283442615408263242>', '<a:mattrang:1283442615408263242>', '<a:matdo:1283442605132222497>');
                if (resultArray === '2white2red') resultEmojis.push('<a:mattrang:1283442615408263242>', '<a:mattrang:1283442615408263242>', '<a:matdo:1283442605132222497>', '<a:matdo:1283442605132222497>');
                if (resultArray === '1white3red') resultEmojis.push('<a:mattrang:1283442615408263242>', '<a:matdo:1283442605132222497>', '<a:matdo:1283442605132222497>', '<a:matdo:1283442605132222497>');
                if (resultArray === '4red') resultEmojis.push('<a:matdo:1283442605132222497>', '<a:matdo:1283442605132222497>', '<a:matdo:1283442605132222497>', '<a:matdo:1283442605132222497>');

                // Cập nhật kết quả từng bước
                for (let i = 0; i < resultEmojis.length; i++) {
                    xocDiaMessage = xocDiaMessage.replace('<a:xucxac:1262719486960730155>', resultEmojis[i]);
                    await resultMessage.edit(xocDiaMessage);
                    await new Promise(resolve => setTimeout(resolve, 1000)); // Chờ 1 giây giữa các lần cập nhật
                }

                let numWinners = 0;
                let numLosers = 0;
                
                embed.setDescription(`Kết quả là: ${resultArray}\n`);
                players.forEach((player, index) => {
                    if (player.choice === resultArray) {
                        embed.setDescription(embed.description + `\n${index + 1}. <@${player.id}> - Thắng`);
                        updateUserMoney(player.id, betAmount); // Thêm tiền cho người chơi thắng
                        numWinners += 1;
                    } else {
                        embed.setDescription(embed.description + `\n${index + 1}. <@${player.id}> - Thua`);
                        updateUserMoney(player.id, -betAmount); // Trừ tiền người chơi thua
                        numLosers += 1;
                    }
                });

                // Cập nhật tiền của host
                const hostLosses = betAmount * numWinners;
                const hostGains = betAmount * numLosers;
                const finalHostMoney = hostMoney - hostLosses + hostGains;
                
                await updateUserMoney(host.id, -hostLosses + hostGains); // Host mất tiền cho người thắng, nhận tiền từ người thua
                embed.setDescription(embed.description + `\n\nChủ host còn lại: **${finalHostMoney.toLocaleString()} <:xumimi:1261591338290511973>**`);

                sentMessage.edit({ embeds: [embed] });

                // Lưu lịch sử trò chơi vào cơ sở dữ liệu
                db.run(
                    `INSERT INTO games_history (host_id, bet_amount, result, date_played) VALUES (?, ?, ?, ?)`, 
                    [host.id, betAmount, resultArray, new Date().toISOString()]
                );

                interaction.reply('Trò chơi kết thúc!');
                collector.stop();
            }

            // Tắt game
            if (interaction.customId === 'end' && interaction.user.id === host.id) {
                interaction.reply('Trò chơi đã bị hủy.');
                collector.stop();
            }
        });

        collector.on('end', () => {
            sentMessage.edit({ components: [] }); // Vô hiệu hóa các nút sau khi hết thời gian
            message.client.xocdiaGames.delete(message.channel.id); // Xóa trạng thái game của kênh
        });

        // Tự động kết thúc game sau 15 phút
        setTimeout(() => {
            if (message.client.xocdiaGames.has(message.channel.id)) {
                message.channel.send("Trò chơi đã kết thúc sau 15 phút.");
                message.client.xocdiaGames.delete(message.channel.id); // Xóa trạng thái game của kênh
            }
        }, 15 * 60 * 1000);
    }
};
