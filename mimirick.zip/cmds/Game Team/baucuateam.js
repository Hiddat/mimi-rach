const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionsBitField } = require('discord.js');
const dbLove = require('../../db/databaseLove');
const { MAX_BET } = require('../../config.json');

module.exports = {
    name: 'baucuateam',
    aliases: ['bct'],
    category: 'Game cược xu mimi theo Team',
    cooldown: 10,
    description: 'Chơi Bầu Cua theo đội',
    async execute(message, args) {
        if (args.length < 2) {
            return message.reply('Vui lòng nhập số tiền cược và số lượng người chơi tối đa.');
        }

        let betAmount = parseInt(args[0]);
        let maxPlayers = parseInt(args[1]);

        if (isNaN(betAmount) || betAmount <= 0 || isNaN(maxPlayers) || maxPlayers <= 0 || maxPlayers > 20) {
            return message.reply('Vui lòng nhập số tiền cược và số lượng người chơi tối đa hợp lệ (tối đa 20 người).');
        }

        if (maxPlayers < 2) {
            maxPlayers = 2;
        }

        if (betAmount > MAX_BET) {
            return message.reply(`Số tiền cược không được vượt quá ${MAX_BET.toLocaleString()} <:xumimi:1261591338290511973>.`);
        }

        let players = [];
        let gameStarted = false;

        const baucuaEmojis = {
            'bầu': '<:bau:1254379355065286757>',
            'cua': '<:cua:1254379406374211665>',
            'tôm': '<:tom:1254379822314950737>',
            'cá': '<:ca:1254379517582245898>',
            'gà': '<:ga:1254379593637564528>',
            'hươu': '<:nai:1254379752807202942>'
        };

        const options = ['bầu', 'cua', 'tôm', 'cá', 'gà', 'hươu'];
        const rollingEmoji = '<a:lac:1254379696897130589>';

        const embed = new EmbedBuilder()
            .setTitle('Trò chơi Bầu Cua Đội')
            .setDescription(`Danh sách người chơi - ${betAmount} <:xumimi:1261591338290511973>:\n\n(Trống)`)
            .setColor('#FFD700')
            .setTimestamp();

        const actionRow = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('join')
                    .setLabel('Tham gia')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('leave')
                    .setLabel('Rời khỏi')
                    .setStyle(ButtonStyle.Danger),
                new ButtonBuilder()
                    .setCustomId('start')
                    .setLabel('Bắt đầu')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(true),
                new ButtonBuilder()
                    .setCustomId('end')
                    .setLabel('Tắt game')
                    .setStyle(ButtonStyle.Secondary)
            );

        const sentMessage = await message.channel.send({ embeds: [embed], components: [actionRow] });

        const filter = i => ['join', 'leave', 'start', 'end'].includes(i.customId) && !gameStarted;
        const collector = sentMessage.createMessageComponentCollector({ filter, time: 5 * 60 * 1000 });

        collector.on('collect', async interaction => {
            const userId = interaction.user.id;
            const isGameManager = userId === message.author.id || interaction.member.permissions.has(PermissionsBitField.Flags.ManageGuild);

            if (interaction.customId === 'join') {
                if (players.length >= maxPlayers) {
                    return interaction.reply({ content: `Số lượng người chơi đã đạt giới hạn (${maxPlayers}).`, ephemeral: true });
                }

                const userMoney = await getUserMoney(userId);
                const soTiencanchoi = betAmount * 3;
                if (userMoney < soTiencanchoi) {
                    return interaction.reply({ content: `Bạn cần ít nhất ${soTiencanchoi.toLocaleString()} <:xumimi:1261591338290511973> để tham gia trò chơi.`, ephemeral: true });
                }

                if (players.find(p => p.id === userId)) {
                    return interaction.reply({ content: 'Bạn đã tham gia trò chơi rồi.', ephemeral: true });
                }

                await interaction.deferReply({ ephemeral: true });

                const choiceRow1 = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId('bau')
                            .setLabel('Bầu')
                            .setStyle(ButtonStyle.Primary)
                            .setEmoji(baucuaEmojis['bầu']),
                        new ButtonBuilder()
                            .setCustomId('cua')
                            .setLabel('Cua')
                            .setStyle(ButtonStyle.Primary)
                            .setEmoji(baucuaEmojis['cua']),
                        new ButtonBuilder()
                            .setCustomId('tom')
                            .setLabel('Tôm')
                            .setStyle(ButtonStyle.Primary)
                            .setEmoji(baucuaEmojis['tôm'])
                    );

                const choiceRow2 = new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId('ca')
                            .setLabel('Cá')
                            .setStyle(ButtonStyle.Primary)
                            .setEmoji(baucuaEmojis['cá']),
                        new ButtonBuilder()
                            .setCustomId('ga')
                            .setLabel('Gà')
                            .setStyle(ButtonStyle.Primary)
                            .setEmoji(baucuaEmojis['gà']),
                        new ButtonBuilder()
                            .setCustomId('nai')
                            .setLabel('Hươu')
                            .setStyle(ButtonStyle.Primary)
                            .setEmoji(baucuaEmojis['hươu'])
                    );

                await interaction.editReply({ content: 'Vui lòng chọn loại cược của bạn.', components: [choiceRow1, choiceRow2] });

                const choiceFilter = i => ['bau', 'cua', 'tom', 'ca', 'ga', 'nai'].includes(i.customId) && i.user.id === userId;
                const choiceCollector = interaction.channel.createMessageComponentCollector({ filter: choiceFilter, max: 1, time: 60000 });

                choiceCollector.on('collect', async choiceInteraction => {
                    const choiceMap = {
                        'bau': 'bầu',
                        'cua': 'cua',
                        'tom': 'tôm',
                        'ca': 'cá',
                        'ga': 'gà',
                        'nai': 'hươu'
                    };

                    const choice = choiceMap[choiceInteraction.customId];
                    players.push({ id: userId, tag: choiceInteraction.user.tag, choice: choice });

                    embed.setDescription(players.map((p, index) => `**${index + 1}. <@${p.id}> - ${p.choice.toUpperCase()}**`).join('\n\n'));
                    await sentMessage.edit({ embeds: [embed] });

                    if (players.length >= 2) {
                        actionRow.components[2].setDisabled(false); // Kích hoạt nút "Bắt đầu" khi đủ 2 người chơi
                        await sentMessage.edit({ components: [actionRow] });
                    }

                    await choiceInteraction.update({ content: `Bạn đã chọn ${choice.toUpperCase()}.`, components: [] });
                });

            } else if (interaction.customId === 'leave') {
                const playerIndex = players.findIndex(p => p.id === userId);
                if (playerIndex === -1) {
                    return interaction.reply({ content: 'Bạn không có trong danh sách tham gia.', ephemeral: true });
                }

                players.splice(playerIndex, 1);
                embed.setDescription(players.length ? players.map((p, index) => `**${index + 1}. <@${p.id}>**`).join('\n\n') : '(Trống)');
                await sentMessage.edit({ embeds: [embed] });

                if (players.length < 2) {
                    actionRow.components[2].setDisabled(true); // Tắt nút "Bắt đầu" nếu còn ít hơn 2 người chơi
                    await sentMessage.edit({ components: [actionRow] });
                }

                await interaction.reply({ content: 'Bạn đã rời khỏi trò chơi.', ephemeral: true });

            } else if (interaction.customId === 'start') {
                if (!isGameManager) {
                    return interaction.reply({ content: 'Bạn không có quyền bắt đầu trò chơi.', ephemeral: true });
                }

                if (players.length < 2) {
                    return interaction.reply({ content: 'Cần ít nhất 2 người để bắt đầu trò chơi.', ephemeral: true });
                }

                gameStarted = true;
                collector.stop();

                await startGame(sentMessage, players, embed, betAmount);
            } else if (interaction.customId === 'end') {
                if (!isGameManager) {
                    return interaction.reply({ content: 'Bạn không có quyền tắt trò chơi.', ephemeral: true });
                }

                gameStarted = true;
                collector.stop();

                embed.setDescription('Trò chơi đã bị hủy.');
                await sentMessage.edit({ embeds: [embed], components: [] });
                await interaction.reply({ content: 'Trò chơi đã bị hủy.', ephemeral: true });
            }
        });

        collector.on('end', async () => {
            if (!gameStarted) {
                embed.setDescription('Trò chơi đã kết thúc do không đủ người tham gia hoặc hết thời gian.');
                await sentMessage.edit({ embeds: [embed], components: [] });
            }
        });

        async function startGame(sentMessage, players, embed, betAmount) {
            const guild = message.guild;
            const channel = message.channel;
            const userHasPermission = channel.permissionsFor(message.member).has(PermissionsBitField.Flags.CreatePublicThreads);

            if (userHasPermission) {
                try {
                    const thread = await channel.threads.create({
                        name: `Bầu Cua Đội - ${message.author.username}`,
                        autoArchiveDuration: 60,
                        reason: 'Chủ đề được tạo cho trò chơi Bầu Cua',
                    });

                    await thread.send({ embeds: [embed] });
                    await runGameInThread(thread, players, betAmount);
                } catch (error) {
                    console.error('Không thể tạo chủ đề:', error);
                    await channel.send('Không thể tạo chủ đề, trò chơi sẽ diễn ra tại đây.');
                    await runGameInThread(channel, players, betAmount);
                }
            } else {
                await channel.send('Bạn không có quyền tạo chủ đề, trò chơi sẽ diễn ra tại đây.');
                await runGameInThread(channel, players, betAmount);
            }
        }

        async function runGameInThread(threadOrChannel, players, betAmount) {
            const rollingEmoji = '<a:lac:1254379696897130589>';
            const baucuaEmojis = {
                'bầu': '<:bau:1254379355065286757>',
                'cua': '<:cua:1254379406374211665>',
                'tôm': '<:tom:1254379822314950737>',
                'cá': '<:ca:1254379517582245898>',
                'gà': '<:ga:1254379593637564528>',
                'hươu': '<:nai:1254379752807202942>'
            };
            const options = ['bầu', 'cua', 'tôm', 'cá', 'gà', 'hươu'];

            const embed = new EmbedBuilder()
                .setDescription(`${rollingEmoji} - ${rollingEmoji} - ${rollingEmoji}`)
                .setColor('#FFD700');

            await threadOrChannel.send({ embeds: [embed] });

            setTimeout(async () => {
                const dice1 = Math.floor(Math.random() * 6);
                const dice2 = Math.floor(Math.random() * 6);
                const dice3 = Math.floor(Math.random() * 6);

                embed.setDescription(`${baucuaEmojis[options[dice1]]} - ${baucuaEmojis[options[dice2]]} - ${baucuaEmojis[options[dice3]]}`);
                await threadOrChannel.send({ embeds: [embed] });

                const results = [options[dice1], options[dice2], options[dice3]];
                await calculateWinnersAndLosers(threadOrChannel, players, results, betAmount);
            }, 3000);
        }

        async function calculateWinnersAndLosers(channel, players, results, betAmount) {
            const winners = players.filter(p => results.includes(p.choice));
            const losers = players.filter(p => !results.includes(p.choice));

            let winnerTags = '';
            let loserTags = '';

            if (winners.length === players.length || losers.length === players.length) {
                winnerTags = losers.length ? 'Tất cả người chơi đều thua, không ai mất tiền.' : 'Tất cả người chơi đều thắng, không ai nhận thêm tiền.';
                loserTags = '';
            } else {
                await updatePlayerMoney(winners, losers, betAmount);
                winnerTags = winners.map(p => `<@${p.id}> - Nhận ${betAmount * losers.length} <:xumimi:1261591338290511973>`).join('\n');
                loserTags = losers.map(p => `<@${p.id}> - Mất ${betAmount * winners.length} <:xumimi:1261591338290511973>`).join('\n');
            }

            const resultEmbed = new EmbedBuilder()
                .setColor('#FFD700')
                .setTitle('Kết quả Bầu Cua Đội')
                .setDescription(`**Kết quả**: ${results.map(result => baucuaEmojis[result]).join(' ')}\n\n**Người thắng**:\n${winnerTags || '(Không có ai)'}\n\n**Người thua**:\n${loserTags || '(Không có ai)'}`)
                .setTimestamp();

            await channel.send({ embeds: [resultEmbed], components: [] });
        }

        async function getUserMoney(userId) {
            return new Promise((resolve, reject) => {
                dbLove.get("SELECT money FROM user_money WHERE user_id = ?", [userId], (err, row) => {
                    if (err) return reject(err);
                    resolve(row ? row.money : 0);
                });
            });
        }

        async function updatePlayerMoney(winners, losers, betAmount) {
            const winAmount = betAmount * losers.length;
            const lossAmount = betAmount * winners.length;

            const updateMoney = (userId, amount) => new Promise((resolve, reject) => {
                dbLove.run("UPDATE user_money SET money = money + ? WHERE user_id = ?", [amount, userId], function(err) {
                    if (err) return reject(err);
                    resolve();
                });
            });

            for (const winner of winners) {
                await updateMoney(winner.id, winAmount);
            }

            for (const loser of losers) {
                await updateMoney(loser.id, -lossAmount);
            }
        }
    },
};

// const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionsBitField } = require('discord.js');
// const dbLove = require('../../db/databaseLove');
// const { MAX_BET } = require('../../config.json');

// module.exports = {
//     name: 'baucuateam',
//     aliases: ['bct'],
//     category: 'Game cược xu mimi theo Team',
//     cooldown: 10,
//     description: 'Chơi Bầu Cua theo đội',
//     async execute(message, args) {
//         if (args.length < 2) {
//             return message.reply('Vui lòng nhập số tiền cược và số lượng người chơi tối đa.');
//         }

//         let betAmount = parseInt(args[0]);
//         let maxPlayers = parseInt(args[1]);

//         if (isNaN(betAmount) || betAmount <= 0 || isNaN(maxPlayers) || maxPlayers <= 0 || maxPlayers > 20) {
//             return message.reply('Vui lòng nhập số tiền cược và số lượng người chơi tối đa hợp lệ (tối đa 20 người).');
//         }

//         if (maxPlayers < 2) {
//             maxPlayers = 2;
//         }

//         if (betAmount > MAX_BET) {
//             return message.reply(`Số tiền cược không được vượt quá ${MAX_BET.toLocaleString()} <:xumimi:1261591338290511973>.`);
//         }

//         let players = [];
//         let gameStarted = false;

//         const baucuaEmojis = {
//             'bầu': '<:bau:1254379355065286757>',
//             'cua': '<:cua:1254379406374211665>',
//             'tôm': '<:tom:1254379822314950737>',
//             'cá': '<:ca:1254379517582245898>',
//             'gà': '<:ga:1254379593637564528>',
//             'hươu': '<:nai:1254379752807202942>'
//         };

//         const options = ['bầu', 'cua', 'tôm', 'cá', 'gà', 'hươu'];
//         const rollingEmoji = '<a:lac:1254379696897130589>';

//         const embed = new EmbedBuilder()
//             .setTitle('Trò chơi Bầu Cua Đội')
//             .setDescription(`Danh sách người chơi - ${betAmount} <:xumimi:1261591338290511973>:\n\n(Trống)`)
//             .setColor('#FFD700')
//             .setTimestamp();

//         // Action buttons for managing the game
//         const actionRow = new ActionRowBuilder()
//             .addComponents(
//                 new ButtonBuilder()
//                     .setCustomId('join')
//                     .setLabel('Tham gia')
//                     .setStyle(ButtonStyle.Success),
//                 new ButtonBuilder()
//                     .setCustomId('leave')
//                     .setLabel('Rời khỏi')
//                     .setStyle(ButtonStyle.Danger),
//                 new ButtonBuilder()
//                     .setCustomId('start')
//                     .setLabel('Bắt đầu')
//                     .setStyle(ButtonStyle.Primary)
//                     .setDisabled(true), // Disabled until enough players join
//                 new ButtonBuilder()
//                     .setCustomId('end')
//                     .setLabel('Tắt game')
//                     .setStyle(ButtonStyle.Secondary)
//             );

//         const sentMessage = await message.channel.send({ embeds: [embed], components: [actionRow] });

//         const filter = i => ['join', 'leave', 'start', 'end'].includes(i.customId) && !gameStarted;
//         const collector = sentMessage.createMessageComponentCollector({ filter, time: 5 * 60 * 1000 });

//         collector.on('collect', async interaction => {
//             const userId = interaction.user.id;
//             const isGameManager = userId === message.author.id || interaction.member.permissions.has(PermissionsBitField.Flags.ManageGuild);

//             if (interaction.customId === 'join') {
//                 if (players.length >= maxPlayers) {
//                     return interaction.reply({ content: `Số lượng người chơi đã đạt giới hạn (${maxPlayers}).`, ephemeral: true });
//                 }

//                 const userMoney = await getUserMoney(userId);
//                 if (userMoney < betAmount) {
//                     return interaction.reply({ content: `Bạn cần ít nhất ${betAmount.toLocaleString()} <:xumimi:1261591338290511973> để tham gia trò chơi.`, ephemeral: true });
//                 }

//                 if (players.find(p => p.id === userId)) {
//                     return interaction.reply({ content: 'Bạn đã tham gia trò chơi rồi.', ephemeral: true });
//                 }

//                 // Defer reply and move on to betting selection
//                 await interaction.deferReply({ ephemeral: true });

//                 // Show the user the choice buttons (bet types) in two rows
//                 const choiceRow1 = new ActionRowBuilder()
//                     .addComponents(
//                         new ButtonBuilder()
//                             .setCustomId('bau')
//                             .setLabel('Bầu')
//                             .setStyle(ButtonStyle.Primary)
//                             .setEmoji(baucuaEmojis['bầu']),
//                         new ButtonBuilder()
//                             .setCustomId('cua')
//                             .setLabel('Cua')
//                             .setStyle(ButtonStyle.Primary)
//                             .setEmoji(baucuaEmojis['cua']),
//                         new ButtonBuilder()
//                             .setCustomId('tom')
//                             .setLabel('Tôm')
//                             .setStyle(ButtonStyle.Primary)
//                             .setEmoji(baucuaEmojis['tôm'])
//                     );

//                 const choiceRow2 = new ActionRowBuilder()
//                     .addComponents(
//                         new ButtonBuilder()
//                             .setCustomId('ca')
//                             .setLabel('Cá')
//                             .setStyle(ButtonStyle.Primary)
//                             .setEmoji(baucuaEmojis['cá']),
//                         new ButtonBuilder()
//                             .setCustomId('ga')
//                             .setLabel('Gà')
//                             .setStyle(ButtonStyle.Primary)
//                             .setEmoji(baucuaEmojis['gà']),
//                         new ButtonBuilder()
//                             .setCustomId('nai')
//                             .setLabel('Hươu')
//                             .setStyle(ButtonStyle.Primary)
//                             .setEmoji(baucuaEmojis['hươu'])
//                     );

//                 await interaction.editReply({ content: 'Vui lòng chọn loại cược của bạn.', components: [choiceRow1, choiceRow2] });

//                 const choiceFilter = i => ['bau', 'cua', 'tom', 'ca', 'ga', 'nai'].includes(i.customId) && i.user.id === userId;
//                 const choiceCollector = interaction.channel.createMessageComponentCollector({ filter: choiceFilter, max: 1, time: 60000 });

//                 choiceCollector.on('collect', async choiceInteraction => {
//                     const choiceMap = {
//                         'bau': 'bầu',
//                         'cua': 'cua',
//                         'tom': 'tôm',
//                         'ca': 'cá',
//                         'ga': 'gà',
//                         'nai': 'hươu'
//                     };

//                     const choice = choiceMap[choiceInteraction.customId];
//                     players.push({ id: userId, tag: choiceInteraction.user.tag, choice: choice });

//                     embed.setDescription(players.map((p, index) => `**${index + 1}. <@${p.id}> - ${p.choice.toUpperCase()}**`).join('\n\n'));
//                     await sentMessage.edit({ embeds: [embed] });

//                     if (players.length >= 2) {
//                         actionRow.components[2].setDisabled(false); // Enable the start button when there are at least 2 players
//                         await sentMessage.edit({ components: [actionRow] });
//                     }

//                     await choiceInteraction.update({ content: `Bạn đã chọn ${choice.toUpperCase()}.`, components: [] });
//                 });

//             } else if (interaction.customId === 'leave') {
//                 const playerIndex = players.findIndex(p => p.id === userId);
//                 if (playerIndex === -1) {
//                     return interaction.reply({ content: 'Bạn không có trong danh sách tham gia.', ephemeral: true });
//                 }

//                 players.splice(playerIndex, 1);
//                 embed.setDescription(players.length ? players.map((p, index) => `**${index + 1}. <@${p.id}>**`).join('\n\n') : '(Trống)');
//                 await sentMessage.edit({ embeds: [embed] });

//                 if (players.length < 2) {
//                     actionRow.components[2].setDisabled(true); // Disable the start button if fewer than 2 players remain
//                     await sentMessage.edit({ components: [actionRow] });
//                 }

//                 await interaction.reply({ content: 'Bạn đã rời khỏi trò chơi.', ephemeral: true });

//             } else if (interaction.customId === 'start') {
//                 if (!isGameManager) {
//                     return interaction.reply({ content: 'Bạn không có quyền bắt đầu trò chơi.', ephemeral: true });
//                 }

//                 if (players.length < 2) {
//                     return interaction.reply({ content: 'Cần ít nhất 2 người để bắt đầu trò chơi.', ephemeral: true });
//                 }

//                 gameStarted = true;
//                 collector.stop();

//                 // Proceed with starting the game
//                 await startGame(sentMessage, players, embed, betAmount);
//             } else if (interaction.customId === 'end') {
//                 if (!isGameManager) {
//                     return interaction.reply({ content: 'Bạn không có quyền tắt trò chơi.', ephemeral: true });
//                 }

//                 gameStarted = true;
//                 collector.stop();

//                 embed.setDescription('Trò chơi đã bị hủy.');
//                 await sentMessage.edit({ embeds: [embed], components: [] });
//                 await interaction.reply({ content: 'Trò chơi đã bị hủy.', ephemeral: true });
//             }
//         });

//         collector.on('end', async () => {
//             if (!gameStarted) {
//                 embed.setDescription('Trò chơi đã kết thúc do không đủ người tham gia hoặc hết thời gian.');
//                 await sentMessage.edit({ embeds: [embed], components: [] });
//             }
//         });

//         const { PermissionsBitField } = require('discord.js');

//         async function startGame(sentMessage, players, embed, betAmount) {
//             const dice1 = Math.floor(Math.random() * 6);
//             const dice2 = Math.floor(Math.random() * 6);
//             const dice3 = Math.floor(Math.random() * 6);

//             embed.setDescription(`${rollingEmoji} - ${rollingEmoji} - ${rollingEmoji}`);
//             await sentMessage.edit({ embeds: [embed] });

//             setTimeout(async () => {
//                 embed.setDescription(`${baucuaEmojis[options[dice1]]} - ${rollingEmoji} - ${rollingEmoji}`);
//                 await sentMessage.edit({ embeds: [embed] });
//             }, 1000);

//             setTimeout(async () => {
//                 embed.setDescription(`${baucuaEmojis[options[dice1]]} - ${baucuaEmojis[options[dice2]]} - ${rollingEmoji}`);
//                 await sentMessage.edit({ embeds: [embed] });
//             }, 2000);

//             setTimeout(async () => {
//                 embed.setDescription(`${baucuaEmojis[options[dice1]]} - ${baucuaEmojis[options[dice2]]} - ${baucuaEmojis[options[dice3]]}`);
//                 await sentMessage.edit({ embeds: [embed] });

//                 const results = [options[dice1], options[dice2], options[dice3]];
//                 await calculateWinnersAndLosers(sentMessage, players, results, betAmount);
//             }, 3000);
//         }

//         async function calculateWinnersAndLosers(sentMessage, players, results, betAmount) {
//             const winners = players.filter(p => results.includes(p.choice));
//             const losers = players.filter(p => !results.includes(p.choice));

//             let winnerTags = '';
//             let loserTags = '';

//             if (winners.length === players.length || losers.length === players.length) {
//                 winnerTags = losers.length ? 'Tất cả người chơi đều thua, không ai mất tiền.' : 'Tất cả người chơi đều thắng, không ai nhận thêm tiền.';
//                 loserTags = '';
//             } else {
//                 await updatePlayerMoney(winners, losers, betAmount);
//                 winnerTags = winners.map(p => `<@${p.id}> - Nhận ${betAmount * losers.length} <:xumimi:1261591338290511973>`).join('\n');
//                 loserTags = losers.map(p => `<@${p.id}> - Mất ${betAmount * winners.length} <:xumimi:1261591338290511973>`).join('\n');
//             }

//             const resultEmbed = new EmbedBuilder()
//                 .setColor('#FFD700')
//                 .setTitle('Kết quả Bầu Cua Đội')
//                 .setDescription(`**Kết quả**: ${results.map(result => baucuaEmojis[result]).join(' ')}\n\n**Người thắng**:\n${winnerTags || '(Không có ai)'}\n\n**Người thua**:\n${loserTags || '(Không có ai)'}`)
//                 .setTimestamp();

//             await sentMessage.edit({ embeds: [resultEmbed], components: [] });
//         }

//         async function getUserMoney(userId) {
//             return new Promise((resolve, reject) => {
//                 dbLove.get("SELECT money FROM user_money WHERE user_id = ?", [userId], (err, row) => {
//                     if (err) return reject(err);
//                     resolve(row ? row.money : 0);
//                 });
//             });
//         }

//         async function updatePlayerMoney(winners, losers, betAmount) {
//             const winAmount = betAmount * losers.length;
//             const lossAmount = betAmount * winners.length;

//             const updateMoney = (userId, amount) => new Promise((resolve, reject) => {
//                 dbLove.run("UPDATE user_money SET money = money + ? WHERE user_id = ?", [amount, userId], function(err) {
//                     if (err) return reject(err);
//                     resolve();
//                 });
//             });

//             for (const winner of winners) {
//                 await updateMoney(winner.id, winAmount);
//             }

//             for (const loser of losers) {
//                 await updateMoney(loser.id, -lossAmount);
//             }
//         }
//     },
// };
