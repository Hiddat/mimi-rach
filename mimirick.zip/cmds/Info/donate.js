const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'donate',
  category: 'Info',
  aliases: ['dnt'],
    cooldown: 3,
  description: 'Provides donation details.',
  async execute(message, args, client) { 
    const embed = new EmbedBuilder()
      .setAuthor({ name: 'Donation Information' })
      .setDescription('<a:mcw_timchat:1255340646248616006>  Tiên Phong Bank \n<a:mcw_timchat:1255340646248616006>  Pham Thanh Xuan\n <a:NQG_xc112:1255341478855573597>  Xuan2001')
      .setThumbnail('https://thanhxuan.xyz/qr.jpg')
      .setImage('https://thanhxuan.xyz/banner.jpg')
      .setTimestamp();

    await message.reply({ embeds: [embed] });
  },
};
