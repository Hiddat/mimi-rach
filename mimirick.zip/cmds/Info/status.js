const { EmbedBuilder } = require('discord.js');
const AsciiTable = require('ascii-table');

module.exports = {
    name: 'status',
    category: 'Info',
    aliases: ['stt'],
    cooldown: 3,
    description: 'Hiển thị tình trạng hiện tại của bot',
    async execute(message) {
        const client = message.client;

        const serverCount = client.guilds.cache.size;
        const memberCount = client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0);
        const uptime = client.uptime;
        const ping = client.ws.ping;
        const ramUsage = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);

        const table = new AsciiTable('Mimi Bot Status');
        table
            .setHeading('Category', 'Value')
            .setBorder('|', '-', ' ', ' ');

        table.addRow('Server Count', serverCount.toLocaleString());
        table.addRow('Member Count', memberCount.toLocaleString());
        table.addRow('Uptime', `${Math.floor(uptime / 86400000)}d ${new Date(uptime).toISOString().substr(11, 8)}`);
        table.addRow('Ping', `~${ping}ms`);
        table.addRow('RAM Usage', `${ramUsage} MB`);

        message.reply(`\`\`\`${table.toString()}\`\`\``);
    },
};