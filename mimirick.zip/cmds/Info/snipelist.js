const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const db = require('../../db/databaseBetaDev');

module.exports = {
    name: 'snipelist',
    category: 'Info',
    cooldown: 3,
    description: 'Hiển thị danh sách tin nhắn bị xoá trong server',
    async execute(message) {
        const guildId = message.guild.id;
        const tenMinutesAgo = Date.now() - 360 * 60 * 1000;  // 6 tiếng trước

        db.all(`SELECT * FROM deleted_messages WHERE guild_id = ? AND timestamp > ? ORDER BY timestamp DESC`, [guildId, tenMinutesAgo], (err, rows) => {
            if (err) {
                console.error(err);
                return message.reply('Đã xảy ra lỗi khi truy vấn lịch sử tin nhắn bị xoá.');
            }

            if (rows.length === 0) {
                return message.reply('Không có tin nhắn bị xoá trong 6 tiếng gần nhất.');
            }

            let currentPage = 0;
            const itemsPerPage = 20;  // Số lượng tin nhắn mỗi trang

            const generateEmbed = (page) => {
                const start = page * itemsPerPage;
                const end = Math.min(start + itemsPerPage, rows.length);
                const pageItems = rows.slice(start, end);

                const description = pageItems.map((msg, index) => {
                    return `**#${start + index + 1}** - <@${msg.user_id}>: \`${msg.content}\` **<t:${Math.floor(msg.timestamp / 1000)}:R>**`;
                }).join('\n');

                const embed = new EmbedBuilder()
                    .setColor('#FF69B4')
                    .setTitle(`Danh sách tin nhắn bị xoá (${start + 1}-${end}/${rows.length})`)
                    .setDescription(description)
                    .setFooter({ text: `Trang ${page + 1}/${Math.ceil(rows.length / itemsPerPage)}` })
                    .setTimestamp();
                return embed;
            };

            const embedMessage = message.channel.send({ embeds: [generateEmbed(currentPage)], components: [generateActionRow(currentPage, rows.length)] });

            const filter = i => i.user.id === message.author.id;
            const collector = message.channel.createMessageComponentCollector({ filter, time: 60000 });

            collector.on('collect', async i => {
                if (i.customId === 'previous') {
                    if (currentPage > 0) {
                        currentPage--;
                        await i.update({ embeds: [generateEmbed(currentPage)], components: [generateActionRow(currentPage, rows.length)] });
                    } else {
                        await i.update({ components: [generateActionRow(currentPage, rows.length)] });
                    }
                } else if (i.customId === 'next') {
                    if (currentPage < Math.ceil(rows.length / itemsPerPage) - 1) {
                        currentPage++;
                        await i.update({ embeds: [generateEmbed(currentPage)], components: [generateActionRow(currentPage, rows.length)] });
                    } else {
                        await i.update({ components: [generateActionRow(currentPage, rows.length)] });
                    }
                }
            });

            collector.on('end', collected => {
                console.log(`Collected ${collected.size} interactions.`);
            });

            function generateActionRow(currentPage, totalRows) {
                return new ActionRowBuilder()
                    .addComponents(
                        new ButtonBuilder()
                            .setCustomId('previous')
                            .setLabel('Quay lại')
                            .setStyle(ButtonStyle.Primary)
                            .setDisabled(currentPage === 0),
                        new ButtonBuilder()
                            .setCustomId('next')
                            .setLabel('Tiếp theo')
                            .setStyle(ButtonStyle.Primary)
                            .setDisabled(currentPage >= Math.ceil(totalRows / itemsPerPage) - 1)
                    );
            }
        });
    },
};
