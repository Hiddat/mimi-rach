const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');

module.exports = {
    name: 'avatar',
    description: 'Hiển thị avatar và banner của người dùng.',
    category: 'Info',
    aliases: ['av', 'pfp'],
    cooldown: 3,
    async execute(message, args) { 
        let user;

        if (args.length) {
            try {
                user = await message.client.users.fetch(args[0].replace(/[<@!>]/g, ''));
            } catch (error) {
                return message.reply('Không tìm thấy người dùng này.');
            }
        } else {
            user = message.author;
        }

        try {
            const member = await message.guild.members.fetch(user.id);
            const userDetails = await user.fetch();
            const avatarUrl = userDetails.displayAvatarURL({ dynamic: true, size: 512 });
            const serverAvatarUrl = member.displayAvatarURL({ dynamic: true, size: 512 });
            const bannerUrl = userDetails.bannerURL({ dynamic: true, size: 1024 });

            const embed = new EmbedBuilder()
                .setTitle(`<a:mcw_timchat:1255340646248616006> Avatar của ${user.tag} <a:mcw_timchat:1255340646248616006>`)
                .setImage(avatarUrl)
                .setColor('#FFB6C1');

            if (bannerUrl) {
                embed.setDescription(`<a:7420bearloveuwu1:1261961349836177448> [Link avatar](${avatarUrl})\n\n[Link banner](${bannerUrl})`);
            } else {
                embed.setDescription(`<a:9761lightpinkcrown:1261960952224546818> [Link avatar](${avatarUrl})\n\nNgười dùng này không có banner.`);
            }

            const row = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('avatar_original')
                    .setLabel('Avatar')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('<:mimi:1258599282311827496>'),
                new ButtonBuilder()
                    .setCustomId('avatar_server')
                    .setLabel('Avatar sv')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('<a:mcw_timchat:1255340646248616006>'),
                new ButtonBuilder()
                    .setCustomId('banner_original')
                    .setLabel('Banner')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('<a:NQG_xc112:1255341478855573597>'),
                new ButtonBuilder()
                    .setCustomId('banner_server')
                    .setLabel('Banner sv')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('<a:pinkfire:1256798201055285370>')
            );

            const responseMessage = await message.channel.send({ embeds: [embed], components: [row] });

            const collector = responseMessage.createMessageComponentCollector({ componentType: ComponentType.Button, time: 60000 });

            collector.on('collect', async interaction => {
                if (interaction.user.id !== message.author.id) {
                    return interaction.reply({ content: 'Bạn không có quyền để thực hiện hành động này.', ephemeral: true });
                }

                switch (interaction.customId) {
                    case 'avatar_original':
                        embed.setImage(avatarUrl).setTitle(`Avatar gốc của ${user.tag}`);
                        await interaction.update({ embeds: [embed] });
                        break;
                    case 'avatar_server':
                        embed.setImage(serverAvatarUrl).setTitle(`Avatar server của ${user.tag}`);
                        await interaction.update({ embeds: [embed] });
                        break;
                    case 'banner_original':
                        if (bannerUrl) {
                            embed.setImage(bannerUrl).setTitle(`Banner gốc của ${user.tag}`);
                            await interaction.update({ embeds: [embed] });
                        } else {
                            interaction.reply({ content: 'Người dùng này không có banner.', ephemeral: true });
                        }
                        break;
                    case 'banner_server':
                        if (bannerUrl) {
                            embed.setImage(bannerUrl).setTitle(`Banner server của ${user.tag}`);
                            await interaction.update({ embeds: [embed] });
                        } else {
                            interaction.reply({ content: 'Người dùng này không có banner.', ephemeral: true });
                        }
                        break;
                }
            });

            collector.on('end', () => {
                responseMessage.edit({ components: [] });
            });
        } catch (error) {
            console.error('Error fetching user details:', error);
            message.reply('Có lỗi xảy ra khi lấy thông tin người dùng.');
        }
    },
};
