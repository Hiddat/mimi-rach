const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'memberinfo',
    category: 'Info',
    cooldown: 3,
    description: 'Displays information about the user or a tagged user.',
    async execute(message, args) { 
        let member;

        if (args.length) {
            member = message.mentions.members.first() || await message.guild.members.fetch(args[0]).catch(() => null);
            if (!member) {
                return message.reply('User not found.');
            }
        } else {
            member = message.member;
        }

        const user = member.user;
        const roles = member.roles.cache
            .filter(role => role.name !== '@everyone')
            .map(role => role.toString())
            .join(', ');

        const embed = new EmbedBuilder()
            .setColor('#0099ff')
            .setTitle(`Member Information - ${user.tag}`)
            .setThumbnail(user.displayAvatarURL({ dynamic: true }))
            .addFields(
                { name: 'User ID', value: user.id, inline: true },
                { name: 'Joined Server', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`, inline: true },
                { name: 'Joined Discord', value: `<t:${Math.floor(user.createdTimestamp / 1000)}:R>`, inline: true },
                { name: 'Roles', value: roles || 'None', inline: false }
            )
            .setFooter({ text: `Requested by ${message.author.tag}` });

        message.channel.send({ embeds: [embed] });
    },
};
