const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    name: 'emoji',
    description: 'Phóng to một hoặc nhiều emoji',
    category: 'Info',
    cooldown: 3,
    async execute(message, args) {
        if (args.length === 0) {
            return message.reply('Vui lòng cung cấp ít nhất một emoji.');
        }

        const emojis = args;
        let pages = [];
        
        // Xử lý từng emoji
        emojis.forEach((emoji, index) => {
            const customEmoji = emoji.match(/<:.+:(\d+)>/) || emoji.match(/<a:.+:(\d+)>/);
            if (customEmoji) {
                const emojiId = customEmoji[1];
                const isGif = emoji.startsWith('<a:'); // Kiểm tra xem có phải là GIF hay không
                const emojiURL = `https://cdn.discordapp.com/emojis/${emojiId}.${isGif ? 'gif' : 'png'}?v=1`;
                
                const embed = new EmbedBuilder()
                    .setTitle('<:mimi:1258599282311827496> Phóng to Emoji! <:mimi:1258599282311827496>')
                    .setColor('#F5B7B1')
                    .setDescription(`**EMOJI:** \`${emoji}\` \`${emojiId}\``)
                    .setImage(emojiURL)
                    .setFooter({ text: `Page ${index + 1}/${emojis.length}` });

                pages.push(embed);
            }
        });

        if (pages.length === 0) {
            return message.reply('Không tìm thấy emoji hợp lệ.');
        }

        let currentPage = 0;

        // Chỉ hiển thị nút nếu có hơn 1 emoji
        let row;
        if (pages.length > 1) {
            row = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('prev')
                        .setLabel('◀️')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(currentPage === 0),
                    new ButtonBuilder()
                        .setCustomId('next')
                        .setLabel('▶️')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(currentPage === pages.length - 1),
                );
        }

        const embedMessage = await message.reply({ 
            embeds: [pages[currentPage]], 
            components: pages.length > 1 ? [row] : [] // Chỉ đính kèm hàng nút nếu có nhiều hơn 1 trang
        });

        if (pages.length > 1) {
            const filter = (interaction) => ['prev', 'next'].includes(interaction.customId) && interaction.user.id === message.author.id;

            const collector = embedMessage.createMessageComponentCollector({ filter, time: 60000 });

            collector.on('collect', async (interaction) => {
                if (interaction.customId === 'prev') {
                    currentPage = Math.max(currentPage - 1, 0);
                } else if (interaction.customId === 'next') {
                    currentPage = Math.min(currentPage + 1, pages.length - 1);
                }

                await interaction.update({
                    embeds: [pages[currentPage]],
                    components: [
                        new ActionRowBuilder()
                            .addComponents(
                                new ButtonBuilder()
                                    .setCustomId('prev')
                                    .setLabel('◀️')
                                    .setStyle(ButtonStyle.Primary)
                                    .setDisabled(currentPage === 0),
                                new ButtonBuilder()
                                    .setCustomId('next')
                                    .setLabel('▶️')
                                    .setStyle(ButtonStyle.Primary)
                                    .setDisabled(currentPage === pages.length - 1),
                            ),
                    ],
                });
            });

            collector.on('end', () => {
                embedMessage.edit({ components: [] });
            });
        }
    },
};
