const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const dbLove = require('../../db/databaseLove');
const { getUserMoney, checkLoveStatus, updateUserMoney, updateLoveData } = require('../../utils/loveUtils');
const gifts = require('../../data/gifts.json');

const formatMoney = (amount) => {
  if (amount >= 1000000) {
    return `${Math.floor(amount / 1000000)}m`;
  } else if (amount >= 1000) {
    return `${Math.floor(amount / 1000)}k`;
  }
  return amount.toString();
};

const ITEMS_PER_PAGE = 10;

module.exports = {
  name: 'cuahang',
  category: 'Cửa hàng',
    cooldown: 3,
  description: 'Xem danh sách quà tặng và mua quà cho người yêu',
  async execute(message, args) {
    const user = message.author;

    if (args.length > 0 && !isNaN(args[0])) {
      const itemIndex = parseInt(args[0]) - 1;
      return await handleBuy(message, itemIndex);
    }

    let currentPage = args.length > 0 && !isNaN(args[0]) ? parseInt(args[0]) - 1 : 0;
    const userMoney = await getUserMoney(user.id);
    const loveStatus = await checkLoveStatus(user.id);

    if (!loveStatus) {
      return message.channel.send('Bạn cần có người yêu để mua quà!');
    }

    const totalPages = Math.ceil(gifts.length / ITEMS_PER_PAGE);
    const start = currentPage * ITEMS_PER_PAGE;
    const end = start + ITEMS_PER_PAGE;
    const giftsPage = gifts.slice(start, end);

    const embed = createShopEmbed(user, userMoney, giftsPage, start, totalPages, currentPage);
    const components = createComponents(currentPage, totalPages);

    const sentMessage = await message.channel.send({ embeds: [embed], components });

    const filter = i => i.user.id === user.id;
    const collector = sentMessage.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async i => {
      if (i.customId === 'previous') {
        currentPage -= 1;
      } else if (i.customId === 'next') {
        currentPage += 1;
      }

      await updatePage(message, currentPage, sentMessage);
      await i.deferUpdate();
    });

    collector.on('end', () => {
      sentMessage.edit({ components: [] });
    });
  }
};

async function updatePage(message, page, sentMessage) {
  const user = message.author;
  const userMoney = await getUserMoney(user.id);
  const totalPages = Math.ceil(gifts.length / ITEMS_PER_PAGE);
  const start = page * ITEMS_PER_PAGE;
  const end = start + ITEMS_PER_PAGE;
  const giftsPage = gifts.slice(start, end);

  const embed = createShopEmbed(user, userMoney, giftsPage, start, totalPages, page);
  const components = createComponents(page, totalPages);

  await sentMessage.edit({ embeds: [embed], components });
}

function createShopEmbed(user, userMoney, giftsPage, start, totalPages, currentPage) {
  const embed = new EmbedBuilder()
    .setColor('#FFB6C1')
    .setTitle('<:xumimi:1261591338290511973> Cửa Hàng Quà Tặng <:xumimi:1261591338290511973>')
    .setDescription('Dưới đây là danh sách các món quà và giá của chúng:\nĐể mua quà, hãy sử dụng lệnh `cuahang <số thứ tự hàng>`')
    .setFooter({ text: `Số tiền hiện tại của bạn: ${formatMoney(userMoney)} xu Mimi` })
    .setTimestamp();

  giftsPage.forEach((gift, index) => {
    embed.addFields({ name: `${start + index + 1}. **${gift.name}**`, value: `${gift.emoji} - Giá: \`${formatMoney(gift.price)} xu\` - Điểm thân mật: \`+${gift.intimacy}\``, inline: false });
  });

  embed.addFields({ name: '\u200B', value: `Trang ${currentPage + 1}/${totalPages}`, inline: false });

  return embed;
}

function createComponents(currentPage, totalPages) {
  const navigationRow = new ActionRowBuilder()
    .addComponents(
      new ButtonBuilder()
        .setCustomId('previous')
        .setLabel('Trang trước')
        .setStyle(ButtonStyle.Primary)
        .setDisabled(currentPage === 0),
      new ButtonBuilder()
        .setCustomId('next')
        .setLabel('Trang sau')
        .setStyle(ButtonStyle.Primary)
        .setDisabled(currentPage === totalPages - 1)
    );

  return [navigationRow];
}

async function handleBuy(message, itemIndex) {
  try {
    const gift = gifts[itemIndex];
    if (!gift) {
      return message.channel.send('Món quà không tồn tại.');
    }

    const userMoney = await getUserMoney(message.author.id);

    if (userMoney < gift.price) {
      return message.channel.send('Bạn không đủ tiền để mua món quà này.');
    } else {
      await updateUserMoney(message.author.id, -gift.price);
      await updateLoveData(message.author.id, gift.intimacy);
      await addToInventory(message.author.id, gift);

      const embed = new EmbedBuilder()
        .setColor('#FFB6C1')
        .setTitle('Mua Quà Thành Công')
        .setDescription(`<@${message.author.id}> đã mua quà ${gift.emoji} thành công!`)
        .addFields(
          { name: 'Món quà', value: gift.name, inline: true },
          { name: 'Giá', value: `${formatMoney(gift.price)} <:xumimi:1261591338290511973>`, inline: true },
          { name: 'Điểm thân mật', value: `+${gift.intimacy}`, inline: true }
        )
        .setTimestamp();

      return message.channel.send({ embeds: [embed] });
    }
  } catch (error) {
    console.error('Lỗi khi xử lý yêu cầu mua quà:', error);
    return message.channel.send('Đã xảy ra lỗi khi xử lý yêu cầu của bạn. Vui lòng thử lại sau.');
  }
}

const addToInventory = (userId, gift) => new Promise((resolve, reject) => {
  dbLove.run("INSERT INTO user_inventory (user_id, item_name, emoji, quantity) VALUES (?, ?, ?, 1) ON CONFLICT(user_id, item_name) DO UPDATE SET quantity = quantity + 1", [userId, gift.name, gift.emoji], function(err) {
    if (err) return reject(err);
    resolve();
  });
});
