const math = require('mathjs');

module.exports = {
    name: 'math',
    category: 'Info',
    description: 'Thực hiện các phép toán cơ bản và nâng cao.',
    execute(message, args) {
        const expression = args.join(' ');

        try {
            // Đánh giá biểu thức toán học
            const result = math.evaluate(expression);

            message.channel.send(`Kết quả: ${result}`);
        } catch (error) {
            message.channel.send('Đã xảy ra lỗi khi tính toán biểu thức! Vui lòng đảm bảo biểu thức hợp lệ và thử lại.');
        }
    },
};
