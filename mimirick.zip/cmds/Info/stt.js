const { EmbedBuilder } = require('discord.js');
const { getQueue } = require('../../queueHandler.js'); // Đường dẫn đến file queueHandler.js

module.exports = {
    name: 'tt',
    description: 'Hiển thị thông tin về các server đang phát nhạc và danh sách chờ.',
      category: 'Owner Bot',
      cooldown: 3,
    execute(message) {
        // Kiểm tra nếu người dùng có ID là 1145030539074600970
        if (message.author.id !== '1145030539074600970') {
            return message.reply('Lệnh này chỉ dành cho Owner sử dụng.');
        }

        const guilds = message.client.guilds.cache; // Lấy tất cả các server mà bot đang tham gia
        let totalQueues = 0;
        let totalTracks = 0;

        guilds.forEach(guild => {
            const queue = getQueue(guild.id); // Lấy danh sách chờ của từng server
            if (queue.length > 0) {
                totalQueues++;
                totalTracks += queue.length;
            }
        });

        // Tạo Embed với màu hồng pastel
        const embed = new EmbedBuilder()
            .setColor(0xFFB6C1) // Màu hồng pastel
            .setTitle('Trạng thái phát nhạc của bot')
            .addFields(
                { name: 'Số server đang phát nhạc:', value: totalQueues.toString(), inline: true },
                { name: 'Tổng số bài hát trong danh sách chờ:', value: totalTracks.toString(), inline: true }
            )
            .setTimestamp()
            .setFooter({ text: 'Music Bot Status', iconURL: message.client.user.displayAvatarURL() });

        // Gửi Embed
        message.channel.send({ embeds: [embed] });
    }
};
