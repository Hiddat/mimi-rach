const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const fs = require('fs');
const path = require('path');

// Đường dẫn tới file config và file scammer list
const configPath = path.join(__dirname, '../../config.json');
const scammerListPath = path.join(__dirname, '../../dbjson/scammerList.json');

module.exports = {
    name: 'listscammer',
    description: 'Hiển thị danh sách scammer',
    category: 'Info',
    execute(message) {
        // Load config và danh sách admin
        const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
        const adminIds = config.adminIds || [];

        // Load danh sách scammer
        let scammerList = [];
        if (fs.existsSync(scammerListPath)) {
            scammerList = JSON.parse(fs.readFileSync(scammerListPath, 'utf-8'));
        }

        const itemsPerPage = 20;
        let currentPage = 0;


        const generateScammerListEmbed = (page) => {
            const start = page * itemsPerPage;
            const end = start + itemsPerPage;
            const paginatedScammers = scammerList.slice(start, end);

            let description = paginatedScammers.map((scammer, index) => 
                
                `${start + index + 1}. <@${scammer.id}> 
                (Lúc: <t:${Math.floor(new Date(scammer.timestamp).getTime() / 1000)}:R>) - Bởi: <@${scammer.addedBy}>`
            ).join('\n') || 'Chưa có scammer nào.';
            
            return new EmbedBuilder()
                .setColor(0xff0000) // Đỏ
                .setTitle('LIST SCAMMER')
                .setDescription(`Danh sách scammer hiện tại:\n${description}`)
                .setFooter({ text: `Trang ${page + 1}/${Math.ceil(scammerList.length / itemsPerPage)}` });
        };

        const generateActionRow = (page) => {
            return new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('previousPage')
                        .setLabel('Trang trước')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(page === 0),
                    new ButtonBuilder()
                        .setCustomId('nextPage')
                        .setLabel('Trang sau')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled((page + 1) * itemsPerPage >= scammerList.length),
                    new ButtonBuilder()
                        .setCustomId('addScammer')
                        .setLabel('Thêm scammer')
                        .setStyle(ButtonStyle.Success)
                        .setDisabled(!adminIds.includes(message.author.id)), // Chỉ admin mới có thể ấn
                    new ButtonBuilder()
                        .setCustomId('removeScammer')
                        .setLabel('Xoá scammer')
                        .setStyle(ButtonStyle.Danger)
                        .setDisabled(!adminIds.includes(message.author.id)) // Chỉ admin mới có thể ấn
                );
        };

        const embed = generateScammerListEmbed(currentPage);
        const row = generateActionRow(currentPage);

        message.channel.send({ embeds: [embed], components: [row] }).then((msg) => {
            if (!adminIds.includes(message.author.id)) return;

            const filter = (interaction) => adminIds.includes(interaction.user.id) || interaction.customId === 'previousPage' || interaction.customId === 'nextPage';
            const collector = msg.createMessageComponentCollector({ filter, componentType: ComponentType.Button, time: 60000 });

            collector.on('collect', async (interaction) => {
                if (interaction.customId === 'previousPage') {
                    currentPage = Math.max(currentPage - 1, 0);
                } else if (interaction.customId === 'nextPage') {
                    currentPage = Math.min(currentPage + 1, Math.ceil(scammerList.length / itemsPerPage) - 1);
                } else if (interaction.customId === 'addScammer') {
                    await interaction.reply({ content: 'Vui lòng tag hoặc nhập ID của người dùng (có thể nhập nhiều ID hoặc tag cách nhau bằng dấu cách) để thêm scammer.', ephemeral: true });

                    const filterMessage = (m) => adminIds.includes(m.author.id);
                    const collected = await message.channel.awaitMessages({ filter: filterMessage, max: 1, time: 30000, errors: ['time'] }).catch(() => null);

                    if (!collected) {
                        return interaction.followUp({ content: 'Hết thời gian thêm scammer.', ephemeral: true });
                    }

                    const input = collected.first().content.trim();
                    const scammerIds = collected.first().mentions.users.map(user => user.id).concat(input.split(/\s+/).filter(id => !isNaN(id)));

                    let addedScammers = [];
                    scammerIds.forEach(scammerId => {
                        if (!scammerList.find(scammer => scammer.id === scammerId)) {
                            scammerList.push({ 
                                id: scammerId, 
                                timestamp: new Date().toISOString(),
                                addedBy: interaction.user.id // Lưu ID người đã thêm scammer
                            });
                            addedScammers.push(scammerId);
                        }
                    });

                    if (addedScammers.length > 0) {
                        fs.writeFileSync(scammerListPath, JSON.stringify(scammerList, null, 2)); // Save updated list
                        currentPage = Math.floor((scammerList.length - 1) / itemsPerPage); // Chuyển đến trang cuối nếu thêm mới
                        const updatedEmbed = generateScammerListEmbed(currentPage);
                        const updatedRow = generateActionRow(currentPage);
                        await msg.edit({ embeds: [updatedEmbed], components: [updatedRow] });
                        interaction.followUp({ content: `Scammer đã được thêm thành công: ${addedScammers.map(id => `<@${id}>`).join(', ')}.`, ephemeral: true });
                    } else {
                        interaction.followUp({ content: 'Tất cả người dùng đã có trong danh sách scammer hoặc không hợp lệ.', ephemeral: true });
                    }
                } else if (interaction.customId === 'removeScammer') {
                    await interaction.reply({ content: 'Vui lòng nhập số thứ tự của scammer bạn muốn xoá.', ephemeral: true });

                    const filterMessage = (m) => adminIds.includes(m.author.id);
                    const collected = await message.channel.awaitMessages({ filter: filterMessage, max: 1, time: 30000, errors: ['time'] }).catch(() => null);

                    if (!collected) {
                        return interaction.followUp({ content: 'Hết thời gian xoá scammer.', ephemeral: true });
                    }

                    const index = parseInt(collected.first().content.trim()) - 1;

                    if (isNaN(index) || index < 0 || index >= scammerList.length) {
                        return interaction.followUp({ content: 'Số thứ tự không hợp lệ.', ephemeral: true });
                    }

                    // Remove the scammer
                    scammerList.splice(index, 1);
                    fs.writeFileSync(scammerListPath, JSON.stringify(scammerList, null, 2)); // Save updated list

                    currentPage = Math.min(currentPage, Math.ceil(scammerList.length / itemsPerPage) - 1); // Cập nhật lại trang nếu cần
                    const updatedEmbed = generateScammerListEmbed(currentPage);
                    const updatedRow = generateActionRow(currentPage);
                    await msg.edit({ embeds: [updatedEmbed], components: [updatedRow] });
                    interaction.followUp({ content: 'Scammer đã được xoá thành công.', ephemeral: true });
                }

                // Cập nhật hiển thị cho các nút chuyển trang
                if (interaction.customId === 'previousPage' || interaction.customId === 'nextPage') {
                    const updatedEmbed = generateScammerListEmbed(currentPage);
                    const updatedRow = generateActionRow(currentPage);
                    await msg.edit({ embeds: [updatedEmbed], components: [updatedRow] });
                    interaction.deferUpdate();
                }
            });

            collector.on('end', () => {
                msg.edit({ components: [] }); // Disable buttons after collector ends
            });
        });
    },
};


// const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
// const fs = require('fs');
// const path = require('path');

// // Đường dẫn tới file config và file scammer list
// const configPath = path.join(__dirname, '../../config.json');
// const scammerListPath = path.join(__dirname, '../../dbjson/scammerList.json');

// module.exports = {
//     name: 'listscammer',
//     description: 'Hiển thị danh sách scammer',
//     category: 'Info',
//     execute(message) {
//         // Load config và danh sách admin
//         const config = JSON.parse(fs.readFileSync(configPath, 'utf-8'));
//         const adminIds = config.adminIds || [];

//         // Load danh sách scammer
//         let scammerList = [];
//         if (fs.existsSync(scammerListPath)) {
//             scammerList = JSON.parse(fs.readFileSync(scammerListPath, 'utf-8'));
//         }

//         const generateScammerListEmbed = () => {
//             let description = scammerList.map((scammer, index) => 
//                 `${index + 1}. <@${scammer.id}> - ${scammer.id} 
//                 (Thời gian bị thêm: <t:${Math.floor(new Date(scammer.timestamp).getTime() / 1000)}:R>) 
//                 Thêm bởi: <@${scammer.addedBy}>`
//             ).join('\n') || 'Chưa có scammer nào.';
            
//             return new EmbedBuilder()
//                 .setColor(0xff0000) // Đỏ
//                 .setTitle('LIST SCAMMER')
//                 .setDescription(`Danh sách scammer hiện tại:\n${description}`);
//         };

//         const embed = generateScammerListEmbed();

//         const row = new ActionRowBuilder()
//             .addComponents(
//                 new ButtonBuilder()
//                     .setCustomId('addScammer')
//                     .setLabel('Thêm scammer')
//                     .setStyle(ButtonStyle.Success)
//                     .setDisabled(!adminIds.includes(message.author.id)), // Chỉ admin mới có thể ấn
//                 new ButtonBuilder()
//                     .setCustomId('removeScammer')
//                     .setLabel('Xoá scammer')
//                     .setStyle(ButtonStyle.Danger)
//                     .setDisabled(!adminIds.includes(message.author.id)) // Chỉ admin mới có thể ấn
//             );

//         message.channel.send({ embeds: [embed], components: [row] }).then((msg) => {
//             if (!adminIds.includes(message.author.id)) return;

//             const filter = (interaction) => adminIds.includes(interaction.user.id);
//             const collector = msg.createMessageComponentCollector({ filter, componentType: ComponentType.Button, time: 60000 });

//             collector.on('collect', async (interaction) => {
//                 if (interaction.customId === 'addScammer') {
//                     await interaction.reply({ content: 'Vui lòng tag hoặc nhập ID của người dùng để thêm scammer.', ephemeral: true });

//                     const filterMessage = (m) => adminIds.includes(m.author.id);
//                     const collected = await message.channel.awaitMessages({ filter: filterMessage, max: 1, time: 30000, errors: ['time'] }).catch(() => null);

//                     if (!collected) {
//                         return interaction.followUp({ content: 'Hết thời gian thêm scammer.', ephemeral: true });
//                     }

//                     const scammerToAdd = collected.first().mentions.users.first() || collected.first().content.trim();

//                     if (!scammerToAdd || scammerList.find(scammer => scammer.id === (scammerToAdd.id || scammerToAdd))) {
//                         return interaction.followUp({ content: 'Người này đã có trong danh sách scammer hoặc không hợp lệ.', ephemeral: true });
//                     }

//                     // Add the new scammer
//                     scammerList.push({ 
//                         id: scammerToAdd.id || scammerToAdd, 
//                         timestamp: new Date().toISOString(),
//                         addedBy: interaction.user.id // Lưu ID người đã thêm scammer
//                     });
//                     fs.writeFileSync(scammerListPath, JSON.stringify(scammerList, null, 2)); // Save updated list

//                     const updatedEmbed = generateScammerListEmbed();
//                     await msg.edit({ embeds: [updatedEmbed] });
//                     interaction.followUp({ content: 'Scammer đã được thêm thành công.', ephemeral: true });
//                 }

//                 if (interaction.customId === 'removeScammer') {
//                     await interaction.reply({ content: 'Vui lòng nhập số thứ tự của scammer bạn muốn xoá.', ephemeral: true });

//                     const filterMessage = (m) => adminIds.includes(m.author.id);
//                     const collected = await message.channel.awaitMessages({ filter: filterMessage, max: 1, time: 30000, errors: ['time'] }).catch(() => null);

//                     if (!collected) {
//                         return interaction.followUp({ content: 'Hết thời gian xoá scammer.', ephemeral: true });
//                     }

//                     const index = parseInt(collected.first().content.trim()) - 1;

//                     if (isNaN(index) || index < 0 || index >= scammerList.length) {
//                         return interaction.followUp({ content: 'Số thứ tự không hợp lệ.', ephemeral: true });
//                     }

//                     // Remove the scammer
//                     scammerList.splice(index, 1);
//                     fs.writeFileSync(scammerListPath, JSON.stringify(scammerList, null, 2)); // Save updated list

//                     const updatedEmbed = generateScammerListEmbed();
//                     await msg.edit({ embeds: [updatedEmbed] });
//                     interaction.followUp({ content: 'Scammer đã được xoá thành công.', ephemeral: true });
//                 }
//             });

//             collector.on('end', () => {
//                 msg.edit({ components: [] }); // Disable buttons after collector ends
//             });
//         });
//     },
// };
