const { EmbedBuilder } = require('discord.js');
const dbLove = require('../../db/databaseLove');

const rings = [
  { name: 'deeppink', emoji: '<:deeppink:1277960353774440490>', price: 100000, intimacy: 480 },
  { name: 'turquoise', emoji: '<:turquoise:1277960338779930624>', price: 150000, intimacy: 720 },
  { name: 'traitim', emoji: '<:traitim:1277960213785350207>', price: 150000, intimacy: 720 },
  { name: 'sliverpink', emoji: '<:sliverpink:1277960391892144268>', price: 250000, intimacy: 1200 },
  { name: 'pinksapphire', emoji: '<:pinksapphire:1277960240335163454>', price: 200000, intimacy: 960 },
  { name: 'zirconiacrystal', emoji: '<:zirconiacrystal:1277960401690169431>', price: 800000, intimacy: 3840 },
  { name: 'Tanzanite', emoji: '<:Tanzanite:1277960322384138290>', price: 500000, intimacy: 2400 },
  { name: 'unicornsliver', emoji: '<:unicornsliver:1277960226922041467>', price: 400000, intimacy: 1920 },
  { name: 'gold2', emoji: '<:gold2:1277960447026270218>', price: 220000, intimacy: 1056 },
  { name: 'basic', emoji: '<:nhan_basic:1259698833823240283>', price: 1000000, intimacy: 4800 },
  { name: 'silver', emoji: '<:nhan_bac:1259699699192172636>', price: 2000000, intimacy: 9600 },
  { name: 'turquoise_diamond', emoji: '<:turquoise_diamond:1277960456845262940>', price: 2500000, intimacy: 12000 },
  { name: 'pinkruby', emoji: '<:pinkruby:1277960265932996789>', price: 5000000, intimacy: 34000 },
  { name: 'gold', emoji: '<:nhan_vang:1259699697292017767>', price: 5000000, intimacy: 34000 },
  { name: 'pink_ruby', emoji: '<:nhan_hongngoc:1259699612034531388>', price: 5000000, intimacy: 34000 },
  { name: 'pinkdiamond', emoji: '<:pinkdiamond:1277960310065598576>', price: 7000000, intimacy: 53600 },
  { name: 'gemstone', emoji: '<:nhan_daquy:1259699627033104555>', price: 7500000, intimacy: 76000 },
  { name: 'midjourney', emoji: '<:midjourney:1277960366005026828>', price: 17000000, intimacy: 101600 },
  { name: 'ruby', emoji: '<:nhan_ruby:1259699702060810262>', price: 10000000, intimacy: 108000 },
  { name: 'sapphire', emoji: '<:nhan_sapphire:1259699706767085638>', price: 20000000, intimacy: 136000 },
  { name: 'emerald', emoji: '<:nhan_lucbao:1259699709380132886>', price: 25000000, intimacy: 160000 },
  { name: 'goldgemstone', emoji: '<:goldgemstone:1277960380861382707>', price: 23000000, intimacy: 210400 },
  { name: 'CrimsonSovereign', emoji: '<:CrimsonSovereign:1278694004548177920>', price: 30000000, intimacy: 350000 },
  { name: 'RoyalIceSapphire', emoji: '<:RoyalIceSapphire:1278693995576430675>', price: 30000000, intimacy: 350000 },
  { name: 'GoldenRadiance', emoji: '<:GoldenRadiance:1278693988152643604>', price: 30000000, intimacy: 350000 }
];

const formatMoney = (amount) => {
  if (amount >= 1000000) {
    return `${Math.floor(amount / 1000000)}m`;
  } else if (amount >= 1000) {
    return `${Math.floor(amount / 1000)}k`;
  }
  return amount.toString();
};

module.exports = {
  name: 'shop',
  category: 'Cửa hàng',
  cooldown: 3,
  description: 'Xem danh sách và mua nhẫn cho người yêu',
  async execute(message, args) {
    const user = message.author;

    const getUserMoney = (userId) => new Promise((resolve, reject) => {
      dbLove.get("SELECT money FROM user_money WHERE user_id = ?", [userId], (err, row) => {
        if (err) return reject(err);
        resolve(row ? row.money : 0);
      });
    });

    const checkLoveStatus = (userId) => new Promise((resolve, reject) => {
      dbLove.get("SELECT * FROM love_data WHERE (user1_id = ? OR user2_id = ?) AND success_time IS NOT NULL ORDER BY success_time DESC LIMIT 1", [userId, userId], (err, row) => {
        if (err) return reject(err);
        resolve(row);
      });
    });

    const userMoney = await getUserMoney(user.id);
    const loveStatus = await checkLoveStatus(user.id);

    if (!loveStatus) {
      return message.channel.send('Bạn cần có người yêu để mua nhẫn!');
    }


      let formattedMoney = Math.floor(userMoney).toLocaleString('en-US');

    if (args.length === 0) {
      let description = 'Hãy nhớ mua xong nhẫn sẽ thay thế nhẫn cũ và nhẫn cũ sẽ bị tiêu hủy ngay lập tức!:\n\n';
      
      rings.forEach((ring, index) => {
        description += `${index + 1}. ${ring.emoji} - Giá: \`${formatMoney(ring.price)} xu\` - Điểm thân mật: \`+${formatMoney(ring.intimacy)}\`\n`;
      });

      description += '\nCách Mua Hàng: Sử dụng lệnh: shop <số thứ tự>\nVí dụ: shop 1';

      const embed = new EmbedBuilder()
        .setColor('#FFB6C1')
        .setTitle('Cửa Hàng Nhẫn')
        .setDescription(description)
        .setFooter({ text: `Số tiền hiện tại của bạn: ${formattedMoney} Xu Mimi` })
        .setTimestamp();

      return message.channel.send({ embeds: [embed] });
    }

    const ringIndex = parseInt(args[0]) - 1;

    if (isNaN(ringIndex) || ringIndex < 0 || ringIndex >= rings.length) {
      return message.channel.send('Số thứ tự không hợp lệ. Sử dụng !shop để xem danh sách các loại nhẫn có sẵn.');
    }

    const ring = rings[ringIndex];

    if (userMoney < ring.price) {
      return message.channel.send('Bạn không đủ tiền để mua nhẫn này.');
    }

    const updateUserMoney = (userId, amount) => new Promise((resolve, reject) => {
      dbLove.run("UPDATE user_money SET money = money + ? WHERE user_id = ?", [amount, userId], function(err) {
        if (err) return reject(err);
        resolve();
      });
    });

    const updateLoveData = (userId, ringType, intimacy) => new Promise((resolve, reject) => {
      dbLove.run("UPDATE love_data SET ring_type = ?, intimacy_level = intimacy_level + ? WHERE user1_id = ? OR user2_id = ?", [ringType, intimacy, userId, userId], function(err) {
        if (err) return reject(err);
        resolve();
      });
    });

    await updateUserMoney(user.id, -ring.price);
    await updateLoveData(user.id, ring.name, ring.intimacy);

    const embed = new EmbedBuilder()
      .setColor('#FFB6C1')
      .setTitle('Mua Nhẫn Thành Công')
      .setDescription(`<@${user.id}> đã mua nhẫn ${ring.emoji} thành công!`)
      .addFields(
        { name: 'Loại nhẫn', value: ring.name, inline: true },
        { name: 'Giá', value: `${formatMoney(ring.price)} <:xumimi:1261591338290511973>`, inline: true },
        { name: 'Điểm thân mật', value: `+${formatMoney(ring.intimacy)}`, inline: true }
      )
      .setTimestamp();

    message.channel.send({ embeds: [embed] });
  }
};
