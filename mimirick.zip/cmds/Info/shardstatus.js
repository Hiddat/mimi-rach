

const { EmbedBuilder } = require('discord.js');

const AsciiTable = require('ascii-table');

module.exports = {
    name: 'shardstatus',
    category: 'Info',
    aliases: ['ss','shard'],
    cooldown: 3,
    description: 'Hiển thị tình trạng các shard',
    async execute(message) {
        const shardInfo = await message.client.shard.broadcastEval(client => ({
            id: client.shard.ids[0],
            serverCount: client.guilds.cache.size,
            memberCount: client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0),
            uptime: client.uptime,
            ping: client.ws.ping,
            ramUsage: (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2),
        }));

        const totalServerCount = shardInfo.reduce((acc, shard) => acc + shard.serverCount, 0);
        const totalMemberCount = shardInfo.reduce((acc, shard) => acc + shard.memberCount, 0);
        const totalRamUsage = shardInfo.reduce((acc, shard) => acc + parseFloat(shard.ramUsage), 0).toFixed(2);

        const table = new AsciiTable('Mimi Shards');
        table
            .setHeading('SID', 'Server', 'Members', 'Uptime', 'Ping', 'Ram')
            .setBorder('|', '-', ' ', ' ');

        shardInfo.forEach(shard => {
            table.addRow(
                shard.id, 
                shard.serverCount.toLocaleString(), 
                shard.memberCount.toLocaleString(), 
                `${Math.floor(shard.uptime / 86400000)}d ${new Date(shard.uptime).toISOString().substr(11, 8)}`,
                `~${shard.ping}ms`,
                `${shard.ramUsage} MB`
            );
        });

        table.addRow(
            'TOTAL',
            totalServerCount.toLocaleString(),
            totalMemberCount.toLocaleString(),
            'null',
            'null',
            `${totalRamUsage} MB`
        );

        message.reply(`\`\`\`${table.toString()}\`\`\``);
    },
};