const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const dbLove = require('../../db/databaseLove');

const itemsPerPage = 15;
let currentPage = 0;

module.exports = {
  name: 'shoplove',
  description: 'Hiển thị cửa hàng với các mặt hàng dành cho phụ nữ mang thai và trẻ em.',
  category: 'Cửa hàng',
  cooldown: 3,
  async execute(message) {
    const user = message.author;

    const checkLoveStatus = (userId) => new Promise((resolve, reject) => {
      dbLove.get("SELECT * FROM love_data WHERE (user1_id = ? OR user2_id = ?) AND success_time IS NOT NULL ORDER BY success_time DESC LIMIT 1", [userId, userId], (err, row) => {
        if (err) return reject(err);
        resolve(row);
      });
    });

    const checkPregnancyStatus = (userId) => new Promise((resolve, reject) => {
      dbLove.get("SELECT pregnancy_start, pregnancy_health FROM love_data WHERE (user1_id = ? OR user2_id = ?) AND success_time IS NOT NULL AND pregnancy_start IS NOT NULL ORDER BY success_time DESC LIMIT 1", [userId, userId], (err, row) => {
        if (err) return reject(err);
        resolve(row);
      });
    });

    const getUserMoney = (userId) => new Promise((resolve, reject) => {
      dbLove.get("SELECT money FROM user_money WHERE user_id = ?", [userId], (err, row) => {
        if (err) return reject(err);
        resolve(row ? row.money : 0);
      });
    });

    const updateUserMoney = (userId, amount) => new Promise((resolve, reject) => {
      dbLove.run("UPDATE user_money SET money = money + ? WHERE user_id = ?", [amount, userId], (err) => {
        if (err) return reject(err);
        resolve();
      });
    });

    const loveStatus = await checkLoveStatus(user.id);
    if (!loveStatus) {
      return message.channel.send('Bạn cần có người yêu để mua hàng!');
    }

    const pregnancyStatus = await checkPregnancyStatus(user.id);
    if (!pregnancyStatus) {
      return message.channel.send('Bạn cần mang thai để mua hàng!');
    }

    const partnerId = loveStatus.user1_id === user.id ? loveStatus.user2_id : loveStatus.user1_id;

    const shopPath = path.join(__dirname, '../../shop.json');
    const shopData = JSON.parse(fs.readFileSync(shopPath));

    const totalPages = Math.ceil(shopData.items.length / itemsPerPage);

    const generateEmbed = (page) => {
      const embed = new EmbedBuilder()
        .setColor('#FFB6C1')
        .setTitle('Cửa hàng')
        .setDescription('Danh sách các mặt hàng dành cho phụ nữ mang thai và trẻ em.')
        .setTimestamp()
        .setFooter({ text: `Trang ${page + 1} / ${totalPages}` });

      const start = page * itemsPerPage;
      const end = start + itemsPerPage;
      const items = shopData.items.slice(start, end);

      items.forEach(item => {
        embed.addFields({ name: `${item.emoji} ${item.name}`, value: `${item.description}\nGiá: ${item.price} <:xumimi:1261591338290511973>`, inline: true });
      });

      return embed;
    };

    const generateButtons = () => {
      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('previous_page')
            .setLabel('Trang trước')
            .setStyle(ButtonStyle.Primary)
            .setDisabled(currentPage === 0),
          new ButtonBuilder()
            .setCustomId('next_page')
            .setLabel('Trang sau')
            .setStyle(ButtonStyle.Primary)
            .setDisabled(currentPage === totalPages - 1),
          new ButtonBuilder()
            .setCustomId('purchase')
            .setLabel('Mua hàng')
            .setStyle(ButtonStyle.Success)
        );

      return row;
    };

    const messageEmbed = await message.channel.send({ embeds: [generateEmbed(currentPage)], components: [generateButtons()] });

    const filter = i => ['previous_page', 'next_page', 'purchase'].includes(i.customId) && i.user.id === message.author.id;
    const collector = messageEmbed.createMessageComponentCollector({ filter, time: 60000 });

    collector.on('collect', async i => {
      if (i.customId === 'previous_page') {
        currentPage--;
      } else if (i.customId === 'next_page') {
        currentPage++;
      } else if (i.customId === 'purchase') {
        const selectMenu = new StringSelectMenuBuilder()
          .setCustomId('select_item')
          .setPlaceholder('Chọn mặt hàng')
          .addOptions(
            shopData.items.map(item => ({
              label: item.name,
              description: `${item.description} - ${item.price} <:xumimi:1261591338290511973>`,
              value: item.id
            }))
          );

        const row = new ActionRowBuilder().addComponents(selectMenu);
        await i.reply({ content: 'Chọn mặt hàng bạn muốn mua:', components: [row], ephemeral: true });
        return;
      }

      await i.update({ embeds: [generateEmbed(currentPage)], components: [generateButtons()] });
    });

    const selectFilter = i => i.customId === 'select_item' && i.user.id === message.author.id;
    const selectCollector = message.channel.createMessageComponentCollector({ filter: selectFilter, time: 60000 });

    selectCollector.on('collect', async i => {
      const selectedItem = shopData.items.find(item => item.id === i.values[0]);
      const userMoney = await getUserMoney(user.id);

      if (userMoney < selectedItem.price) {
        await i.update({ content: `Bạn không đủ tiền để mua ${selectedItem.name}.`, components: [] });
        return;
      }

      await updateUserMoney(user.id, -selectedItem.price);
      await updateUserMoney(partnerId, -selectedItem.price);

      // Logic để lưu mặt hàng vào kho đồ của cặp đôi
      dbLove.run(`INSERT INTO user_inventorys (user_id, item_name, emoji, quantity) VALUES (?, ?, ?, 1)
      ON CONFLICT(user_id, item_name) DO UPDATE SET quantity = quantity + 1`, 
      [message.author.id, selectedItem.name, selectedItem.emoji], function(err) {
        if (err) {
          console.error(err);
          return;
        }
      });

      await i.update({ content: `Bạn đã mua ${selectedItem.name} với giá ${selectedItem.price} <:xumimi:1261591338290511973>.`, components: [] });
    });
    collector.on('end', () => {
            messageEmbed.edit({ components: [] });
        });
  }
};
