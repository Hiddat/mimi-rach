const { EmbedBuilder } = require('discord.js');
const dbLove = require('../../db/databaseLove');

module.exports = {
  name: 'inventory',
  aliases: ['inv'],
  description: 'Hiển thị kho đồ của cặp đôi',
  category: 'Tình yêu là gì?',
  cooldown: 3,
  async execute(message) {
    const getInventory = (userId) => new Promise((resolve, reject) => {
      dbLove.all("SELECT * FROM user_inventorys WHERE user_id = ?", [userId], (err, rows) => {
        if (err) return reject(err);
        resolve(rows);
      });
    });

    const inventory = await getInventory(message.author.id);

    if (!inventory.length) {
      return message.channel.send('Kho đồ của bạn hiện tại trống.');
    }

    const embed = new EmbedBuilder()
      .setColor('#FFB6C1')
      .setTitle('Kho đồ của bạn')
      .setTimestamp();

    let inventoryDescription = '';
    inventory.forEach((item, index) => {
      inventoryDescription += `${item.item_name} ${item.emoji} ${item.quantity}`;
      if ((index + 1) % 3 === 0) {
        inventoryDescription += '\n';
      } else {
        inventoryDescription += ' | ';
      }
    });

    embed.setDescription(inventoryDescription);

    message.channel.send({ embeds: [embed] });
  }
};
