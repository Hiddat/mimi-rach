const { EmbedBuilder } = require('discord.js');

module.exports = {
  name: 'invite',
  description: 'Hiển thị các liên kết mời bot vào server Discord',
    category: 'Info',
    aliases: ['moibot', 'moi'],
    cooldown: 5,

  execute(message) {
    // Tạo embed
    const embed = new EmbedBuilder()
      .setTitle('Mời List Bot Music vào Server')
      .setColor('#FFB6C1') // Màu của thanh bên trái của embed
      .setThumbnail(message.client.user.displayAvatarURL())
      .addFields(
        { name: 'List Bot Aiko', 
          value: `
        **0. <@1271101244089434254>:** [Invite Here](<https://discord.com/oauth2/authorize?client_id=1271101244089434254&permissions=0&integration_type=0&scope=bot>)
        **1. <@1273256051780747367>:** [Invite Here](<https://discord.com/oauth2/authorize?client_id=1273256051780747367&permissions=0&integration_type=0&scope=bot>)
        **2. <@1273256124858105941>:** [Invite Here](<https://discord.com/oauth2/authorize?client_id=1273256124858105941&permissions=0&integration_type=0&scope=bot>)
        **3. <@1273256158026666106>:** [Invite Here](<https://discord.com/oauth2/authorize?client_id=1273256158026666106&permissions=0&integration_type=0&scope=bot>)`, 
          inline: true },
        { name: 'List Bot Mimi',
          value: `
        **0. <@1207923287519268875>:** [Invite Here](<https://discord.com/oauth2/authorize?client_id=1207923287519268875&permissions=0&integration_type=0&scope=bot>)
        **1. <@1244953067988979722>:** [Invite Here](<https://discord.com/oauth2/authorize?client_id=1244953067988979722&permissions=0&integration_type=0&scope=bot>)
        **2. <@1245342437874864238>:** [Invite Here](<https://discord.com/oauth2/authorize?client_id=1245342437874864238&permissions=0&integration_type=0&scope=bot>)
        **3. <@1207851471434031144>:** [Invite Here](<https://discord.com/oauth2/authorize?client_id=1207851471434031144&permissions=0&integration_type=0&scope=bot>)`, 
          inline: true },
      )
      .setFooter({ text: `Mimi Bot - ${message.guild.name}` })
      .setTimestamp();

    // Gửi tin nhắn
    message.channel.send({ embeds: [embed] });
  },
};
