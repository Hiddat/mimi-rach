const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const fs = require('fs');

const botListFilePath = './data/botList.json';

module.exports = {
    name: 'musicbot',
    category: 'Info',
    description: 'Quản lý và kiểm tra trạng thái các bot âm nhạc trong server',
    cooldown: 3,
    async execute(message) {
        const serverId = message.guild.id;

        // Đọc danh sách bot từ file JSON
        let botList = {};
        if (fs.existsSync(botListFilePath)) {
            botList = JSON.parse(fs.readFileSync(botListFilePath, 'utf-8'));
        }

        // Nếu chưa có danh sách cho server này, khởi tạo danh sách rỗng
        if (!botList[serverId]) {
            botList[serverId] = [];
        }

        const busyBots = [];
        const availableBots = [];

        // Phân loại bot dựa trên trạng thái hiện tại
        botList[serverId].forEach(botId => {
            const botMember = message.guild.members.cache.get(botId);
            if (botMember && botMember.voice.channel) {
                busyBots.push(`${busyBots.length + 1}. <@${botId}>`);
            } else {
                availableBots.push(`${availableBots.length + 1}. <@${botId}>`);
            }
        });

        const embed = new EmbedBuilder()
            .setColor(0xffc0cb) // Màu hồng pastel
            .setTitle('Trạng thái các bot âm nhạc')
            .addFields(
                { name: 'Bot đang bận', value: busyBots.length > 0 ? busyBots.join('\n') : 'Không có bot nào bận.', inline: true },
                { name: 'Bot đang rảnh', value: availableBots.length > 0 ? availableBots.join('\n') : 'Không có bot nào rảnh.', inline: true }
            );

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('addBot')
                    .setLabel('Thêm bot')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId('removeBot')
                    .setLabel('Xóa bot')
                    .setStyle(ButtonStyle.Danger)
            );

        const replyMessage = await message.channel.send({ embeds: [embed], components: [row] });

        // Bộ lọc tương tác cho các nút
        const filter = (interaction) => interaction.user.id === message.author.id;

        // Tạo bộ thu thập tương tác với thời gian chờ 60 giây
        const collector = replyMessage.createMessageComponentCollector({ filter, componentType: ComponentType.Button, time: 60000 });

        collector.on('collect', async interaction => {
            if (interaction.customId === 'addBot') {
                if (botList[serverId].length >= 20) {
                    return interaction.reply({ content: 'Server này đã thêm đủ 20 bot.', ephemeral: true });
                }

                await interaction.reply({ content: 'Vui lòng tag hoặc nhập ID của các bot muốn thêm.', ephemeral: true });

                const filterMessage = (m) => m.author.id === message.author.id;
                const collected = await message.channel.awaitMessages({ filter: filterMessage, max: 1, time: 30000 });

                const mentionedBots = collected.first().mentions.users;

                if (mentionedBots.size === 0) {
                    return interaction.followUp({ content: 'Không có bot nào được tag.', ephemeral: true });
                }

                let addedBots = [];
                mentionedBots.forEach(bot => {
                    if (botList[serverId].length < 20 && !botList[serverId].includes(bot.id)) {
                        botList[serverId].push(bot.id);
                        addedBots.push(bot);
                    }
                });

                // Lưu lại danh sách sau khi thêm bot mới
                saveBotList(botList);

                if (addedBots.length > 0) {
                    interaction.followUp({ content: `Bot đã được thêm thành công: ${addedBots.map(b => `<@${b.id}>`).join(', ')}`, ephemeral: true });
                    await refreshEmbed(replyMessage, message.guild, botList[serverId]);
                } else {
                    interaction.followUp({ content: 'Không có bot nào được thêm. Hãy chắc chắn rằng bot chưa tồn tại và không vượt quá giới hạn 20 bot.', ephemeral: true });
                }
            }

            if (interaction.customId === 'removeBot') {
                await interaction.reply({ content: 'Vui lòng tag hoặc nhập ID của bot muốn xóa.', ephemeral: true });

                const filterMessage = (m) => m.author.id === message.author.id;
                const collected = await message.channel.awaitMessages({ filter: filterMessage, max: 1, time: 30000 });

                const botToRemove = collected.first().mentions.users.first() || collected.first().content.trim();

                // Kiểm tra nếu bot được tag hoặc nhập ID hợp lệ
                const botId = botToRemove.id ? botToRemove.id : botToRemove;

                if (!botList[serverId].includes(botId)) {
                    return interaction.followUp({ content: 'Bot này không có trong danh sách.', ephemeral: true });
                }

                botList[serverId] = botList[serverId].filter(id => id !== botId);
                saveBotList(botList); // Lưu lại danh sách sau khi xóa bot

                interaction.followUp({ content: `Bot <@${botId}> đã được xóa thành công!`, ephemeral: true });
                await refreshEmbed(replyMessage, message.guild, botList[serverId]);
            }
        });

        collector.on('end', collected => {
            if (collected.size === 0) {
                replyMessage.edit({ content: 'Hết thời gian tương tác.', components: [] });
            }
        });
    }
};

// Hàm cập nhật lại embed sau khi thêm/xóa bot và kiểm tra trạng thái bot theo thời gian thực
async function refreshEmbed(replyMessage, guild, botList) {
    const busyBots = [];
    const availableBots = [];

    // Phân loại bot dựa trên trạng thái hiện tại
    botList.forEach(botId => {
        const botMember = guild.members.cache.get(botId);
        if (botMember && botMember.voice.channel) {
            busyBots.push(`${busyBots.length + 1}. <@${botId}>`);
        } else {
            availableBots.push(`${availableBots.length + 1}. <@${botId}>`);
        }
    });

    const embed = new EmbedBuilder()
        .setColor(0xffc0cb) // Màu hồng pastel
        .setTitle('Trạng thái các bot âm nhạc')
        .addFields(
            { name: 'Bot đang bận', value: busyBots.length > 0 ? busyBots.join('\n') : 'Không có bot nào bận.', inline: true },
            { name: 'Bot đang rảnh', value: availableBots.length > 0 ? availableBots.join('\n') : 'Không có bot nào rảnh.', inline: true }
        );

    await replyMessage.edit({ embeds: [embed] });
}

// Hàm lưu danh sách bot vào file JSON
function saveBotList(botList) {
    fs.writeFileSync(botListFilePath, JSON.stringify(botList, null, 2));
}
