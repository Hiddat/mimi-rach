const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const config = require('../../config.json');

module.exports = {
    name: 'servers',
    description: 'Displays the list of servers the bot is in',
    aliases: ['svl', 'lsv', 'sv'],
    category: 'Info',
    cooldown: 3,
    execute(message, args) {
        const serversPerPage = 5;
        let currentPage = 0;
        const minMembers = parseInt(args[0]) || 0; // Đặt giá trị mặc định là 0 nếu không có tham số

        const generateEmbed = (page) => {
            const start = page * serversPerPage;
            const end = start + serversPerPage;

            // Lọc các server dựa trên số lượng thành viên
            const guildsArray = Array.from(message.client.guilds.cache.values())
                .filter(guild => guild.memberCount >= minMembers);

            const servers = guildsArray.slice(start, end);

            const totalMembers = guildsArray.reduce((acc, guild) => acc + guild.memberCount, 0);

            let description = ' ';
            servers.forEach((guild, index) => {
                description += `${index + 1 + start}: ${guild.name} - ${guild.id} - ${guild.memberCount}\n`;
            });

            const embed = new EmbedBuilder()
                .setTitle(`Tổng ${guildsArray.length} servers, tổng: ${totalMembers} member`)
                .setColor(0x00AE86)
                .setDescription(description)
                .setFooter({ text: `Page ${page + 1}/${Math.ceil(guildsArray.length / serversPerPage)}` });

            return embed;
        };

        const generateRow = () => {
            return new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('previous')
                        .setLabel('Previous')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(currentPage === 0),
                    new ButtonBuilder()
                        .setCustomId('next')
                        .setLabel('Next')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(currentPage === Math.ceil(message.client.guilds.cache.filter(guild => guild.memberCount >= minMembers).size / serversPerPage) - 1)
                );
        };

        const filteredGuilds = message.client.guilds.cache.filter(guild => guild.memberCount >= minMembers);

        if (filteredGuilds.size === 0) {
            return message.channel.send(`Không tìm thấy server nào có hơn ${minMembers} thành viên.`);
        }

        message.channel.send({ embeds: [generateEmbed(currentPage)], components: [generateRow()] }).then(embedMessage => {
            const filter = i => i.customId === 'previous' || i.customId === 'next';
            const collector = embedMessage.createMessageComponentCollector({ filter, time: 300000 });

            collector.on('collect', async i => {
                if (i.customId === 'previous' && currentPage > 0) {
                    currentPage--;
                } else if (i.customId === 'next' && currentPage < Math.ceil(filteredGuilds.size / serversPerPage) - 1) {
                    currentPage++;
                }
                await i.update({ embeds: [generateEmbed(currentPage)], components: [generateRow()] });
            });
        });
    },
};
