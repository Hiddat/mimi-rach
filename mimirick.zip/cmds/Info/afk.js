const { EmbedBuilder } = require('discord.js');
const dataBetaDev = require('../../db/databaseBetaDev');

module.exports = {
    name: 'afk',
    description: 'Đặt trạng thái AFK với lý do hoặc không có lý do.',
    category: 'Info',
    aliases: [],
    cooldown: 3,
    async execute(message, args) { 
        const reason = args.join(' ') || 'Không có lý do';
        dataBetaDev.run(`INSERT OR REPLACE INTO afk_users (user_id, reason, timestamp) VALUES (?, ?, ?)`, [
            message.author.id,
            reason,
            Date.now()
        ], (err) => {
            if (err) {
                console.error(err);
                return message.reply('Có lỗi xảy ra khi lưu trạng thái AFK.');
            }
            message.reply(`<a:7420bearloveuwu1:1261961349836177448> Bạn AFK với: \`${reason}\``);
        });
    },
};
