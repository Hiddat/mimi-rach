const fs = require('fs');
const path = require('path');
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, StringSelectMenuBuilder, PermissionsBitField } = require('discord.js');
const dataBetaDev = require('../../db/databaseBetaDev'); // Kết nối cơ sở dữ liệu SQLite
const { prefix: defaultPrefix } = require('../../config.json');

// Tạo bảng command_status nếu chưa tồn tại
dataBetaDev.run(`
    CREATE TABLE IF NOT EXISTS command_status (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        channel_id TEXT NOT NULL,
        disabled_commands TEXT DEFAULT '[]',
        disabled_categories TEXT DEFAULT '[]',
        UNIQUE(guild_id, channel_id)
    )
`);

module.exports = {
    name: 'help',
    cooldown: 3,
    description: 'Hiển thị danh sách lệnh theo từng category.',
    category: 'Info',
    async execute(message, args) {
        const channel = message.channel;

        // Kiểm tra quyền Manage Server của người dùng
        const isManager = message.member.permissions.has(PermissionsBitField.Flags.ManageGuild);
        
        dataBetaDev.get(`SELECT prefix FROM prefixes WHERE guild_id = ?`, [message.guild.id], async (err, row) => {
            let prefix = err ? defaultPrefix : (row ? row.prefix : defaultPrefix);

            const cmdsDir = path.join(__dirname, '../../cmds');
            const categories = {};

            function getAllCommandFiles(dir) {
                let commandFiles = [];
                const files = fs.readdirSync(dir);

                for (const file of files) {
                    const filePath = path.join(dir, file);
                    const stats = fs.statSync(filePath);

                    if (stats.isDirectory()) {
                        commandFiles = commandFiles.concat(getAllCommandFiles(filePath));
                    } else if (file.endsWith('.js')) {
                        commandFiles.push(filePath);
                    }
                }

                return commandFiles;
            }

            const commandFiles = getAllCommandFiles(cmdsDir);

            for (const filePath of commandFiles) {
                const command = require(filePath);
                const category = command.category || 'Nhóm lệnh lỗi';
                if (!categories[category]) {
                    categories[category] = [];
                }
                categories[category].push(command);
            }

            // Kiểm tra và gạch ngang các lệnh hoặc category bị disable
            const disabledCommands = await getDisabledCommands(message.guild.id, channel.id);

            // const embed = new EmbedBuilder()
            //     .setColor('#FF69B4')
            //     .setTitle(`Prefix: ${prefix}`)
            //     .setTimestamp();

            // // Thêm các lệnh và category vào embed, kiểm tra xem có bị disable không
            // for (const [category, commands] of Object.entries(categories)) {
            //     const commandNames = commands.map(cmd => {
            //         const isDisabled = disabledCommands.commands.includes(cmd.name) || disabledCommands.categories.includes(category);
            //         return isDisabled ? `~~\`${cmd.name}\`~~` : `\`${cmd.name}\``;
            //     }).join(' ');
            //     embed.addFields({ name: `<a:tick:1254376731356430361> ${category}`, value: commandNames || 'Không có lệnh nào' });
            // }
            const tagUser = message.author.id;
            const embed = new EmbedBuilder()
            .setColor('#FF69B4')
            .setTitle(`LIST COMMANDS - Prefix: ${prefix}`)
            .setDescription(`Xin chào <@${tagUser}>, tôi là <@1207923287519268875>.\nBot đa dạng lệnh được phát triển nhằm vào mục đích giải trí.\n\nAdmin Bot Mimi có mở cả server **Minecraft** và server **Ngọc Rồng online** để mọi người thỏa sức chơi nha. Join Server Bot ở nút bên dưới!\n\nCác lệnh help liên quan`)
            .addFields(
                { name: '⚙️ Moderation', value: '\u200B', inline: true },
                { name: '💸 Tiền tệ', value: '\u200B', inline: true },
                { name: '🎮 Trò chơi', value: '\u200B', inline: true },
                { name: '📦 Hành trang', value: '\u200B', inline: true },
                { name: '🛒 Cửa hàng', value: '\u200B', inline: true },
                { name: '🎶 Music', value: '\u200B', inline: true },
                { name: '💍 Tình yêu', value: '\u200B', inline: true },
                { name: '🎉 Giveaway', value: '\u200B', inline: true },
                { name: '\u200B', value: '\u200B', inline: false },
                { name: '💯 Server Minecraft', value: 'Tham Gia server chơi game ở server bot', inline: true },
                { name: '💯 Server Ngọc Rồng Online', value: 'Tham Gia server chơi game ở server bot', inline: true }
            )
            .setTimestamp();


            // Hiển thị các nút disable và enable chỉ cho người dùng có quyền Manager
            const actionRow = new ActionRowBuilder();
            if (isManager) {
                actionRow.addComponents(
                    new ButtonBuilder()
                        .setCustomId('disable_command')
                        .setLabel('Tắt lệnh')
                        .setEmoji('🔒')
                        .setStyle(ButtonStyle.Danger),
                    new ButtonBuilder()
                        .setCustomId('enable_command')
                        .setLabel('Bật lệnh')
                        .setEmoji('🔓')
                        .setStyle(ButtonStyle.Success)
                );
            }

            const rows = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setLabel('Support')
                        .setStyle(ButtonStyle.Link)
                        .setURL('https://discord.gg/mimibot')
                        .setEmoji('<:mimi:1258599282311827496>'),
                    new ButtonBuilder()
                        .setLabel('Invite Me')
                        .setStyle(ButtonStyle.Link)
                        .setURL('https://discord.com/oauth2/authorize?client_id=1207923287519268875&permissions=0&integration_type=0&scope=bot')
                        .setEmoji('<a:THUTINH:1255341478855573597>'),
                    new ButtonBuilder()
                        .setLabel('Vote Me !')
                        .setStyle(ButtonStyle.Link)
                        .setURL('https://top.gg/bot/1207923287519268875/vote')
                        .setEmoji('<a:2006pinkflame:1261960949951365212>')
                );
                // Tạo menu select category theo số thứ tự
            const selectMenu = new StringSelectMenuBuilder()
                .setCustomId('select_category')
                .setPlaceholder('Xem chi tiết các lệnh theo Category')
                .addOptions(Object.keys(categories).map((cat, index) => ({
                    label: `${index + 1}: ${cat}`,
                    description: `Xem các lệnh của ${cat}`,
                    value: `${index + 1}`, // Gán giá trị là số thứ tự
                })));

            const selectActionRow = new ActionRowBuilder()
                .addComponents(selectMenu);


            const components = [];

            if (isManager) {
                components.push(actionRow); // Chỉ thêm nếu là Manager
            }

            
            components.push(selectActionRow); // Thêm menu select
            components.push(rows);

            const sentMessage = await channel.send({ embeds: [embed], components: components });
            const selectCategoryFilter = interaction => interaction.isSelectMenu() && interaction.customId === 'select_category' && interaction.user.id === message.author.id;

const categoryCollector = sentMessage.createMessageComponentCollector({ filter: selectCategoryFilter, time: 86400000 });

categoryCollector.on('collect', async interaction => {
    try {
        const selectedIndex = parseInt(interaction.values[0], 10) - 1; // Lấy chỉ số category từ giá trị menu
        const selectedCategory = Object.keys(categories)[selectedIndex];
        const selectedCommands = categories[selectedCategory] || [];

        const commandsDetails = selectedCommands.map(cmd => `<a:mmb_arrow:1255341510954713138> \`${prefix}${cmd.name}\`: ${cmd.description || 'Không có mô tả'}`).join('\n\n');

        const categoryEmbed = new EmbedBuilder()
            .setColor('#FF69B4')
            .setTitle(`Danh sách lệnh của ${selectedCategory}`)
            .setDescription(commandsDetails || 'Không có lệnh nào.')
            .setTimestamp();

        await interaction.reply({ embeds: [categoryEmbed], ephemeral: true });
    } catch (error) {
        console.error("Error handling category select interaction:", error);
        await interaction.reply({ content: 'Đã xảy ra lỗi khi xử lý lựa chọn này.', ephemeral: true });
    }
});


            // Bộ lọc cho các tương tác nút
            const filter = interaction => interaction.isButton() && ['disable_command', 'enable_command'].includes(interaction.customId) && interaction.user.id === message.author.id;

            const collector = sentMessage.createMessageComponentCollector({ filter, time: 86400000 });

            collector.on('collect', async interaction => {
                try {
                    const action = interaction.customId === 'disable_command' ? 'disable' : 'enable';
                    const selectMenu = new StringSelectMenuBuilder()
                        .setCustomId(`${action}_select`)
                        .setPlaceholder('Chọn hành động')
                        .addOptions([
                            {
                                label: 'Command',
                                value: 'command',
                            },
                            {
                                label: 'Category',
                                value: 'category',
                            },
                            {
                                label: 'All',
                                value: 'all',
                            },
                        ]);
            
                    if (interaction.replied || interaction.deferred) {
                        await interaction.followUp({ content: `Chọn hành động để ${action} lệnh:`, components: [new ActionRowBuilder().addComponents(selectMenu)], ephemeral: true });
                    } else {
                        await interaction.update({ content: `Chọn hành động để ${action} lệnh:`, components: [new ActionRowBuilder().addComponents(selectMenu)], ephemeral: true });
                    }
                } catch (error) {
                    console.error("Error handling button interaction:", error);
            
                    if (error.code === 10062 || error.code === 40060) {
                        console.log("Interaction was already acknowledged or is unknown. Skipping response.");
                    } else {
                        if (interaction.replied || interaction.deferred) {
                            await interaction.followUp({ content: 'Đã xảy ra lỗi khi xử lý tương tác này.', ephemeral: true });
                        } else {
                            await interaction.reply({ content: 'Đã xảy ra lỗi khi xử lý tương tác này.', ephemeral: true });
                        }
                    }
                }
            });

            // Bộ lọc cho các tương tác menu chọn
            const selectFilter = interaction => interaction.isSelectMenu() && ['disable_select', 'enable_select'].includes(interaction.customId) && interaction.user.id === message.author.id;

            const selectCollector = sentMessage.createMessageComponentCollector({ selectFilter, time: 86400000 });

            selectCollector.on('collect', async interaction => {
                try {
                    // Kiểm tra xem có giá trị nào được chọn trong menu chọn không
                    if (!interaction.values || interaction.values.length === 0) {
                        throw new Error('No value selected in select menu.');
                    }
                    
                    const selectedValue = interaction.values[0];
                    const action = interaction.customId.startsWith('disable') ? 'disable' : 'enable';
            
                    if (selectedValue === 'command') {
                        // Defer response để đảm bảo tương tác được xử lý
                        await interaction.deferReply({ ephemeral: true });
            
                        const messageFilter = m => m.author.id === interaction.user.id && m.channel.id === interaction.channel.id;
                        const messageCollector = interaction.channel.createMessageCollector({ filter: messageFilter, time: 60000, max: 1 });
            
                        messageCollector.on('collect', async m => {
                            const commands = m.content.split(',').map(cmd => cmd.trim());
                            const invalidCommands = commands.filter(cmd => !message.client.commands2.has(cmd));
            
                            if (invalidCommands.length) {
                                await interaction.followUp({ content: `Các lệnh sau không tồn tại: \`${invalidCommands.join(', ')}\``, ephemeral: true });
                            } else {
                                await updateCommandStatus(message.guild.id, interaction.channel.id, commands, action);
                                await interaction.followUp({ content: `Các lệnh sau đã được ${action}: \`${commands.join(', ')}\``, ephemeral: true });
                            }
                        });
            
                    } else if (selectedValue === 'category') {
                        await interaction.deferUpdate(); // deferUpdate để đảm bảo tương tác không bị timeout
            
                        const categoryMenu = new StringSelectMenuBuilder()
                            .setCustomId(`${action}_category`)
                            .setPlaceholder('Chọn category')
                            .addOptions(Object.keys(categories).map(cat => ({
                                label: cat,
                                value: cat,
                                emoji: disabledCommands.categories.includes(cat) ? '❌' : '✅'
                            })));
            
                        await interaction.editReply({ content: `Chọn category để ${action}:`, components: [new ActionRowBuilder().addComponents(categoryMenu)] });
            
                        const categoryCollectorFilter = i => i.isStringSelectMenu() && i.customId === `${action}_category` && i.user.id === interaction.user.id;
                        const categoryCollector = interaction.channel.createMessageComponentCollector({ filter: categoryCollectorFilter, time: 60000, max: 1 });
            
                        categoryCollector.on('collect', async categoryInteraction => {
                            const selectedCategory = categoryInteraction.values[0];
                            if (!selectedCategory) { 
                                throw new Error('No category selected.');
                            }
                            await updateCategoryStatus(message.guild.id, interaction.channel.id, selectedCategory, action);
                            await categoryInteraction.followUp({ content: `Category \`${selectedCategory}\` đã được ${action}.`, ephemeral: true });
                        });
            
                    } else if (selectedValue === 'all') {
                        await interaction.deferUpdate(); // deferUpdate để đảm bảo tương tác không bị timeout
                        await updateAllStatus(message.guild.id, interaction.channel.id, action);
                        await interaction.editReply({ content: `Tất cả các lệnh và category đã được ${action} trong kênh này.`, components: [], ephemeral: true });
                    }
                } catch (error) {
                    console.error("Error handling select menu interaction:", error);
            
                    if (error.message === 'No value selected in select menu.') {
                        console.log("No value selected in the select menu. Skipping response.");
                    } else if (error.code === 'InteractionNotReplied') {
                        console.log("The reply to this interaction has not been sent or deferred. Skipping response.");
                    } else {
                        if (interaction.replied || interaction.deferred) {
                            await interaction.followUp({ content: 'Đã xảy ra lỗi khi xử lý tương tác này.', ephemeral: true });
                        } else {
                            await interaction.reply({ content: 'Đã xảy ra lỗi khi xử lý tương tác này.', ephemeral: true });
                        }
                    }
                }
            });
        });
    },
};

// Hàm lấy danh sách các lệnh và category đã bị disable
async function getDisabledCommands(guildId, channelId) {
    return new Promise((resolve, reject) => {
        dataBetaDev.get(
            `SELECT disabled_commands, disabled_categories FROM command_status WHERE guild_id = ? AND channel_id = ?`,
            [guildId, channelId],
            (err, row) => {
                if (err) {
                    console.error(err);
                    return reject(err);
                }
                const commands = row ? JSON.parse(row.disabled_commands) : [];
                const categories = row ? JSON.parse(row.disabled_categories) : [];
                resolve({ commands, categories });
            }
        );
    });
}

// Hàm cập nhật trạng thái bật/tắt của lệnh
async function updateCommandStatus(guildId, channelId, commands, action) {
    const { commands: disabledCommands } = await getDisabledCommands(guildId, channelId);
    let updatedCommands;

    if (action === 'disable') {
        updatedCommands = Array.from(new Set([...disabledCommands, ...commands]));
    } else {
        updatedCommands = disabledCommands.filter(cmd => !commands.includes(cmd));
    }

    dataBetaDev.run(
        `INSERT INTO command_status (guild_id, channel_id, disabled_commands) VALUES (?, ?, ?) 
        ON CONFLICT(guild_id, channel_id) DO UPDATE SET disabled_commands = ?`,
        [guildId, channelId, JSON.stringify(updatedCommands), JSON.stringify(updatedCommands)]
    );
}

// Hàm cập nhật trạng thái bật/tắt của category
async function updateCategoryStatus(guildId, channelId, category, action) {
    const { categories: disabledCategories } = await getDisabledCommands(guildId, channelId);
    let updatedCategories;

    if (action === 'disable') {
        updatedCategories = Array.from(new Set([...disabledCategories, category]));
    } else {
        updatedCategories = disabledCategories.filter(cat => cat !== category);
    }

    dataBetaDev.run(
        `INSERT INTO command_status (guild_id, channel_id, disabled_categories) VALUES (?, ?, ?) 
        ON CONFLICT(guild_id, channel_id) DO UPDATE SET disabled_categories = ?`,
        [guildId, channelId, JSON.stringify(updatedCategories), JSON.stringify(updatedCategories)]
    );
}

// Hàm cập nhật trạng thái bật/tắt của tất cả lệnh và category
async function updateAllStatus(guildId, channelId, action) {
    const updatedCommands = action === 'disable' ? await getAllCommandNames() : [];
    const updatedCategories = action === 'disable' ? await getAllCategoryNames() : [];

    dataBetaDev.run(
        `INSERT INTO command_status (guild_id, channel_id, disabled_commands, disabled_categories) VALUES (?, ?, ?, ?) 
        ON CONFLICT(guild_id, channel_id) DO UPDATE SET disabled_commands = ?, disabled_categories = ?`,
        [guildId, channelId, JSON.stringify(updatedCommands), JSON.stringify(updatedCategories), JSON.stringify(updatedCommands), JSON.stringify(updatedCategories)]
    );
}

// Hàm lấy tất cả các tên lệnh
async function getAllCommandNames() {
    const commandFiles = getAllCommandFiles(path.join(__dirname, '../../cmds'));
    return commandFiles.map(filePath => require(filePath).name);
}

// Hàm lấy tất cả các tên category
async function getAllCategoryNames() {
    const commandFiles = getAllCommandFiles(path.join(__dirname, '../../cmds'));
    const categories = {};
    commandFiles.forEach(filePath => {
        const command = require(filePath);
        const category = command.category || 'Uncategorized';
        if (!categories[category]) {
            categories[category] = true;
        }
    });
    return Object.keys(categories);
}

// Hàm đệ quy lấy tất cả các tệp lệnh
function getAllCommandFiles(dir) {
    let commandFiles = [];
    const files = fs.readdirSync(dir);

    for (const file of files) {
        const filePath = path.join(dir, file);
        const stats = fs.statSync(filePath);

        if (stats.isDirectory()) {
            commandFiles = commandFiles.concat(getAllCommandFiles(filePath));
        } else if (file.endsWith('.js')) {
            commandFiles.push(filePath);
        }
    }

    return commandFiles;
}
