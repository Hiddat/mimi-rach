const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, InteractionType } = require('discord.js');
const sqlite3 = require('sqlite3').verbose();
const dbCaptcha = new sqlite3.Database('./captcha.db', sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE);

module.exports = {
    data: new SlashCommandBuilder()
        .setName('check')
        .setDescription('Kiểm tra trạng thái ban của người dùng.')
        .addUserOption(option => 
            option.setName('user')
                .setDescription('Người dùng cần kiểm tra')
                .setRequired(true)
        ),
    async execute(interaction) {
        // Chỉ cho phép owner sử dụng lệnh
        if (interaction.user.id !== '1145030539074600970') {
            return interaction.reply({ content: 'Bạn không có quyền sử dụng lệnh này.', ephemeral: true });
        }

        const targetUser = interaction.options.getUser('user');
        const userId = targetUser.id;

        // Lấy thông tin từ database
        dbCaptcha.get(`SELECT * FROM captcha_users WHERE userId = ?`, [userId], (err, row) => {
            if (err) {
                return interaction.reply({ content: 'Có lỗi xảy ra khi truy xuất thông tin!', ephemeral: true });
            }

            if (!row) {
                return interaction.reply({ content: 'Người dùng này không có dữ liệu xác minh captcha.', ephemeral: true });
            }

            const now = Date.now();
            let isBanned = false;
            let banEndTime;

            // Kiểm tra nếu người dùng đã bị cấm
            if (row.captcha_status === 'banned') {
                isBanned = true;
                // Nếu ban_expire_at là NULL thì có nghĩa là không có thời hạn hết hạn
                if (row.ban_expire_at && row.ban_expire_at > now) {
                    banEndTime = `<t:${Math.floor(row.ban_expire_at / 1000)}:R>`;
                } else {
                    banEndTime = 'Không có'; // Không có thời hạn hết hạn cụ thể
                }
            }

            // Tạo embed
            const embed = new EmbedBuilder()
                .setColor('#FFB6C1') // Màu hồng pastel
                .setTitle(`Trạng thái của ${targetUser.tag}`)
                .addFields(
                    { name: 'Bị ban', value: isBanned ? 'Có' : 'Không', inline: true },
                    { name: 'Thời gian hết hạn ban', value: isBanned ? banEndTime : 'Không có', inline: true }
                );

            let components = [];
            if (isBanned) {
                // Nút gỡ ban
                const removeBanButton = new ButtonBuilder()
                    .setCustomId('remove_ban')
                    .setLabel('Gỡ ban')
                    .setStyle(ButtonStyle.Danger);

                const actionRow = new ActionRowBuilder().addComponents(removeBanButton);
                components.push(actionRow);
            }

            // Trả lời với embed và các thành phần
            interaction.reply({ embeds: [embed], components, ephemeral: true });
        });
    },

    async handleInteraction(interaction) {
        if (interaction.customId === 'remove_ban') {
            const targetUser = interaction.message.embeds[0].title.split(' ')[2];
            const userId = targetUser.match(/\d+/g)[0];

            // Xóa tất cả các thông tin liên quan đến captcha của người dùng
            dbCaptcha.run(`DELETE FROM captcha_users WHERE userId = ?`, [userId], (err) => {
                if (err) {
                    return interaction.reply({ content: 'Có lỗi xảy ra khi gỡ bỏ ban.', ephemeral: true });
                }
                interaction.update({ content: `Đã gỡ bỏ ban và xóa tất cả thông tin captcha của ${targetUser}.`, components: [], embeds: [], ephemeral: true });
            });
        }
    }
};
