const { SlashCommandBuilder, EmbedBuilder, PermissionsBitField } = require('discord.js');
const AsciiTable = require('ascii-table');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ig')
        .setDescription('Hiển thị thông tin in-game cho mọi người')
        .setDefaultMemberPermissions(PermissionsBitField.Flags.Administrator), // Chỉ dành cho owner
    async execute(interaction) {
        // const ownerId = '1145030539074600970';
        
        // // Kiểm tra xem người gọi lệnh có phải là owner không
        // if (interaction.user.id !== ownerId) {
        //     return interaction.reply({ content: 'Bạn không có quyền sử dụng lệnh này.', ephemeral: true });
        // }

        // Tạo bảng thông tin cho LOL
        const lolTable = new AsciiTable('League of Legends');
        lolTable
            .setHeading('Thông Tin', 'Giá Trị')
            .addRow('Tên', 'Easy#MIMI')
            .addRow('Main', 'Lux, veigar')
            .addRow('Line', 'Support thiên về Ap');

        // Tạo bảng thông tin cho STEAM
        const steamTable = new AsciiTable('Steam');
        steamTable
            .setHeading('Thông Tin', 'Giá Trị')
            .addRow('Id', '1670119058')
            .addRow('Invite', 'https://s.team/p/jfmq-wvnd/KPMJDRFT')
            .addRow('Games', 'Chủ yếu game kinh dị!');

        // Tạo bảng thông tin cho STEAM
        const infoTable = new AsciiTable('OWNER MIMI BOT');
        steamTable
            .setHeading('Thông Tin', 'Giá Trị')
            .addRow('Bot', 'Mimi#0462')
            .addRow('Invite bot', 'https://discord.com/oauth2/authorize?client_id=1207923287519268875&permissions=8&integration_type=0&scope=bot')
            .addRow('Web up ảnh lấy link', 'https://upload.mimibot.fun/');


        const nroTable = new AsciiTable('Ngọc Rồng Mimi Bot');
        steamTable
            .setHeading('Thông Tin', 'Giá Trị')
            .addRow('Website', 'https://nromimi.fun/');


        const mineTable = new AsciiTable('Minecraft Mimi Bot');
        steamTable
            .setHeading('Thông Tin', 'Giá Trị')
            .addRow('link', 'mimigame.fun')
        // Tạo embed để hiển thị thông tin
        const embed = new EmbedBuilder()
            .setColor('#FFB6C1') // Màu hồng pastel
            .setTitle('Thông tin In-Game')
            .setDescription('Dưới đây là các thông tin quan trọng về owner bot:')
            .addFields(
                { name: 'LOL', value: `\`\`\`${lolTable.toString()}\`\`\`` },
                { name: 'STEAM', value: `\`\`\`${steamTable.toString()}\`\`\`` }
            )
            .setTimestamp();

        // Gửi embed tới kênh cho tất cả mọi người xem
        await interaction.reply({ embeds: [embed] });

        const embeds = new EmbedBuilder()
            .setColor('#FFB6C1') // Màu hồng pastel
            .setTitle('Thông tin về owner bot')
            .setDescription('Dưới đây là các thông tin quan trọng về owner bot:')
            .addFields(
                { name: 'Info Easy', value: `\`\`\`${infoTable.toString()}\`\`\`` },
                { name: 'Ngọc rồng Mimi Bot', value: `\`\`\`${nroTable.toString()}\`\`\`` },
                { name: 'Minecraft Mimi Bot', value: `\`\`\`${mineTable.toString()}\`\`\`` }
            )
            .setTimestamp();

        // Gửi embed tới kênh cho tất cả mọi người xem
        await interaction.reply({ embeds: [embeds] });
    }
};
