const { SlashCommandBuilder, EmbedBuilder } = require('discord.js')

const helpEmbed = () => new EmbedBuilder()
    .setColor(13250094)
    .setDescription(':crystal_ball: Hướng dẫn sử dụng các lệnh nối từ')
    .addFields(
        {
            name: 'Cài đặt kênh chơi nối từ',
            value: '`.noichu <channel` hoặc dùng `?mimi set` trong kênh nối từ.',
            inline: true
        },
        {
            name: 'Bắt đầu lượt chơi',
            value: 'Dùng lệnh `?start`',
            inline: true
        },
        {
            name: 'Dừng lượt chơi',
            value: 'Dùng lệnh `?stop`, lượt mới sẽ tự động bắt đầu!',
            inline: true
        },
        {
            name: 'Xem thống kê của BOT',
            value: 'Dùng lệnh slash `/stats`',
            inline: true
        },
        {
            name: 'Xem bảng xếp hạng server',
            value: 'Dùng lệnh slash `/rank`',
            inline: true
        },
        {
            name: 'Xem thống kê cá nhân',
            value: 'Dùng lệnh slash `/me`',
            inline: true
        },
        {
            name: 'Xem 2 từ kiếp tiếp',
            value: 'Dùng lệnh `.wc + 1 từ cần nối`',
            inline: true
        },
        // {
        //     name: 'Report từ sai trong từ điển',
        //     value: 'Dùng lệnh slash `/report <từ> [lý do]`',
        //     inline: true
        // },
        {
            name: 'Xem TT Server',
            value: 'Lệnh slash `/server`',
            inline: true
        },
        {
            name: ':robot: Invite/Vote',
            value: '[Mimi Bot](https://discord.com/oauth2/authorize?client_id=1207923287519268875&permissions=1126864127318081&integration_type=0&scope=bot+applications.commands)',
            inline: true
        },
        {
            name: ':pencil: Đóng góp từ/Hỗ trợ',
            value: '[Server Bot](https://discord.gg/mimibot)',
            inline: true
        }

    )

module.exports = {
    data: new SlashCommandBuilder()
        .setName('noitu')
        .setDescription('Xem hướng dẫn sử dụng lệnh nối từ'),
    async execute(interaction) {
        await interaction.reply({
            embeds: [helpEmbed()],
            flags: [4096]
        })
    }
}