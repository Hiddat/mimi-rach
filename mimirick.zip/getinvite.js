// module.exports = {
//     name: 'getinvite',
//     description: 'Lấy link invite cho server với ID 1164015700688523384',
//     async execute(message, args) {
//         // Lấy guild thông qua ID
//         const guild = await message.client.guilds.fetch('1164015700688523384');

//         if (!guild) {
//             return message.channel.send('Không tìm thấy server với ID này!');
//         }

//         // Lấy channel bất kỳ trong server để tạo invite
//         const channels = guild.channels.cache.filter(channel => channel.isTextBased());
//         if (channels.size === 0) {
//             return message.channel.send('Server không có channel văn bản nào để tạo link invite!');
//         }

//         const channel = channels.first();

//         try {
//             const invite = await channel.createInvite({ maxAge: 0, maxUses: 0 });
//             return message.channel.send(`Đây là link invite của server: ${invite.url}`);
//         } catch (error) {
//             console.error(error);
//             return message.channel.send('Có lỗi xảy ra khi tạo link invite!');
//         }
//     },
// };
