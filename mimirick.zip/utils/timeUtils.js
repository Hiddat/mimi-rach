// utils/timeUtils.js

module.exports.parseDuration = (input) => {
    const regex = /^(\d+)([smhd])$/;
    const match = input.match(regex);

    if (!match) return null;

    const value = parseInt(match[1]);
    const unit = match[2];

    switch (unit) {
        case 's': return value * 1000;
        case 'm': return value * 60 * 1000;
        case 'h': return value * 60 * 60 * 1000;
        case 'd': return value * 24 * 60 * 60 * 1000;
        default: return null;
    }
};

module.exports.parseDate = (input) => {
    const regex = /^(\d{2})-(\d{2})-(\d{4})$/;
    const match = input.match(regex);

    if (!match) return null;

    const day = parseInt(match[1]);
    const month = parseInt(match[2]) - 1; // Tháng bắt đầu từ 0
    const year = parseInt(match[3]);

    const date = new Date(year, month, day);
    return date.getTime();
};
