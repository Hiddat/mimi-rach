const { WebhookClient, EmbedBuilder } = require('discord.js');

async function logError(error, context) {
    const webhookClient = new WebhookClient({ url: 'https://discord.com/api/webhooks/YOUR_WEBHOOK_URL' });

    const errorEmbed = new EmbedBuilder()
        .setTitle('Lỗi Bot')
        .setColor(0xff0000)
        .setDescription(`Đã xảy ra lỗi trong bot`)
        .addFields(
            { name: 'Lỗi', value: `\`\`\`${error.stack || error}\`\`\`` },
            { name: 'Ngữ cảnh', value: `\`\`\`${context}\`\`\`` }
        )
        .setTimestamp();

    try {
        await webhookClient.send({ embeds: [errorEmbed] });
    } catch (sendError) {
        console.error('Không thể gửi lỗi tới webhook:', sendError);
    }
}

module.exports = logError;
