const fetch = require('node-fetch');

async function getGif(action) {
    let gifUrl;
    while (!gifUrl) {
        try {
            const response = await fetch(`https://nekos.life/api/v2/img/${action}`);
            const data = await response.json();
            gifUrl = data.url;
        } catch (error) {
            console.error('Error fetching GIF from nekos.life, retrying...');
        }
    }
    return gifUrl;
}

module.exports = getGif;
