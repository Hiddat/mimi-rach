const dbLove = require('../db/databaseLove');

const getUserMoney = (userId) => new Promise((resolve, reject) => {
  dbLove.get("SELECT money FROM user_money WHERE user_id = ?", [userId], (err, row) => {
    if (err) return reject(err);
    resolve(row ? row.money : 0);
  });
});

const checkLoveStatus = (userId) => new Promise((resolve, reject) => {
  dbLove.get("SELECT * FROM love_data WHERE (user1_id = ? OR user2_id = ?) AND success_time IS NOT NULL ORDER BY success_time DESC LIMIT 1", [userId, userId], (err, row) => {
    if (err) return reject(err);
    resolve(row);
  });
});

const updateUserMoney = (userId, amount) => new Promise((resolve, reject) => {
  dbLove.run("UPDATE user_money SET money = money + ? WHERE user_id = ?", [amount, userId], function(err) {
    if (err) return reject(err);
    resolve();
  });
});

const updateLoveData = (userId, intimacy) => new Promise((resolve, reject) => {
  dbLove.run("UPDATE love_data SET intimacy_level = intimacy_level + ? WHERE user1_id = ? OR user2_id = ?", [intimacy, userId, userId], function(err) {
    if (err) return reject(err);
    resolve();
  });
});

const addToInventory = (userId, gift) => new Promise((resolve, reject) => {
  dbLove.run("INSERT INTO user_inventory (user_id, item_name, emoji, quantity) VALUES (?, ?, ?, 1) ON CONFLICT(user_id, item_name) DO UPDATE SET quantity = quantity + 1", [userId, gift.name, gift.emoji], function(err) {
    if (err) return reject(err);
    resolve();
  });
});


module.exports = {
  getUserMoney,
  checkLoveStatus,
  updateUserMoney,
  updateLoveData,
  addToInventory
};
