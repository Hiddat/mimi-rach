const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./db/commandSettings.db');


        // Cấu hình busyTimeout để tăng thời gian chờ khi database bị khóa
db.configure('busyTimeout', 300000); // 5 giây

// Hàng đợi để xử lý các thao tác ghi tuần tự
const queue = [];

// Hàm xử lý hàng đợi
function processQueue() {
  if (queue.length > 0) {
    const task = queue.shift();
    task();
  }
}

// Thêm thao tác ghi vào hàng đợi
function addToQueue(task) {
  queue.push(() => {
    task(() => {
      processQueue();
    });
  });

  if (queue.length === 1) {
    processQueue();
  }
}

// Ví dụ về ghi dữ liệu vào cơ sở dữ liệu
function writeData(sql, params) {
  addToQueue((done) => {
    db.run(sql, params, (err) => {
      if (err) {
        console.error('Lỗi ghi vào cơ sở dữ liệu:', err.message);
      }
      done();
    });
  });
}
db.serialize(() => {
    writeData(`
        CREATE TABLE IF NOT EXISTS CommandSettings (
            guild_id TEXT,
            channel_id TEXT,
            command TEXT,
            category TEXT,
            is_enabled INTEGER,
            PRIMARY KEY (guild_id, channel_id, command)
        )
    `);
});

function setCommandStatus(guild_id, channel_id, command, category, is_enabled) {
    return new Promise((resolve, reject) => {
        const stmt = db.prepare(`
            INSERT INTO CommandSettings (guild_id, channel_id, command, category, is_enabled)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(guild_id, channel_id, command)
            DO UPDATE SET is_enabled = excluded.is_enabled
        `);
        stmt.run(guild_id, channel_id, command, category, is_enabled, function (err) {
            if (err) {
                return reject(err);
            }
            resolve();
        });
        stmt.finalize();
    });
}

function getCommandStatus(guild_id, channel_id, command) {
    return new Promise((resolve, reject) => {
        db.get(`SELECT is_enabled FROM CommandSettings WHERE guild_id = ? AND channel_id = ? AND command = ?`, [guild_id, channel_id, command], (err, row) => {
            if (err) {
                return reject(err);
            }
            resolve(row ? row.is_enabled : 1);
        });
    });
}

function getCategoryStatus(guild_id, channel_id, category) {
    return new Promise((resolve, reject) => {
        db.all(`SELECT is_enabled FROM CommandSettings WHERE guild_id = ? AND channel_id = ? AND category = ?`, [guild_id, channel_id, category], (err, rows) => {
            if (err) {
                return reject(err);
            }
            resolve(rows);
        });
    });
}

function getDisabledCommands(guild_id) {
    return new Promise((resolve, reject) => {
        db.all(`SELECT * FROM CommandSettings WHERE guild_id = ? AND is_enabled = 0`, [guild_id], (err, rows) => {
            if (err) {
                return reject(err);
            }
            resolve(rows);
        });
    });
}

module.exports = {
    setCommandStatus,
    getCommandStatus,
    getCategoryStatus,
    getDisabledCommands
};
