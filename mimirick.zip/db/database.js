const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./welcome.db');

        // Cấu hình busyTimeout để tăng thời gian chờ khi database bị khóa
db.configure('busyTimeout', 300000); // 5 giây

// Hàng đợi để xử lý các thao tác ghi tuần tự
const queue = [];

// Hàm xử lý hàng đợi
function processQueue() {
  if (queue.length > 0) {
    const task = queue.shift();
    task();
  }
}

// Thêm thao tác ghi vào hàng đợi
function addToQueue(task) {
  queue.push(() => {
    task(() => {
      processQueue();
    });
  });

  if (queue.length === 1) {
    processQueue();
  }
}

// Ví dụ về ghi dữ liệu vào cơ sở dữ liệu
function writeData(sql, params) {
  addToQueue((done) => {
    db.run(sql, params, (err) => {
      if (err) {
        console.error('Lỗi ghi vào cơ sở dữ liệu:', err.message);
      }
      done();
    });
  });
}
db.serialize(() => {
    writeData(`
        CREATE TABLE IF NOT EXISTS afk_users (
            user_id TEXT PRIMARY KEY,
            reason TEXT,
            timestamp INTEGER
        )
    `);

    writeData(`
        CREATE TABLE IF NOT EXISTS afk_mentions (
            user_id TEXT,
            mentioner_id TEXT,
            message_id TEXT,
            channel_id TEXT,
            content TEXT,
            timestamp INTEGER
        )
    `);
    writeData(`
        CREATE TABLE IF NOT EXISTS welcome_settings (
            guild_id TEXT PRIMARY KEY,
            channel_id TEXT,
            title TEXT,
            description TEXT,
            thumbnail TEXT,
            image TEXT,
            color TEXT,
            content TEXT,
            enabled INTEGER
        )
    `);

    writeData(`
        CREATE TABLE IF NOT EXISTS leave_settings (
            guild_id TEXT PRIMARY KEY,
            channel_id TEXT,
            title TEXT,
            description TEXT,
            thumbnail TEXT,
            image TEXT,
            color TEXT,
            content TEXT,
            enabled INTEGER
        )
    `);

    writeData(`
        CREATE TABLE IF NOT EXISTS spam_counters (
            user_id TEXT PRIMARY KEY,
            count INTEGER,
            last_command INTEGER,
            warned INTEGER
        )
    `);

    writeData(`
        CREATE TABLE IF NOT EXISTS banned_users (
            user_id TEXT PRIMARY KEY,
            timestamp INTEGER
        )
    `);

    writeData(`
        CREATE TABLE IF NOT EXISTS afk_users (
            user_id TEXT PRIMARY KEY,
            reason TEXT,
            timestamp INTEGER
        )
    `);

    writeData(`
        CREATE TABLE IF NOT EXISTS afk_mentions (
            user_id TEXT,
            mentioner_id TEXT,
            message_id TEXT,
            channel_id TEXT,
            content TEXT,
            timestamp INTEGER
        )
    `);

    writeData(`
        CREATE TABLE IF NOT EXISTS command_usage (
            command_name TEXT PRIMARY KEY,
            usage_count INTEGER
        )
    `);

    writeData(`
        CREATE TABLE IF NOT EXISTS deleted_messages (
            message_id TEXT PRIMARY KEY,
            user_id TEXT,
            content TEXT,
            channel_id TEXT,
            deleted_at INTEGER
        )
    `);
});


function setAFK(userId, reason, timestamp) {
    return new Promise((resolve, reject) => {
        writeData(`
            INSERT INTO afk_users (user_id, reason, timestamp)
            VALUES (?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET 
                reason = excluded.reason,
                timestamp = excluded.timestamp
        `, [userId, reason, timestamp], function(err) {
            if (err) {
                return reject(err);
            }
            resolve();
        });
    });
}

function removeAFK(userId) {
    return new Promise((resolve, reject) => {
        writeData(`
            DELETE FROM afk_users WHERE user_id = ?
        `, [userId], function(err) {
            if (err) {
                return reject(err);
            }
            resolve();
        });
    });
}

function getAFK(userId) {
    return new Promise((resolve, reject) => {
        db.get(`
            SELECT * FROM afk_users WHERE user_id = ?
        `, [userId], (err, row) => {
            if (err) {
                return reject(err);
            }
            resolve(row);
        });
    });
}

function addAFKMention(userId, mentionerId, messageId, channelId, content, timestamp) {
    return new Promise((resolve, reject) => {
        writeData(`
            INSERT INTO afk_mentions (user_id, mentioner_id, message_id, channel_id, content, timestamp)
            VALUES (?, ?, ?, ?, ?, ?)
        `, [userId, mentionerId, messageId, channelId, content, timestamp], function(err) {
            if (err) {
                return reject(err);
            }
            resolve();
        });
    });
}

function getAFKMentions(userId) {
    return new Promise((resolve, reject) => {
        db.all(`
            SELECT * FROM afk_mentions WHERE user_id = ?
        `, [userId], (err, rows) => {
            if (err) {
                return reject(err);
            }
            resolve(rows);
        });
    });
}

function removeAFKMentions(userId) {
    return new Promise((resolve, reject) => {
        writeData(`
            DELETE FROM afk_mentions WHERE user_id = ?
        `, [userId], function(err) {
            if (err) {
                return reject(err);
            }
            resolve();
        });
    });
}


function setAFK(userId, reason, timestamp) {
    return new Promise((resolve, reject) => {
        writeData(`
            INSERT INTO afk_users (user_id, reason, timestamp)
            VALUES (?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET 
                reason = excluded.reason,
                timestamp = excluded.timestamp
        `, [userId, reason, timestamp], function(err) {
            if (err) {
                return reject(err);
            }
            resolve();
        });
    });
}

function removeAFK(userId) {
    return new Promise((resolve, reject) => {
        writeData(`
            DELETE FROM afk_users WHERE user_id = ?
        `, [userId], function(err) {
            if (err) {
                return reject(err);
            }
            resolve();
        });
    });
}

function getAFK(userId) {
    return new Promise((resolve, reject) => {
        db.get(`
            SELECT * FROM afk_users WHERE user_id = ?
        `, [userId], (err, row) => {
            if (err) {
                return reject(err);
            }
            resolve(row);
        });
    });
}

function addAFKMention(userId, mentionerId, messageId, channelId, content, timestamp) {
    return new Promise((resolve, reject) => {
        writeData(`
            INSERT INTO afk_mentions (user_id, mentioner_id, message_id, channel_id, content, timestamp)
            VALUES (?, ?, ?, ?, ?, ?)
        `, [userId, mentionerId, messageId, channelId, content, timestamp], function(err) {
            if (err) {
                return reject(err);
            }
            resolve();
        });
    });
}

function getAFKMentions(userId) {
    return new Promise((resolve, reject) => {
        db.all(`
            SELECT * FROM afk_mentions WHERE user_id = ?
        `, [userId], (err, rows) => {
            if (err) {
                return reject(err);
            }
            resolve(rows);
        });
    });
}

function removeAFKMentions(userId) {
    return new Promise((resolve, reject) => {
        writeData(`
            DELETE FROM afk_mentions WHERE user_id = ?
        `, [userId], function(err) {
            if (err) {
                return reject(err);
            }
            resolve();
        });
    });
}


function setSpamCounter(userId, count, lastCommand, warned) {
    return new Promise((resolve, reject) => {
        writeData(`
            INSERT INTO spam_counters (user_id, count, last_command, warned)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET 
                count = excluded.count, 
                last_command = excluded.last_command,
                warned = excluded.warned
        `, [userId, count, lastCommand, warned], function(err) {
            if (err) {
                return reject(err);
            }
            resolve();
        });
    });
}

function getSpamCounter(userId) {
    return new Promise((resolve, reject) => {
        db.get(`
            SELECT * FROM spam_counters WHERE user_id = ?
        `, [userId], (err, row) => {
            if (err) {
                return reject(err);
            }
            resolve(row);
        });
    });
}

function deleteSpamCounter(userId) {
    return new Promise((resolve, reject) => {
        writeData(`
            DELETE FROM spam_counters WHERE user_id = ?
        `, [userId], function(err) {
            if (err) {
                return reject(err);
            }
            resolve();
        });
    });
}

function banUser(userId, timestamp) {
    return new Promise((resolve, reject) => {
        writeData(`
            INSERT INTO banned_users (user_id, timestamp)
            VALUES (?, ?)
            ON CONFLICT(user_id) DO UPDATE SET 
                timestamp = excluded.timestamp
        `, [userId, timestamp], function(err) {
            if (err) {
                return reject(err);
            }
            resolve();
        });
    });
}

function unbanUser(userId) {
    return new Promise((resolve, reject) => {
        writeData(`
            DELETE FROM banned_users WHERE user_id = ?
        `, [userId], function(err) {
            if (err) {
                return reject(err);
            }
            resolve();
        });
    });
}

function getBannedUsers() {
    return new Promise((resolve, reject) => {
        db.all(`
            SELECT * FROM banned_users
        `, [], (err, rows) => {
            if (err) {
                return reject(err);
            }
            resolve(rows);
        });
    });
}

function setWelcomeSetting(guildId, key, value) {
    return new Promise((resolve, reject) => {
        writeData(`
            INSERT INTO welcome_settings (guild_id, ${key})
            VALUES (?, ?)
            ON CONFLICT(guild_id) DO UPDATE SET ${key} = excluded.${key}
        `, [guildId, value], function(err) {
            if (err) {
                return reject(err);
            }
            resolve();
        });
    });
}

function getWelcomeSettings(guildId) {
    return new Promise((resolve, reject) => {
        db.get(`
            SELECT * FROM welcome_settings WHERE guild_id = ?
        `, [guildId], (err, row) => {
            if (err) {
                return reject(err);
            }
            resolve(row);
        });
    });
}

function setLeaveSetting(guildId, key, value) {
    return new Promise((resolve, reject) => {
        writeData(`
            INSERT INTO leave_settings (guild_id, ${key})
            VALUES (?, ?)
            ON CONFLICT(guild_id) DO UPDATE SET ${key} = excluded.${key}
        `, [guildId, value], function(err) {
            if (err) {
                return reject(err);
            }
            resolve();
        });
    });
}

function getLeaveSettings(guildId) {
    return new Promise((resolve, reject) => {
        db.get(`
            SELECT * FROM leave_settings WHERE guild_id = ?
        `, [guildId], (err, row) => {
            if (err) {
                return reject(err);
            }
            resolve(row);
        });
    });
}

function logCommandUsage(commandName) {
    return new Promise((resolve, reject) => {
        writeData(`
            INSERT INTO command_usage (command_name, usage_count)
            VALUES (?, 1)
            ON CONFLICT(command_name) DO UPDATE SET 
                usage_count = usage_count + 1
        `, [commandName], function(err) {
            if (err) {
                return reject(err);
            }
            resolve();
        });
    });
}

function getTotalCommandUsage() {
    return new Promise((resolve, reject) => {
        db.get(`
            SELECT SUM(usage_count) as total_usage FROM command_usage
        `, (err, row) => {
            if (err) {
                return reject(err);
            }
            resolve(row.total_usage || 0);
        });
    });
}
// Lưu tin nhắn đã xóa vào cơ sở dữ liệu
function saveDeletedMessage(messageId, userId, content, channelId, deletedAt) {
    return new Promise((resolve, reject) => {
        writeData(`
            INSERT INTO deleted_messages (message_id, user_id, content, channel_id, deleted_at)
            VALUES (?, ?, ?, ?, ?)
        `, [messageId, userId, content, channelId, deletedAt], function(err) {
            if (err) {
                return reject(err);
            }
            resolve();
        });
    });
}

// Lưu tin nhắn đã xóa vào cơ sở dữ liệu
function saveDeletedMessage(messageId, userId, content, channelId, deletedAt) {
    return new Promise((resolve, reject) => {
        writeData(`
            INSERT INTO deleted_messages (message_id, user_id, content, channel_id, deleted_at)
            VALUES (?, ?, ?, ?, ?)
        `, [messageId, userId, content, channelId, deletedAt], function(err) {
            if (err) {
                return reject(err);
            }
            resolve();
        });
    });
}

// Lấy các tin nhắn đã xóa trong khoảng thời gian nhất định
function getDeletedMessages(since) {
    return new Promise((resolve, reject) => {
        db.all(`
            SELECT * FROM deleted_messages WHERE deleted_at > ?
            ORDER BY deleted_at DESC
        `, [since], (err, rows) => {
            if (err) {
                return reject(err);
            }
            resolve(rows);
        });
    });
}

db.configure("busyTimeout", 5000);
db.run("PRAGMA journal_mode = WAL;");
module.exports = {
    saveDeletedMessage,
    getDeletedMessages,
    setWelcomeSetting,
    getWelcomeSettings,
    setLeaveSetting,
    getLeaveSettings,
    setSpamCounter,
    getSpamCounter,
    deleteSpamCounter,
    banUser,
    unbanUser,
    getBannedUsers,
    setAFK,
    removeAFK,
    getAFK,
    addAFKMention,
    getAFKMentions,
    removeAFKMentions,
    logCommandUsage,
    getTotalCommandUsage
};
