const sqlite3 = require('sqlite3').verbose();

const db = new sqlite3.Database('./db/databaseBetaBot.db', sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, (err) => {
    if (err) {
        console.error('Could not connect to database', err);
    } else {
        // Cấu hình busyTimeout để tăng thời gian chờ khi database bị khóa
db.configure('busyTimeout', 300000); // 5 giây

// Hàng đợi để xử lý các thao tác ghi tuần tự
const queue = [];

// Hàm xử lý hàng đợi
function processQueue() {
  if (queue.length > 0) {
    const task = queue.shift();
    task();
  }
}

// Thêm thao tác ghi vào hàng đợi
function addToQueue(task) {
  queue.push(() => {
    task(() => {
      processQueue();
    });
  });

  if (queue.length === 1) {
    processQueue();
  }
}

// Ví dụ về ghi dữ liệu vào cơ sở dữ liệu
function writeData(sql, params) {
  addToQueue((done) => {
    db.run(sql, params, (err) => {
      if (err) {
        console.error('Lỗi ghi vào cơ sở dữ liệu:', err.message);
      }
      done();
    });
  });
}
        writeData(`CREATE TABLE IF NOT EXISTS notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            guild_id TEXT NOT NULL,
            note TEXT NOT NULL
        )`);
    
        writeData(`CREATE TABLE IF NOT EXISTS locks (
            channel_id TEXT PRIMARY KEY,
            guild_id TEXT NOT NULL,
            unlock_time INTEGER,
            message TEXT
        )`);
    writeData(`CREATE TABLE IF NOT EXISTS highlights (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        phrase TEXT NOT NULL
    )`);

    writeData(`CREATE TABLE IF NOT EXISTS game_channels (
        guild_id TEXT NOT NULL,
        epic_channel_id TEXT,
        steam_channel_id TEXT,
        epic_webhook_url TEXT,
        steam_webhook_url TEXT,
        PRIMARY KEY(guild_id)
    )`);
        // writeDataALTER TABLE autorespond_embeds ADD COLUMN guildId TEXT NOT NULL DEFAULT '')`);
writeData(`CREATE TABLE IF NOT EXISTS autorespond_embeds (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guildId TEXT NOT NULL,
    trigger TEXT NOT NULL,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    color TEXT NOT NULL,
    image TEXT,
    isActive BOOLEAN DEFAULT 1
)`);
writeData(`
    CREATE TABLE IF NOT EXISTS disabled_commands (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        channel_id TEXT NOT NULL,
        command_name TEXT,
        category_name TEXT
    )
`);
        writeData(`
        CREATE TABLE IF NOT EXISTS muted_users (
            guildId TEXT NOT NULL,
            userId TEXT NOT NULL,
            unmuteTime INTEGER NOT NULL,
            PRIMARY KEY (guildId, userId)
        )`);

        writeData(`CREATE TABLE IF NOT EXISTS warns (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            guildId TEXT NOT NULL,
            userId TEXT NOT NULL,
            reason TEXT NOT NULL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            requestedBy TEXT NOT NULL
        )`);
        writeData(`CREATE TABLE IF NOT EXISTS log_channels (
            guildId TEXT PRIMARY KEY,
            channelId TEXT NOT NULL
        )`);
        writeData(`CREATE TABLE IF NOT EXISTS random_roles (
            guildId TEXT NOT NULL,
            roleId TEXT NOT NULL,
            roleName TEXT NOT NULL,
            PRIMARY KEY (guildId, roleId)
        )`);
        writeData(`CREATE TABLE IF NOT EXISTS random_role_embed (
            guildId TEXT PRIMARY KEY,
            title TEXT,
            content TEXT,
            image TEXT,
            thumbnail TEXT
        )`);
    }
});
db.configure("busyTimeout", 10000);

module.exports = db;
