// /db/dbmod.js
const sqlite3 = require('sqlite3').verbose();
const dbmod = new sqlite3.Database('./db/dbmod.db');

dbmod.serialize(() => {
  dbmod.run("CREATE TABLE IF NOT EXISTS bans (id TEXT, guild_id TEXT, reason TEXT, timestamp INTEGER, PRIMARY KEY (id, guild_id))");
  dbmod.run("CREATE TABLE IF NOT EXISTS mutes (id TEXT, guild_id TEXT, reason TEXT, duration INTEGER, timestamp INTEGER, PRIMARY KEY (id, guild_id))");
  dbmod.run("CREATE TABLE IF NOT EXISTS warns (id TEXT, guild_id TEXT, reason TEXT, count INTEGER, timestamp INTEGER, PRIMARY KEY (id, guild_id))");
  dbmod.run("CREATE TABLE IF NOT EXISTS settings (guild_id TEXT PRIMARY KEY, log_channel_id TEXT)");
});

module.exports = dbmod;
