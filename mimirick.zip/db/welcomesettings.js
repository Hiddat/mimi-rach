const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./db/welcomeSettings.db');


        // Cấu hình busyTimeout để tăng thời gian chờ khi database bị khóa
db.configure('busyTimeout', 300000); // 5 giây

// Hàng đợi để xử lý các thao tác ghi tuần tự
const queue = [];

// Hàm xử lý hàng đợi
function processQueue() {
  if (queue.length > 0) {
    const task = queue.shift();
    task();
  }
}

// Thêm thao tác ghi vào hàng đợi
function addToQueue(task) {
  queue.push(() => {
    task(() => {
      processQueue();
    });
  });

  if (queue.length === 1) {
    processQueue();
  }
}

// Ví dụ về ghi dữ liệu vào cơ sở dữ liệu
function writeData(sql, params) {
  addToQueue((done) => {
    db.run(sql, params, (err) => {
      if (err) {
        console.error('Lỗi ghi vào cơ sở dữ liệu:', err.message);
      }
      done();
    });
  });
}
db.serialize(() => {
    writeData(`
        CREATE TABLE IF NOT EXISTS WelcomeSettings (
            guild_id TEXT PRIMARY KEY,
            title TEXT,
            description TEXT,
            thumbnail TEXT,
            image TEXT,
            color TEXT,
            content TEXT,
            channel_id TEXT,
            show_avatar INTEGER,
            footer TEXT,
            footer_icon TEXT,
            enabled INTEGER,
            author TEXT,
            author_icon TEXT
        )
    `);
});


// Hàm setWelcomeSetting với hàng đợi
function setWelcomeSetting(guild_id, key, value) {
    return new Promise((resolve, reject) => {
        addToQueue((done) => {
            const stmt = db.prepare(`
                INSERT INTO WelcomeSettings (guild_id, ${key})
                VALUES (?, ?)
                ON CONFLICT(guild_id)
                DO UPDATE SET ${key} = excluded.${key}
            `);
            stmt.run(guild_id, value, function (err) {
                if (err) {
                    reject(err);
                } else {
                    resolve();
                }
                done(); // Kết thúc thao tác hàng đợi
            });
            stmt.finalize();
        });
    });
}

function getWelcomeSettings(guild_id) {
    return new Promise((resolve, reject) => {
        db.get(`SELECT * FROM WelcomeSettings WHERE guild_id = ?`, [guild_id], (err, row) => {
            if (err) {
                return reject(err);
            }
            resolve(row);
        });
    });
}


module.exports = {
    setWelcomeSetting,
    getWelcomeSettings
};