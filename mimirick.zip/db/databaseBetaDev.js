
const sqlite3 = require('sqlite3').verbose();
const dataBetaDev = new sqlite3.Database('./db/databaseBetaDev.db', (err) => {
    if (err) {
        console.error('Không thể kết nối đến cơ sở dữ liệu:', err);
    } else {
        // Cấu hình busyTimeout để tăng thời gian chờ khi database bị khóa
dataBetaDev.configure('busyTimeout', 300000); // 5 giây

// Hàng đợi để xử lý các thao tác ghi tuần tự
const queue = [];

// Hàm xử lý hàng đợi
function processQueue() {
  if (queue.length > 0) {
    const task = queue.shift();
    task();
  }
}

// Thêm thao tác ghi vào hàng đợi
function addToQueue(task) {
  queue.push(() => {
    task(() => {
      processQueue();
    });
  });

  if (queue.length === 1) {
    processQueue();
  }
}

// Ví dụ về ghi dữ liệu vào cơ sở dữ liệu
function writeData(sql, params) {
  addToQueue((done) => {
    dataBetaDev.run(sql, params, (err) => {
      if (err) {
        console.error('Lỗi ghi vào cơ sở dữ liệu:', err.message);
      }
      done();
    });
  });
}
    writeData(`
        CREATE TABLE IF NOT EXISTS autoimages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            guild_id TEXT,
            trigger TEXT,
            image_url TEXT,
            reply INTEGER DEFAULT 0,
            filter_mode TEXT DEFAULT 'contains'
        )
    `);
    writeData(`CREATE TABLE IF NOT EXISTS autoresponses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT,
        trigger TEXT,
        response TEXT,
        reply BOOLEAN DEFAULT false
    )`);
        writeData(`CREATE TABLE IF NOT EXISTS count_channels (
            guild_id TEXT PRIMARY KEY,
            channel_id TEXT NOT NULL,
            current_number INTEGER NOT NULL,
            last_user_id TEXT NOT NULL
        )`);
        writeData(`CREATE TABLE IF NOT EXISTS roman_count_channels (
            guild_id TEXT PRIMARY KEY,
            channel_id TEXT NOT NULL,
            current_number INTEGER NOT NULL,
            last_user_id TEXT NOT NULL
        )`);
        

    writeData(`CREATE TABLE IF NOT EXISTS toggle_states (
        guild_id TEXT NOT NULL,
        state BOOLEAN DEFAULT false
    )`);
        writeData(`CREATE TABLE IF NOT EXISTS wordchain_channels (
            guild_id TEXT PRIMARY KEY,
            channel_id TEXT NOT NULL
                )`);
        writeData(`CREATE TABLE IF NOT EXISTS autorespond_embeds (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            guildId TEXT NOT NULL,
            trigger TEXT NOT NULL,
            title TEXT NOT NULL,
            description TEXT NOT NULL,
            color TEXT NOT NULL,
            image TEXT,
            isActive BOOLEAN DEFAULT 1
        )`);
        writeData(`CREATE TABLE IF NOT EXISTS wordchain_rounds (
            guild_id TEXT PRIMARY KEY,
            word TEXT NOT NULL,
            last_user TEXT NOT NULL,
            round_number INTEGER NOT NULL
        )`);
        writeData(`CREATE TABLE IF NOT EXISTS wordchain_words (
            guild_id TEXT,
            word TEXT NOT NULL,
            UNIQUE(guild_id, word)
        )`);
        writeData(`CREATE TABLE IF NOT EXISTS snipes (
            guild_id TEXT,
            channel_id TEXT,
            message_id TEXT,
            author_id TEXT,
            content TEXT,
            timestamp INTEGER
        )`);
        writeData(`CREATE TABLE IF NOT EXISTS afk_users (
            user_id TEXT PRIMARY KEY,
            reason TEXT,
            timestamp INTEGER,
            message_count INTEGER DEFAULT 0
        )`);
        writeData(`CREATE TABLE IF NOT EXISTS prefixes (
            guild_id TEXT PRIMARY KEY,
            prefix TEXT NOT NULL
        )`);
        writeData(`CREATE TABLE IF NOT EXISTS afk_tags (
            user_id TEXT,
            tagger_id TEXT,
            content TEXT,
            message_id TEXT,
            channel_id TEXT,
            timestamp INTEGER
        )`);
        writeData(`CREATE TABLE IF NOT EXISTS guild_settings (
            guild_id TEXT PRIMARY KEY,
            log_channel_id TEXT,
            voice_log_channel_id TEXT
        )`);
        
    // Tạo bảng wordchain_usage nếu chưa tồn tại
    writeData(`CREATE TABLE IF NOT EXISTS wordchain_usage (
        user_id TEXT PRIMARY KEY,
        free_uses INTEGER,
        last_used INTEGER
    )`);
        writeData(`CREATE TABLE IF NOT EXISTS autorvesponses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            guild_id TEXT,
            trigger TEXT,
            response TEXT,
            reply BOOLEAN DEFAULT false
        )`);
        writeData(`CREATE TABLE IF NOT EXISTS giveaways (
            id TEXT PRIMARY KEY, 
            prize TEXT, 
            winnerCount INTEGER, 
            endTime INTEGER, 
            channelId TEXT, 
            messageId TEXT,
            guildId TEXT,
            user TEXT,
            is_deleted INTEGER DEFAULT 0
        )`);
        writeData(`CREATE TABLE IF NOT EXISTS addpoints_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            server_id TEXT,
            user_id TEXT,
            target_user_id TEXT,
            points_added INTEGER,
            timestamp INTEGER
        )`);
        writeData(`CREATE TABLE IF NOT EXISTS music_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT,
            title TEXT,
            url TEXT,
            length INTEGER,
            timestamp INTEGER
        )`);
        writeData(`CREATE TABLE IF NOT EXISTS user_server_time (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT,
            server_id TEXT,
            server_name TEXT,
            total_time INTEGER
        )`);

        writeData(`CREATE TABLE IF NOT EXISTS snipes (
            guild_id TEXT,
            channel_id TEXT,
            message_id TEXT,
            author_id TEXT,
            content TEXT,
            timestamp INTEGER
        )`);
        writeData(`CREATE TABLE IF NOT EXISTS afk_users (
            user_id TEXT PRIMARY KEY,
            reason TEXT,
            timestamp INTEGER,
            message_count INTEGER DEFAULT 0
        )`);
        writeData(`CREATE TABLE IF NOT EXISTS afk_tags (
            user_id TEXT,
            tagger_id TEXT,
            content TEXT,
            message_id TEXT,
            channel_id TEXT,
            timestamp INTEGER
        )`);
        writeData(`CREATE TABLE IF NOT EXISTS guild_settings (
            guild_id TEXT PRIMARY KEY,
            log_channel_id TEXT,
            voice_log_channel_id TEXT
        )`);
        writeData(`CREATE TABLE IF NOT EXISTS giveaways (
            id TEXT PRIMARY KEY, 
            prize TEXT, 
            winnerCount INTEGER, 
            endTime INTEGER, 
            channelId TEXT, 
            messageId TEXT,
            guildId TEXT,
            is_deleted INTEGER DEFAULT 0
        )`);
        writeData(`CREATE TABLE IF NOT EXISTS user_points (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT,
            global_points INTEGER DEFAULT 0,
            server_points INTEGER DEFAULT 0,
            used_points INTEGER DEFAULT 0
        )`);
        writeData(`CREATE TABLE IF NOT EXISTS chatgpt_config (
            guild_id TEXT PRIMARY KEY,
            channel_id TEXT
        )`);
        writeData(`CREATE TABLE IF NOT EXISTS deleted_messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT,
            username TEXT,
            avatar_url TEXT,
            content TEXT,
            timestamp INTEGER,
            guild_id TEXT,
            attachments TEXT
        )`);
        writeData(`CREATE TABLE IF NOT EXISTS log_channels (
            guild_id TEXT NOT NULL,
            log_channel_id TEXT NOT NULL,
            log_webhook_id TEXT NOT NULL,
            log_webhook_token TEXT NOT NULL,
            log_type TEXT NOT NULL,
            PRIMARY KEY (guild_id, log_type)
        )`);
    }
});
dataBetaDev.configure("busyTimeout", 10000);

module.exports = dataBetaDev;
