const sqlite3 = require('sqlite3').verbose();
const dbLove = new sqlite3.Database('./db/love.db', (err) => {
  if (err) {
    console.error(err.message);
  } else {
    console.log('Kết nối thành công đến cơ sở dữ liệu.');
  }
});

// Cấu hình busyTimeout để tăng thời gian chờ khi database bị khóa
dbLove.configure('busyTimeout', 300000); // 5 giây

// Hàng đợi để xử lý các thao tác ghi tuần tự
const queue = [];

// Hàm xử lý hàng đợi
function processQueue() {
  if (queue.length > 0) {
    const task = queue.shift();
    task();
  }
}

// Thêm thao tác ghi vào hàng đợi
function addToQueue(task) {
  queue.push(() => {
    task(() => {
      processQueue();
    });
  });

  if (queue.length === 1) {
    processQueue();
  }
}

// Ví dụ về ghi dữ liệu vào cơ sở dữ liệu
function writeData(sql, params) {
  addToQueue((done) => {
    dbLove.run(sql, params, (err) => {
      if (err) {
        console.error('Lỗi ghi vào cơ sở dữ liệu:', err.message);
      }
      done();
    });
  });
}

// Tạo bảng trực tiếp
dbLove.serialize(() => {
  // Bảng lưu cá của người dùng
  writeData(`CREATE TABLE IF NOT EXISTS user_fish (
    user_id TEXT,
    fish_id INTEGER,
    quantity INTEGER DEFAULT 0,
    PRIMARY KEY (user_id, fish_id)
  )`);

  // Bảng lưu tên câu cá của người dùng
  writeData(`CREATE TABLE IF NOT EXISTS fishing_name (
    user_id TEXT PRIMARY KEY,
    name TEXT
  )`);

  // Bảng lưu điểm câu cá của người chơi
  writeData(`CREATE TABLE IF NOT EXISTS user_fishing_score (
    user_id TEXT PRIMARY KEY,
    score INTEGER DEFAULT 0
  )`);

  // Bảng lưu dữ liệu tình yêu
  writeData(`CREATE TABLE IF NOT EXISTS love_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user1_id TEXT,
    user2_id TEXT,
    action TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    success_time DATETIME,
    intimacy_level INTEGER DEFAULT 0,
    ring_level INTEGER DEFAULT 0,
    ring_type TEXT DEFAULT 'none',
    pregnancy_start DATETIME,
    pregnancy_health INTEGER DEFAULT 100,
    pregnancy_stage TEXT,
    pregnancy_gender TEXT
  )`);

  // Bảng lưu cấu hình guild
  writeData(`CREATE TABLE IF NOT EXISTS guild_settings (
    guild_id TEXT PRIMARY KEY,
    notify_level_up INTEGER DEFAULT 0,
    rank_channel_id TEXT,
    daily_exp_limit INTEGER DEFAULT 170000
  )`);

  // Bảng lưu kho đồ của người dùng
  writeData(`CREATE TABLE IF NOT EXISTS user_inventorys (
    user_id TEXT NOT NULL,
    item_name TEXT NOT NULL,
    emoji TEXT NOT NULL,
    quantity INTEGER DEFAULT 1,
    PRIMARY KEY (user_id, item_name)
  )`);

  // Bảng lưu lịch sử giao dịch
  writeData(`CREATE TABLE IF NOT EXISTS transaction_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT,
    target_id TEXT,
    amount INTEGER,
    timestamp INTEGER,
    user_money_before INTEGER,
    user_money_after INTEGER,
    target_money_before INTEGER,
    target_money_after INTEGER
  )`);

  // Bảng lưu trạng thái voice của người dùng
  writeData(`CREATE TABLE IF NOT EXISTS voice_status (
    user_id TEXT PRIMARY KEY,
    channel_id TEXT,
    join_time DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  // Bảng lưu thông tin giới thiệu của người dùng
  writeData(`CREATE TABLE IF NOT EXISTS user_about (
    user_id TEXT UNIQUE,
    about TEXT,
    image TEXT
  )`);

  // Bảng lưu lịch sử tình yêu
  writeData(`CREATE TABLE IF NOT EXISTS love_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT,
    action TEXT,
    target_id TEXT,
    time DATETIME
  )`);

  // Bảng lưu thông tin chuyển khoản hàng ngày
  writeData(`CREATE TABLE IF NOT EXISTS user_daily_transfer (
    user_id TEXT,
    date TEXT,
    daily_transfer INTEGER,
    PRIMARY KEY (user_id, date)
  )`);

  // Bảng lưu thông tin nhận hàng ngày
  writeData(`CREATE TABLE IF NOT EXISTS user_daily_receive (
    user_id TEXT,
    date TEXT,
    daily_receive INTEGER,
    PRIMARY KEY (user_id, date)
  )`);

  // Bảng lưu dữ liệu người dùng
  writeData(`CREATE TABLE IF NOT EXISTS user_data (
    user_id TEXT PRIMARY KEY,
    level INTEGER DEFAULT 1,
    experience INTEGER DEFAULT 0,
    last_daily DATETIME,
    banned INTEGER DEFAULT 0,
    game_count INTEGER DEFAULT 0,
    last_game_time DATETIME,
    daily_exp INTEGER DEFAULT 0,
    message_count INTEGER DEFAULT 0
  )`);

  // Bảng lưu số tiền của người dùng
  writeData(`CREATE TABLE IF NOT EXISTS user_money (
    user_id TEXT PRIMARY KEY,
    money INTEGER DEFAULT 0
  )`);

  // Bảng lưu các nhiệm vụ của người dùng
  writeData(`CREATE TABLE IF NOT EXISTS tasks (
    task_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT,
    description TEXT,
    reward INTEGER,
    completed BOOLEAN DEFAULT 0,
    completion_time DATETIME,
    FOREIGN KEY(user_id) REFERENCES user_money(user_id)
  )`);

  // Bảng lưu cược lô tô
  writeData(`CREATE TABLE IF NOT EXISTS lottery_bets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    number INTEGER NOT NULL,
    amount INTEGER NOT NULL,
    server_id TEXT NOT NULL,
    message_link TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  // Bảng lưu các kênh thông báo của guild
  writeData(`CREATE TABLE IF NOT EXISTS announcement_channels (
    guild_id TEXT PRIMARY KEY,
    channel_id TEXT
  )`);

});

module.exports = dbLove;
