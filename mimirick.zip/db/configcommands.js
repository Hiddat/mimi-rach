const sqlite3 = require('sqlite3').verbose();
const path = require('path');

// Path to the SQLite database file
const dbPath = path.resolve(__dirname, 'commands.db');

// Connect to the SQLite database
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Could not connect to the database:', err);
    }
});

// Create the disabled_commands table if it doesn't exist
db.run(`CREATE TABLE IF NOT EXISTS disabled_commands (
    guildId TEXT NOT NULL,
    channelId TEXT NOT NULL,
    commandName TEXT,
    category TEXT
)`);

module.exports = db;
