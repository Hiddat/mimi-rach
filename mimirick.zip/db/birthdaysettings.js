const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./db/birthdaySettings.db');

db.serialize(() => {
    db.run(`
        CREATE TABLE IF NOT EXISTS BirthdaySettings (
            guild_id TEXT PRIMARY KEY,
            title TEXT,
            description TEXT,
            thumbnail TEXT,
            image TEXT,
            color TEXT,
            content TEXT,
            channel_id TEXT,
            enabled INTEGER,
            everyone_tag INTEGER,
            birthday_count INTEGER DEFAULT 0
        )
    `);
    db.run(`
        CREATE TABLE IF NOT EXISTS Birthdays (
            guild_id TEXT,
            user_id TEXT,
            date TEXT,
            PRIMARY KEY (guild_id, user_id)
        )
    `);
});

function setBirthdaySetting(guild_id, key, value) {
    return new Promise((resolve, reject) => {
        const stmt = db.prepare(`
            INSERT INTO BirthdaySettings (guild_id, ${key})
            VALUES (?, ?)
            ON CONFLICT(guild_id)
            DO UPDATE SET ${key} = excluded.${key}
        `);
        stmt.run(guild_id, value, function (err) {
            if (err) {
                return reject(err);
            }
            resolve();
        });
        stmt.finalize();
    });
}

function setBirthdayNotiSetting(guild_id, key, value) {
    return setBirthdaySetting(guild_id, key, value);
}

function getBirthdaySettings(guild_id) {
    return new Promise((resolve, reject) => {
        db.get(`SELECT * FROM BirthdaySettings WHERE guild_id = ?`, [guild_id], (err, row) => {
            if (err) {
                return reject(err);
            }
            resolve(row);
        });
    });
}

function getBirthdayNotiSettings(guild_id) {
    return getBirthdaySettings(guild_id);
}

function getBirthdays(guild_id) {
    return new Promise((resolve, reject) => {
        db.all(`SELECT * FROM Birthdays WHERE guild_id = ?`, [guild_id], (err, rows) => {
            if (err) {
                return reject(err);
            }
            resolve(rows);
        });
    });
}

function updateBirthday(guild_id, user_id, date) {
    return new Promise((resolve, reject) => {
        const stmt = db.prepare(`
            INSERT INTO Birthdays (guild_id, user_id, date)
            VALUES (?, ?, ?)
            ON CONFLICT(guild_id, user_id)
            DO UPDATE SET date = excluded.date
        `);
        stmt.run(guild_id, user_id, date, function (err) {
            if (err) {
                return reject(err);
            }
            resolve();
        });
        stmt.finalize();
    });
}

module.exports = {
    setBirthdaySetting,
    setBirthdayNotiSetting,
    getBirthdaySettings,
    getBirthdayNotiSettings,
    getBirthdays,
    updateBirthday
};
